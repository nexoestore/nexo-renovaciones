# Arquitectura del negocio — Control de Cuentas Streaming

## Flujo principal

**Proveedor → Compra/Stock → Venta → Entrega → Renovación → Corte → Ganancia**

La aplicación se organiza alrededor de cinco preguntas:

1. ¿Qué puedo vender ahora?
2. ¿Qué clientes requieren cobro o renovación?
3. ¿Qué cuentas debo renovar con mis proveedores?
4. ¿Cuánto estoy vendiendo, gastando y ganando?
5. ¿Qué ocurrió con cada cliente/cuenta?

## Modelo de inventario

### Cuenta completa
Es una unidad individual que se compra a un proveedor y se vende completa a un cliente.

Estados:
- **Disponible**: está en Stock y puede venderse.
- **Entregada**: ya fue vendida; no pertenece al Stock vendible.
- **No disponible**: no debe venderse por caída, bloqueo o vencimiento del proveedor.

Al finalizar el servicio del cliente, la cuenta vuelve a **Disponible** si sigue siendo válida para vender.

### Cuenta por perfiles/pantallas
La cuenta completa funciona como contenedor y el inventario comercial son sus perfiles.

Cada perfil usa:
- **Disponible**: libre para vender.
- **Ocupado**: asignado a un cliente.
- **No disponible**: temporalmente fuera de venta.

Una cuenta compartida puede seguir activa mientras tenga clientes y, al mismo tiempo, conservar perfiles disponibles para nuevas ventas.

## Significado de las pestañas

### Inicio
Prioriza trabajo y dinero: vencidos, vencen hoy, stock, proveedor por vencer, cartera, ventas, costos y utilidad.

### Renovar
Gestiona cobros, +30 días, promesas de pago, ajustes y finalización del servicio.

### Stock
Separa de forma explícita **Stock para vender** de **Cuentas activas**.

### Proveedores
Controla quién suministra cada cuenta, inversión, vencimiento, renovación, ingresos producidos y utilidad acumulada.

### Reportes
Resume rendimiento comercial y operativo sin mezclarlo con las acciones del día.

### Ajustes
Contiene configuración, plantillas, actividad, incidencias y respaldos. No compite con las cinco áreas operativas principales.

## Regla de datos

Una venta desde Stock debe reutilizar los datos ya conocidos de la cuenta. El vendedor solo completa los datos variables de la operación. Esto reduce errores de correo, contraseña, proveedor y costo.

## Regla financiera

- Venta/Renovación de cliente = ingreso.
- Compra de cuenta/stock = costo.
- Renovación pagada al proveedor = costo.
- Ajuste de días = no es ingreso.
- Contacto por WhatsApp = no es ingreso.
- Baja = no es ingreso; libera el acceso cuando corresponde.

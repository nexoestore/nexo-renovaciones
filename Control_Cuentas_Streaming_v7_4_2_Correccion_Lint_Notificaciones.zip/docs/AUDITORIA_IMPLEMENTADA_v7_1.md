# Auditoría implementada — v7.1

La v7.1 completa la Fase 1 del plan profesional reducido a 3 etapas.

## Base sólida
- Room es el almacenamiento principal.
- Migración automática desde formatos anteriores.
- Entidades separadas para clientes, proveedores, cuentas, perfiles, suscripciones, historial y plantillas.
- Modelo operativo Cuenta → Perfil → Cliente/Suscripción.

## Seguridad
- Contraseñas y PIN se cifran localmente con AES-GCM y una clave no exportable de Android Keystore.
- Si el cifrado local falla, la aplicación ya no guarda silenciosamente la credencial en texto plano.
- Los respaldos nuevos requieren contraseña y se cifran con PBKDF2-HMAC-SHA256 + AES-GCM.
- AES-GCM autentica el contenido: una copia alterada o dañada no se restaura como válida.
- PIN opcional de acceso de 4 a 8 dígitos; se guarda solo salt + hash PBKDF2.
- Cinco intentos fallidos activan una espera temporal de 30 segundos.
- Huella/biometría opcional en dispositivos compatibles.
- Bloqueo automático al regresar tras 1 minuto en segundo plano y botón Bloquear ahora.

## Pruebas
- Reglas de negocio existentes.
- Cifrado/restauración de respaldo.
- Verificación segura del PIN.

## Próxima etapa
Fase 2: exactitud y automatización operativa (renovación editable, calendarios, validaciones, registros erróneos y alertas avanzadas).

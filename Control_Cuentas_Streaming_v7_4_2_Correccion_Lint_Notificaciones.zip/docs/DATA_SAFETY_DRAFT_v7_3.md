# Borrador de Seguridad de datos — Google Play

Este documento es una guía para completar la sección **Seguridad de los datos** de Play Console. Debe revisarse de nuevo si se añaden SDK, analítica, publicidad, nube o backend.

## Situación técnica de v7.3
- La app no declara permiso `INTERNET`.
- No incluye SDK de publicidad ni analítica.
- Clientes, teléfonos, cuentas, contraseñas, PIN, pagos y proveedores se procesan y guardan localmente.
- Contraseñas y PIN se cifran localmente con Android Keystore.
- Los respaldos nuevos se cifran con contraseña antes de salir del almacenamiento privado de la app.
- WhatsApp se abre mediante una intención externa cuando el usuario decide enviar un mensaje; Control Streaming no envía el mensaje a servidores propios.

## Borrador orientativo
Si la configuración publicada es exactamente la de esta versión, la app no transmite datos de usuario al desarrollador ni a un backend propio. En Play Console revisa cuidadosamente la definición vigente de “recogida” y “compartición” antes de responder.

## Obligatorio
La política de privacidad debe estar publicada en una URL pública y también ser accesible desde la app. v7.3 incluye una sección “Privacidad y datos” dentro de Ajustes.

Fuente oficial: https://support.google.com/googleplay/android-developer/answer/10144311

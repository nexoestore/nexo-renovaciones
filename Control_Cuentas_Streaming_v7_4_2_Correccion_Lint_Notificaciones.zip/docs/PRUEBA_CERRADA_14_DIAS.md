# Plan de prueba cerrada

Si la cuenta personal de Play Console fue creada después del 13 de noviembre de 2023, Google exige actualmente una prueba cerrada con al menos **12 testers** inscritos de forma continua durante **14 días** antes de solicitar acceso a producción.

## Qué pedir a cada tester
- Crear al menos una cuenta completa.
- Crear una cuenta por perfiles.
- Vender un acceso desde Stock.
- Renovar un cliente.
- Dar plazo a un cliente.
- Finalizar un servicio y comprobar que el acceso vuelve a Stock.
- Registrar/renovar un proveedor.
- Crear y restaurar un respaldo de prueba.
- Probar PIN/biometría.
- Revisar el diagnóstico comercial.

## Registro de incidencias
Guardar: modelo de celular, Android, versión de app, pasos para reproducir y captura. No pedir contraseñas ni PIN de cuentas reales.

Fuente oficial: https://support.google.com/googleplay/android-developer/answer/14151465

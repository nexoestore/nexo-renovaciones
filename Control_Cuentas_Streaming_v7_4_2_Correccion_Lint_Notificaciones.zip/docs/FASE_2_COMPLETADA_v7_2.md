# Control de Cuentas Streaming v7.2 — Fase 2

Esta fase se centra en exactitud operativa y automatización sin cambiar el modelo de datos Room de v7.1.

## Renovaciones exactas
- Renovar ya no registra a ciegas el precio y método anteriores.
- Antes de confirmar se puede revisar/cambiar valor cobrado, método de pago y duración.
- Regla: si aún está activo, los días se suman al vencimiento actual; si ya venció, se cuentan desde hoy.
- Cobranza rápida usa el mismo flujo de confirmación.

## Fechas seguras
- Los formularios operativos usan selector de calendario en lugar de depender de escribir AAAA-MM-DD.
- Se validan relaciones: fin >= inicio y vencimiento proveedor >= compra cuando ambas fechas existen.
- Promesas de pago no permiten fechas anteriores a hoy.

## Validaciones
- Se detectan WhatsApp demasiado cortos.
- Duración debe ser mayor que cero.
- Los perfiles de una misma cuenta deben tener nombres únicos.
- Se normalizan importes numéricos desde la interfaz.

## Corrección de errores
- Desde Editar entrega/cuenta existe “Eliminar registro de prueba / error”.
- Elimina la entrega equivocada y sus movimientos asociados para no contaminar reportes.
- Si la venta venía de Stock, libera el acceso vinculado.
- Esta opción no sustituye “No renovó”, que conserva el historial comercial.

## Automatización
- Un cliente vencido y pendiente de corte programa hasta 3 recordatorios matutinos consecutivos, cancelados al renovar/cortar.
- Promesas de pago usan plantilla configurable.
- Avisos de proveedor usan plantillas configurables para 3 días, mañana y hoy.
- Mensajes automáticos se administran desde Ajustes.

## Backup
- Formato interno de respaldo: versión 8.
- Restaura respaldos 1–8.
- Mantiene cifrado y respaldo de emergencia de v7.1.

# Fase 3 — Calidad comercial y preparación Google Play

La v7.3 no cambia el modelo de negocio de v7.2. Endurece el proceso de lanzamiento y soporte.

## Implementado
- Diagnóstico comercial dentro de Ajustes con puntuación y hallazgos.
- Exportación de diagnóstico sin credenciales ni datos personales.
- Sección de privacidad accesible dentro de la app.
- Guía rápida para distribuidores con poca experiencia.
- CI exige tests unitarios, Android Lint, APK release y AAB release.
- Verificación criptográfica del APK/AAB generado y checksums SHA-256.
- Documentación específica para Data Safety, prueba cerrada, Play Integrity y checklist de publicación.

## Play Integrity
Se deja documentada la integración real. No se simula una licencia local. Para activar verificación de licencia hace falta primero crear/configurar la app en Play Console y el proyecto de Google Cloud/backend correspondiente.

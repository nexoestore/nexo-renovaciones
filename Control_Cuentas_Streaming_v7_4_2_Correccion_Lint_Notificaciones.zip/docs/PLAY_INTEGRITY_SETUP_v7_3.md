# Play Integrity y licencia — preparación v7.3

La aplicación puede publicarse como **app de pago** sin integrar un cobro dentro de la app. Google Play gestiona la compra y las actualizaciones para el comprador.

## Por qué v7.3 no bloquea todavía instalaciones con Play Integrity
La comprobación robusta de licencia con Play Integrity requiere:
1. Crear/configurar la app en Play Console.
2. Vincular el proyecto de Google Cloud correspondiente.
3. Solicitar un token de integridad desde la app.
4. Verificar ese token de forma confiable, normalmente en un backend seguro.

No se incluyó una falsa “licencia local” fácil de saltar. Cuando la ficha de Play Console exista, se puede conectar el flujo real y comprobar `appLicensingVerdict` (`LICENSED` / `UNLICENSED`).

Fuente oficial: https://developer.android.com/google/play/integrity/verdicts

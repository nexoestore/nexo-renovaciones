# Migración segura a v7.1

1. Desde la versión instalada crea un respaldo manual antes de actualizar.
2. Instala v7.1 encima de la app actual (misma firma y applicationId).
3. Abre la app y comprueba: Stock, perfiles, clientes activos, proveedores, reportes y actividad.
4. En Ajustes crea una contraseña de respaldo v7.
5. Guarda un nuevo respaldo cifrado y consérvalo fuera de la app.
6. Verifica que las notificaciones estén permitidas por Android.

Si una prueba falla, conserva el respaldo anterior antes de modificar o desinstalar la app.

# Checklist de lanzamiento — v7.3

## Antes de compilar
- [ ] Respaldo local actualizado.
- [ ] Diagnóstico comercial sin hallazgos críticos.
- [ ] PIN de acceso configurado.
- [ ] Carpeta de respaldo automático configurada.
- [ ] Notificaciones habilitadas.

## CI / GitHub Actions
- [ ] Tests unitarios verdes.
- [ ] `lintRelease` verde.
- [ ] APK release firmado y verificado.
- [ ] AAB release firmado y verificado.
- [ ] Checksums SHA-256 guardados.

## Play Console
- [ ] Nombre, icono, capturas y descripción.
- [ ] Política de privacidad en URL pública.
- [ ] Seguridad de los datos revisada.
- [ ] Clasificación de contenido completa.
- [ ] App configurada como **de pago antes de publicarla gratis**, si ese es el modelo comercial elegido.
- [ ] Precio y países configurados.
- [ ] Play App Signing activado.
- [ ] Prueba interna completada.
- [ ] Prueba cerrada completada si la cuenta lo requiere.

## Producción
- [ ] Probar instalación limpia.
- [ ] Probar actualización desde la versión anterior.
- [ ] Probar migración de datos.
- [ ] Probar respaldo/restauración.
- [ ] Probar compra/descarga desde el canal de prueba de Play.

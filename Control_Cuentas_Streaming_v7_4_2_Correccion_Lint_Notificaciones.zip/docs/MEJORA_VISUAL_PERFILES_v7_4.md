# Mejora visual de perfiles — v7.4

Objetivo: que un distribuidor pueda entender en segundos cuántos perfiles tiene una cuenta, cuáles están libres, cuáles están ocupados y qué debe hacer al tocarlos.

## Comportamiento
- Cuenta por perfiles: muestra todos los espacios en una cuadrícula visible.
- LIBRE: cian. Tocar = asignar cliente.
- OCUPADO: morado. Muestra cliente y vencimiento. Tocar = administrar perfil.
- NO DISPONIBLE: rojo. Tocar = revisar/habilitar.
- Vencimiento proveedor permanece separado del vencimiento de cada cliente.

## Compatibilidad
No cambia el formato de los datos ni borra registros. Es una mejora de visualización y flujo sobre la base v7.3.

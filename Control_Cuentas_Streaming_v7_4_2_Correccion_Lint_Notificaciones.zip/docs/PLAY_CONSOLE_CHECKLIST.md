# Control de Cuentas Streaming v7.0 — Checklist Google Play

## Ruta recomendada para monetizar esta primera versión

Para el primer lanzamiento comercial, la ruta más simple es publicar la aplicación como **app de pago** en Google Play. El comprador paga antes de descargarla y la aplicación no necesita implementar un sistema propio de licencias.

Importante: decide que será **de pago antes de publicarla como gratuita**. Google Play permite pasar una app de pago a gratuita, pero una app que ya fue ofrecida gratis no puede convertirse después en app de pago con el mismo package; para eso haría falta otro package.

Si más adelante quieres cobrar **mensualmente**, la app deberá integrar Google Play Billing y, para una protección comercial sólida, validar las compras con un backend seguro.

## Estado técnico de esta versión

- Package: `com.nexo.suscripciones`
- Version name: `7.0`
- Version code: `28`
- Target SDK: `36` (Android 16)
- Compile SDK: `36`
- Java: `17`
- Genera APK release y AAB release
- Usa la misma clave permanente configurada en GitHub Secrets
- Backup del sistema Android desactivado: la app usa su propio respaldo local
- Tráfico HTTP sin cifrar desactivado

## Archivos que debes subir a Google Play

Sube el archivo `.aab`, no el APK. El workflow incluido genera ambos:

- APK: sirve para tus pruebas directas.
- AAB: es el archivo que se sube a Play Console.

## Secuencia en Play Console

1. Crear la aplicación en Play Console.
2. Elegir el nombre comercial: **Control de Cuentas Streaming**.
3. Completar Ficha de Play Store.
4. Completar Política de privacidad y Seguridad de los datos.
5. Completar Clasificación de contenido.
6. Indicar que la app no contiene anuncios, si no agregas publicidad.
7. Configurar países/regiones.
8. En Productos > Precio de la aplicación, establecer la app como **de pago** y fijar el precio.
9. Activar Play App Signing cuando Play Console lo solicite.
10. Subir el AAB a prueba interna/cerrada antes de producción.
11. Probar restauración de respaldo, notificaciones, WhatsApp y ventas desde stock.
12. Publicar cuando Play Console indique que todos los requisitos están completos.

## Si tu cuenta personal de desarrollador es nueva

Las cuentas personales creadas después del 13 de noviembre de 2023 pueden requerir una prueba cerrada con al menos 12 testers durante 14 días continuos antes de solicitar acceso a Producción.

## Monetización mensual (fase posterior)

Para vender una suscripción mensual a la aplicación:

- Crear una suscripción en Play Console.
- Integrar Google Play Billing.
- Consultar y reconocer compras.
- Validar el estado de la compra en un backend seguro.
- Bloquear/desbloquear funciones según el entitlement del usuario.

No conviene hacer un bloqueo mensual solo con validaciones locales; para una suscripción comercial debe verificarse el derecho de uso con Google Play Billing y un backend seguro.

## Documentación oficial consultada

- Target API: https://support.google.com/googleplay/android-developer/answer/11926878
- Subir App Bundle: https://developer.android.com/studio/publish/upload-bundle
- Precios de apps: https://support.google.com/googleplay/android-developer/answer/6334373
- Google Play Billing: https://developer.android.com/google/play/billing/integrate
- Requisitos de pruebas: https://support.google.com/googleplay/android-developer/answer/14151465

# Migración a v7.2

La v7.2 mantiene la base Room y el applicationId de v7.1. No crea una base de datos distinta ni requiere borrar la aplicación.

## Antes de actualizar
1. Crea un respaldo cifrado desde la versión instalada.
2. Conserva el archivo `.nexo` fuera del almacenamiento privado de la app.
3. Instala la APK v7.2 firmada con la misma clave permanente.

## Compatibilidad de datos
- Se conserva la base Room creada por v7.0/v7.1.
- Se conservan clientes, proveedores, cuentas, perfiles, suscripciones, historial y plantillas.
- El formato de respaldo pasa a `backupVersion 8` por las nuevas plantillas de recordatorios.
- Restaurar sigue aceptando respaldos anteriores no cifrados y respaldos cifrados de v7.x.

## Qué conviene comprobar después de actualizar
- Una cuenta completa disponible y una entregada.
- Una cuenta por perfiles con perfiles libres y ocupados.
- Renovar un cliente cambiando precio y método de pago.
- Dar plazo y comprobar que queda en espera.
- Renovar una cuenta con el proveedor.
- Editar fechas mediante calendario.
- Crear y restaurar un respaldo de prueba.

# Control de Cuentas Streaming v7.1 — Fase 1 completada

Esta versión completa la primera fase de la auditoría profesional sobre la base de v7.0.

## Incluido
- Room como almacenamiento principal y migración desde versiones anteriores.
- Modelo Cuenta → Perfil → Cliente/Suscripción.
- Contraseñas y PIN cifrados con Android Keystore.
- Copias de seguridad portables cifradas con AES-GCM y contraseña.
- Se impide crear un respaldo v7 sin contraseña configurada.
- PIN de acceso de 4 a 8 dígitos, almacenado como hash PBKDF2 con sal aleatoria.
- Protección ante intentos repetidos: 5 errores bloquean temporalmente nuevos intentos.
- Desbloqueo opcional con huella/biometría cuando el dispositivo lo soporta.
- Bloqueo automático al regresar después de 1 minuto en segundo plano y botón “Bloquear ahora”.
- Pruebas unitarias para cifrado de respaldo, reglas de negocio y verificación segura de PIN.

## No incluido todavía
La fase 2 cubrirá exactitud y automatización operativa: confirmación editable al renovar, selectores de fecha, validaciones más estrictas, manejo de registros erróneos y mejoras adicionales de alertas.

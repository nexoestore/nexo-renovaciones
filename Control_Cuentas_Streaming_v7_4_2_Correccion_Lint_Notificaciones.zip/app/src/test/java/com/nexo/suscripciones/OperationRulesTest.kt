package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class OperationRulesTest {
    @Test fun renewal_before_expiry_adds_to_current_expiry(){
        val today=LocalDate.of(2026,10,3)
        assertEquals("2026-11-14",OperationRules.renewalEnd("2026-10-15",30,today))
    }

    @Test fun renewal_after_expiry_starts_from_today(){
        val today=LocalDate.of(2026,10,3)
        assertEquals("2026-11-02",OperationRules.renewalEnd("2026-09-15",30,today))
    }

    @Test fun end_cannot_be_before_start(){
        assertFalse(OperationRules.dateRangeValid("2026-10-10","2026-10-09"))
        assertTrue(OperationRules.dateRangeValid("2026-10-10","2026-10-10"))
    }

    @Test fun duplicate_profile_names_are_rejected_case_insensitive(){
        assertFalse(OperationRules.uniqueProfileNames(listOf("Perfil 1","perfil 1")))
        assertTrue(OperationRules.uniqueProfileNames(listOf("Perfil 1","Perfil 2")))
    }

    @Test fun phone_validation_allows_blank_or_reasonable_number(){
        assertTrue(OperationRules.phoneValidOrBlank(""))
        assertTrue(OperationRules.phoneValidOrBlank("+57 300 123 4567"))
        assertFalse(OperationRules.phoneValidOrBlank("123"))
    }
}

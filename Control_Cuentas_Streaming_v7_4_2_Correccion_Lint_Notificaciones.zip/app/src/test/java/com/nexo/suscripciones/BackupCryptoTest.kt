package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test

class BackupCryptoTest {
    @Test fun encryptedBackupRoundTrip(){
        val source="{\"backupVersion\":7,\"client\":\"Ana\"}"
        val encrypted=BackupCrypto.encrypt(source,"secreto123")
        assertTrue(BackupCrypto.isEncrypted(encrypted))
        assertNotEquals(source,encrypted)
        assertEquals(source,BackupCrypto.decrypt(encrypted,"secreto123"))
    }

    @Test fun legacyBackupRemainsReadable(){
        val source="{\"backupVersion\":6}"
        assertFalse(BackupCrypto.isEncrypted(source))
        assertEquals(source,BackupCrypto.decrypt(source,""))
    }
}

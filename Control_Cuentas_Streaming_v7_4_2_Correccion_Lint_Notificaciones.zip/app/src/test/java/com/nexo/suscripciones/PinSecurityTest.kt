package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test

class PinSecurityTest {
    @Test fun pinHashRoundTrip(){
        val salt=PinSecurity.newSalt()
        val saltB64=PinSecurity.encode(salt)
        val hash=PinSecurity.hash("2580",salt)
        assertTrue(PinSecurity.verify("2580",saltB64,hash))
        assertFalse(PinSecurity.verify("2581",saltB64,hash))
    }
}

package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class BusinessRulesTest {
    @Test fun monthlyCostCountsAccountWithoutProvider(){
        val stock=listOf(StockItem(id=1,service="Max",account="a@b.com",type="CUENTA COMPLETA",accountCost=6500,purchaseDate=LocalDate.now().toString()))
        assertEquals(6500L,monthlyAccountCosts(emptyList(),stock))
    }

    @Test fun deliveryOmitsEmptyProfileAndPin(){
        val s=Sub(client="Ana",phone="57",service="Max",account="a@b.com",profile="",type="CUENTA COMPLETA",price=10000,start="2026-10-01",end="2026-11-01",password="abc")
        val msg=fillTemplate(Templates().delivery,s)
        assertTrue(msg.contains("Cuenta: a@b.com"))
        assertFalse(msg.contains("Perfil:"))
        assertFalse(msg.contains("PIN/clave:"))
    }

    @Test fun providerVariantsNormalizeTogether(){
        val expected=providerKey("G2G")
        assertEquals(expected,providerKey("https://www.g2g.com"))
        assertEquals(expected,providerKey("g2g.com"))
        assertEquals(expected,providerKey("  g2g  "))
    }
}

package com.nexo.suscripciones

import org.junit.Assert.assertTrue
import org.junit.Test

class CommercialReadinessTest {
    @Test fun healthySetupScoresHigh(){
        val report=CommercialReadiness.evaluate(emptyList(),emptyList(),true,true,true,true)
        assertTrue(report.score>=90)
        assertTrue(report.issues.isEmpty())
    }

    @Test fun missingSecurityAndNotificationsAreCritical(){
        val report=CommercialReadiness.evaluate(emptyList(),emptyList(),false,false,false,false)
        assertTrue(report.issues.any{it.severity=="CRITICO"})
        assertTrue(report.score<90)
    }

    @Test fun invalidClientDatesAreDetected(){
        val s=Sub(client="Cliente",phone="3001234567",service="Servicio",account="a",profile="",type="CUENTA COMPLETA",price=10000,start="2026-10-10",end="2026-10-01")
        val report=CommercialReadiness.evaluate(listOf(s),emptyList(),true,true,true,true)
        assertTrue(report.issues.any{it.title.contains("Fechas de cliente")})
    }
}

package com.nexo.suscripciones

data class CommercialIssue(val severity:String,val title:String,val detail:String)
data class CommercialReport(val score:Int,val label:String,val issues:List<CommercialIssue>)

object CommercialReadiness {
    private fun isCompleteAccess(x:StockItem):Boolean {
        val u=x.type.uppercase()
        return u.contains("CUENTA COMPLETA") || (u.contains("CORREO/CONTRASEÑA") && x.profile.isBlank())
    }

    fun evaluate(
        subs:List<Sub>,
        stock:List<StockItem>,
        pinEnabled:Boolean,
        backupProtected:Boolean,
        backupFolderConfigured:Boolean,
        notificationsEnabled:Boolean
    ):CommercialReport {
        val issues=mutableListOf<CommercialIssue>()
        if(!pinEnabled) issues += CommercialIssue("ADVERTENCIA","PIN de acceso desactivado","Actívalo antes de entregar la app a un distribuidor.")
        if(!backupProtected) issues += CommercialIssue("CRITICO","Respaldo sin contraseña","Configura una contraseña de respaldo para proteger las credenciales.")
        if(!backupFolderConfigured) issues += CommercialIssue("ADVERTENCIA","Copia automática sin carpeta","Elige una carpeta local para conservar copias automáticas.")
        if(!notificationsEnabled) issues += CommercialIssue("CRITICO","Notificaciones desactivadas","Los avisos de clientes y proveedores pueden no mostrarse.")

        val badClientDates=subs.count{it.status!="CORTADO" && !OperationRules.dateRangeValid(it.start,it.end)}
        if(badClientDates>0) issues += CommercialIssue("CRITICO","Fechas de cliente inconsistentes","Hay $badClientDates entrega(s) con inicio/fin inválidos.")

        val shortPhones=subs.count{it.status!="CORTADO" && it.phone.isNotBlank() && !OperationRules.phoneValidOrBlank(it.phone)}
        if(shortPhones>0) issues += CommercialIssue("ADVERTENCIA","WhatsApp incompleto","Hay $shortPhones cliente(s) con un número demasiado corto.")

        val missingProviders=stock.filter{it.accountCost>0 && it.provider.isBlank()}.map{it.masterId.ifBlank{it.account}}.distinct().size
        if(missingProviders>0) issues += CommercialIssue("ADVERTENCIA","Costos sin proveedor","Hay $missingProviders cuenta(s) con costo pero sin proveedor asignado.")

        val invalidProviderDates=stock.filter{it.purchaseDate.isNotBlank()&&it.accountEnd.isNotBlank()&&!OperationRules.optionalDateRangeValid(it.purchaseDate,it.accountEnd)}
            .map{it.masterId.ifBlank{it.account}}.distinct().size
        if(invalidProviderDates>0) issues += CommercialIssue("CRITICO","Fechas de proveedor inconsistentes","Hay $invalidProviderDates cuenta(s) con vencimiento anterior a la compra.")

        val duplicateProfiles=stock.filter{!isCompleteAccess(it)}
            .groupBy{it.masterId.ifBlank{"${it.service.trim().lowercase()}|${it.account.trim().lowercase()}"}}
            .count{(_,items)->!OperationRules.uniqueProfileNames(items.map{it.profile})}
        if(duplicateProfiles>0) issues += CommercialIssue("CRITICO","Perfiles duplicados","Hay $duplicateProfiles cuenta(s) con nombres de perfil repetidos.")

        val activeWithoutStock=subs.count{it.status!="CORTADO" && it.stockId>0 && stock.none{s->s.id==it.stockId}}
        if(activeWithoutStock>0) issues += CommercialIssue("CRITICO","Entregas sin acceso asociado","Hay $activeWithoutStock entrega(s) que apuntan a un acceso inexistente.")

        val critical=issues.count{it.severity=="CRITICO"}
        val warnings=issues.size-critical
        val score=(100-critical*15-warnings*5).coerceIn(0,100)
        val label=when{score>=90->"Excelente";score>=75->"Bien";score>=60->"Atención";else->"Revisar"}
        return CommercialReport(score,label,issues)
    }

    fun plainText(report:CommercialReport,appVersion:String,subscriptions:Int,stockItems:Int,clients:Int,providers:Int):String=buildString{
        appendLine("CONTROL DE CUENTAS STREAMING - DIAGNOSTICO")
        appendLine("Version: $appVersion")
        appendLine("Estado: ${report.score}/100 - ${report.label}")
        appendLine("Entregas: $subscriptions")
        appendLine("Accesos en stock: $stockItems")
        appendLine("Clientes: $clients")
        appendLine("Proveedores: $providers")
        appendLine()
        appendLine("REVISION")
        if(report.issues.isEmpty()) appendLine("Sin hallazgos operativos.")
        else report.issues.forEach{appendLine("[${it.severity}] ${it.title}: ${it.detail}")}
        appendLine()
        appendLine("Este diagnostico no incluye correos, contraseñas, PIN, telefonos ni credenciales.")
    }
}

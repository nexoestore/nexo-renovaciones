package com.nexo.suscripciones

import java.time.LocalDate

object OperationRules {
    fun parseDate(value:String):LocalDate? = runCatching { LocalDate.parse(value.trim()) }.getOrNull()

    fun dateRangeValid(start:String,end:String):Boolean {
        val a=parseDate(start)?:return false
        val b=parseDate(end)?:return false
        return !b.isBefore(a)
    }

    fun optionalDateRangeValid(start:String,end:String):Boolean {
        if(start.isBlank()||end.isBlank()) return true
        return dateRangeValid(start,end)
    }

    fun renewalEnd(currentEnd:String,days:Int,today:LocalDate=LocalDate.now()):String {
        val old=parseDate(currentEnd)?:today
        val base=if(old.isBefore(today))today else old
        return base.plusDays(days.coerceAtLeast(1).toLong()).toString()
    }

    fun phoneValidOrBlank(phone:String):Boolean {
        if(phone.isBlank()) return true
        return phone.filter(Char::isDigit).length>=7
    }

    fun uniqueProfileNames(names:List<String>):Boolean {
        val cleaned=names.map{it.trim().lowercase()}.filter{it.isNotBlank()}
        return cleaned.size==cleaned.distinct().size
    }

    fun amount(text:String):Long = text.filter(Char::isDigit).toLongOrNull()?:0L
}

package com.nexo.suscripciones

import java.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Respaldo portable: el usuario puede restaurarlo tras reinstalar usando su contraseña. */
object BackupCrypto {
    private const val PREFIX="NEXO7ENC"
    private const val ITERATIONS=150_000
    private const val KEY_BITS=256

    fun isEncrypted(text:String)=text.startsWith("$PREFIX|")

    fun encrypt(plain:String,password:String):String{
        require(password.length>=6){"La contraseña de respaldo debe tener al menos 6 caracteres"}
        val random=SecureRandom();val salt=ByteArray(16).also{random.nextBytes(it)}
        val key=derive(password,salt);val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key)
        val body=cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return listOf(PREFIX,b64(salt),b64(cipher.iv),b64(body)).joinToString("|")
    }

    fun decrypt(text:String,password:String):String{
        if(!isEncrypted(text))return text
        require(password.isNotBlank()){"Se necesita la contraseña del respaldo"}
        val p=text.split("|",limit=4);require(p.size==4&&p[0]==PREFIX){"Formato de respaldo no válido"}
        val salt=unb64(p[1]);val iv=unb64(p[2]);val body=unb64(p[3]);val cipher=Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE,derive(password,salt),GCMParameterSpec(128,iv))
        return String(cipher.doFinal(body),Charsets.UTF_8)
    }

    private fun derive(password:String,salt:ByteArray):SecretKeySpec{
        val f=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");val spec=PBEKeySpec(password.toCharArray(),salt,ITERATIONS,KEY_BITS)
        return SecretKeySpec(f.generateSecret(spec).encoded,"AES")
    }
    private fun b64(v:ByteArray)=Base64.getEncoder().encodeToString(v)
    private fun unb64(v:String)=Base64.getDecoder().decode(v)
}

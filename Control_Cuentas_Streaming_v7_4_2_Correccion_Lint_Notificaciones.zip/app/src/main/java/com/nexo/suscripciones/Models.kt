package com.nexo.suscripciones

data class Sub(
    val id:Long=System.currentTimeMillis(), val client:String, val phone:String, val service:String,
    val account:String, val profile:String, val type:String, val price:Long, val start:String, val end:String,
    val status:String="ACTIVO", val paid:Boolean=true, val pin:String="", val accountCost:Long=0,
    val paymentMethod:String="Efectivo", val contacted:Boolean=false, val password:String="",
    val provider:String="", val providerPhone:String="", val accountEnd:String="", val accountRenewCost:Long=0,
    val promiseDate:String="", val stockId:Long=0, val lastContact:String="", val purchaseDate:String=""
)

data class StockItem(
    val id:Long=System.currentTimeMillis(), val service:String, val account:String, val password:String="",
    val profile:String="", val pin:String="", val type:String="PERFIL/PANTALLA", val provider:String="",
    val providerPhone:String="", val accountEnd:String="", val accountCost:Long=0, val accountRenewCost:Long=0,
    val status:String="DISPONIBLE", val purchaseDate:String="", val masterId:String=""
)

data class AccountMaster(
    val id:String, val service:String, val account:String, val password:String="", val type:String="PERFIL/PANTALLA",
    val provider:String="", val providerPhone:String="", val accountEnd:String="", val accountCost:Long=0,
    val accountRenewCost:Long=0, val purchaseDate:String=""
)

data class StockSlot(
    val id:Long, val masterId:String, val profile:String="", val pin:String="",
    val type:String="PERFIL/PANTALLA", val status:String="DISPONIBLE"
)

data class ClientRecord(val key:String,val name:String,val phone:String,val createdAt:String="")
data class ProviderRecord(val key:String,val name:String,val phone:String="")
data class ProfileDraft(val id:Long=System.nanoTime(), val name:String, val pin:String="")
data class Hist(val id:Long=System.currentTimeMillis(),val subId:Long,val date:String,val action:String,val amount:Long=0,val method:String="")

data class Templates(
    val due3:String="Hola {cliente} 👋 Tu servicio {servicio} vence el {fecha}. Valor de renovación: ${'$'}{precio}.",
    val due1:String="Hola {cliente} 👋 Tu servicio {servicio} vence mañana ({fecha}). Valor: ${'$'}{precio}.",
    val due0:String="Hola {cliente} 👋 Tu servicio {servicio} vence hoy ({fecha}). Si deseas continuar, puedes renovar por ${'$'}{precio}.",
    val expired:String="Hola {cliente} 👋 Tu servicio {servicio} venció el {fecha}. Si deseas reactivarlo, escríbeme para renovar.",
    val delivery:String="Hola {cliente} 👋 Aquí tienes tus datos de {servicio}:\nCuenta: {cuenta}\nContraseña: {password}\nPerfil: {perfil}\nPIN/clave: {pin}\nVence: {fecha}\nGracias por preferir Nexo.",
    val promise:String="Hola {cliente} 👋 Hoy quedamos pendientes de la renovación de {servicio}. Valor: ${'$'}{precio}. ¿Deseas continuar?",
    val provider3:String="Hola {proveedor} 👋 La cuenta {cuenta} de {servicio} vence el {fecha}. Costo estimado de renovación: ${'$'}{costo}.",
    val provider1:String="Hola {proveedor} 👋 Mañana vence la cuenta {cuenta} de {servicio}. Costo de renovación: ${'$'}{costo}.",
    val provider0:String="Hola {proveedor} 👋 Hoy vence la cuenta {cuenta} de {servicio}. Necesito renovarla. Costo: ${'$'}{costo}."
)

data class ServiceTemplate(
    val id:Long=System.currentTimeMillis(), val name:String, val type:String="CUENTA COMPLETA", val durationDays:Int=30,
    val defaultPrice:Long=0, val provider:String="", val providerPhone:String="", val accountCost:Long=0,
    val renewCost:Long=0
)

data class ProviderAccountSummary(
    val provider:String, val phone:String, val service:String, val account:String, val type:String,
    val cost:Long, val renewCost:Long, val purchaseDate:String, val end:String, val status:String,
    val income:Long, val renewSpent:Long, val subIds:List<Long>
)

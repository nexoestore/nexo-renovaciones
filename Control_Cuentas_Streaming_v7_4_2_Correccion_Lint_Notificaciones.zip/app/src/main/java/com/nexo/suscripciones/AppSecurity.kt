package com.nexo.suscripciones

import android.content.Context
import androidx.biometric.BiometricManager
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object PinSecurity {
    private const val ITERATIONS = 120_000
    private const val KEY_BITS = 256

    fun newSalt(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }

    fun hash(pin: String, salt: ByteArray): String {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_BITS)
        return Base64.getEncoder().encodeToString(factory.generateSecret(spec).encoded)
    }

    fun verify(pin: String, saltB64: String, expectedHash: String): Boolean = runCatching {
        val salt = Base64.getDecoder().decode(saltB64)
        constantTimeEquals(hash(pin, salt), expectedHash)
    }.getOrDefault(false)

    fun encode(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }
}

class AppLockManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("nexo_security", Context.MODE_PRIVATE)

    fun isEnabled(): Boolean = prefs.getBoolean("pin_enabled", false) &&
        !prefs.getString("pin_hash", "").isNullOrBlank() &&
        !prefs.getString("pin_salt", "").isNullOrBlank()

    fun setPin(pin: String): Boolean {
        if (!pin.matches(Regex("\\d{4,8}"))) return false
        val salt = PinSecurity.newSalt()
        val hash = PinSecurity.hash(pin, salt)
        prefs.edit()
            .putString("pin_salt", PinSecurity.encode(salt))
            .putString("pin_hash", hash)
            .putBoolean("pin_enabled", true)
            .putInt("failed_attempts", 0)
            .putLong("lock_until", 0L)
            .apply()
        return true
    }

    fun verifyPin(pin: String): Boolean {
        val now = System.currentTimeMillis()
        if (remainingLockSeconds(now) > 0) return false
        val salt = prefs.getString("pin_salt", "") ?: ""
        val hash = prefs.getString("pin_hash", "") ?: ""
        val ok = PinSecurity.verify(pin, salt, hash)
        if (ok) {
            prefs.edit().putInt("failed_attempts", 0).putLong("lock_until", 0L).apply()
            return true
        }
        val failed = prefs.getInt("failed_attempts", 0) + 1
        val editor = prefs.edit().putInt("failed_attempts", failed)
        if (failed >= 5) editor.putLong("lock_until", now + 30_000L).putInt("failed_attempts", 0)
        editor.apply()
        return false
    }

    fun remainingLockSeconds(now: Long = System.currentTimeMillis()): Long {
        val until = prefs.getLong("lock_until", 0L)
        return ((until - now).coerceAtLeast(0L) + 999L) / 1000L
    }

    fun disablePin(currentPin: String): Boolean {
        if (!verifyPin(currentPin)) return false
        prefs.edit()
            .remove("pin_salt")
            .remove("pin_hash")
            .putBoolean("pin_enabled", false)
            .putBoolean("biometric_enabled", false)
            .remove("failed_attempts")
            .remove("lock_until")
            .apply()
        return true
    }

    fun biometricEnabled(): Boolean = isEnabled() && prefs.getBoolean("biometric_enabled", false)

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("biometric_enabled", enabled && isEnabled() && canUseBiometric()).apply()
    }

    fun canUseBiometric(): Boolean {
        val manager = BiometricManager.from(context)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        return manager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
    }
}

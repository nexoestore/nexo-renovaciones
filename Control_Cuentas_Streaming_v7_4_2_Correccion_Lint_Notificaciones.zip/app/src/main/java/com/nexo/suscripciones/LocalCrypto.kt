package com.nexo.suscripciones

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Cifra credenciales locales con una clave no exportable del Android Keystore. */
object LocalCrypto {
    private const val ALIAS="control_streaming_credentials_v1"
    private const val PREFIX="enc1:"
    @Volatile private var cached:SecretKey?=null

    private fun key():SecretKey=cached?:synchronized(this){
        cached?:run{
            val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
            val existing=ks.getKey(ALIAS,null) as? SecretKey
            val resolved=existing?:run{
                val gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
                gen.init(KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build())
                gen.generateKey()
            }
            cached=resolved;resolved
        }
    }

    fun encrypt(context:Context,value:String):String{
        if(value.isBlank()||value.startsWith(PREFIX))return value
        return runCatching{
            val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key())
            val iv=Base64.getEncoder().encodeToString(cipher.iv);val body=Base64.getEncoder().encodeToString(cipher.doFinal(value.toByteArray(Charsets.UTF_8)))
            "$PREFIX$iv:$body"
        }.getOrElse{ throw IllegalStateException("No se pudo cifrar la credencial local", it) }
    }

    fun decrypt(context:Context,value:String):String{
        if(value.isBlank()||!value.startsWith(PREFIX))return value
        return runCatching{
            val parts=value.removePrefix(PREFIX).split(":",limit=2);require(parts.size==2)
            val iv=Base64.getDecoder().decode(parts[0]);val body=Base64.getDecoder().decode(parts[1])
            val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,iv))
            String(cipher.doFinal(body),Charsets.UTF_8)
        }.getOrDefault("")
    }
}

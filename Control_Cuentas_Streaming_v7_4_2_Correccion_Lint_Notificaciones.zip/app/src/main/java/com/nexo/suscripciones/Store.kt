package com.nexo.suscripciones

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class Store(private val c:Context){
    private val p=c.getSharedPreferences("nexo_db",Context.MODE_PRIVATE)
    private val dao=ProfessionalDatabase.get(c).dao()

    init{ensureMigrated()}

    private fun <T> io(block:()->T):T=runBlocking(Dispatchers.IO){block()}

    private fun clientKey(name:String,phone:String):String{
        val digits=phone.filter{it.isDigit()}
        return if(digits.isNotBlank())"phone:$digits" else "name:${name.trim().lowercase()}"
    }

    private fun masterIdFor(x:StockItem):String{
        if(x.masterId.isNotBlank())return x.masterId
        return if(normalizedAccessType(x.type,x.profile)=="CUENTA COMPLETA")"complete-${x.id}" else "profile-${providerKey(x.provider)}-${x.service.trim().lowercase()}-${accountKey(x.account)}"
    }

    private fun legacySubs():MutableList<Sub>{
        val a=JSONArray(p.getString("subs","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Sub(
            o.getLong("id"),o.getString("client"),o.optString("phone"),o.getString("service"),o.optString("account"),o.optString("profile"),o.optString("type","PERFIL"),o.optLong("price"),o.getString("start"),o.getString("end"),o.optString("status","ACTIVO"),o.optBoolean("paid",true),o.optString("pin"),o.optLong("accountCost"),o.optString("paymentMethod","Efectivo"),o.optBoolean("contacted",false),o.optString("password",""),o.optString("provider",""),o.optString("providerPhone",""),o.optString("accountEnd",""),o.optLong("accountRenewCost"),o.optString("promiseDate",""),o.optLong("stockId",0),o.optString("lastContact",""),o.optString("purchaseDate",o.optString("start",""))
        )}
    }

    private fun legacyStock():MutableList<StockItem>{
        val masters=JSONArray(p.getString("account_masters","[]"));val slots=JSONArray(p.getString("stock_slots","[]"))
        if(masters.length()>0&&slots.length()>0){
            val map=mutableMapOf<String,AccountMaster>();for(i in 0 until masters.length()){val o=masters.getJSONObject(i);val m=AccountMaster(o.getString("id"),o.optString("service"),o.optString("account"),o.optString("password"),o.optString("type","PERFIL/PANTALLA"),o.optString("provider"),o.optString("providerPhone"),o.optString("accountEnd"),o.optLong("accountCost"),o.optLong("accountRenewCost"),o.optString("purchaseDate"));map[m.id]=m}
            val out=mutableListOf<StockItem>();for(i in 0 until slots.length()){val o=slots.getJSONObject(i);val mid=o.optString("masterId");val m=map[mid]?:continue;out+=StockItem(o.getLong("id"),m.service,m.account,m.password,o.optString("profile"),o.optString("pin"),o.optString("type",m.type),m.provider,m.providerPhone,m.accountEnd,m.accountCost,m.accountRenewCost,o.optString("status","DISPONIBLE"),m.purchaseDate,mid)}
            return out
        }
        val a=JSONArray(p.getString("stock","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);StockItem(
            o.getLong("id"),o.optString("service"),o.optString("account"),o.optString("password"),o.optString("profile"),o.optString("pin"),o.optString("type","PERFIL/PANTALLA"),o.optString("provider"),o.optString("providerPhone"),o.optString("accountEnd"),o.optLong("accountCost"),o.optLong("accountRenewCost"),o.optString("status","DISPONIBLE"),o.optString("purchaseDate",""),o.optString("masterId","")
        )}.map{x->x.copy(masterId=masterIdFor(x))}.toMutableList()
    }

    private fun legacyHist():MutableList<Hist>{val a=JSONArray(p.getString("hist","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Hist(o.getLong("id"),o.getLong("subId"),o.getString("date"),o.getString("action"),o.optLong("amount"),o.optString("method"))}}
    private fun legacyServices():MutableList<ServiceTemplate>{val a=JSONArray(p.getString("services","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);ServiceTemplate(o.getLong("id"),o.optString("name"),o.optString("type","CUENTA COMPLETA"),o.optInt("durationDays",30),o.optLong("defaultPrice"),o.optString("provider"),o.optString("providerPhone"),o.optLong("accountCost"),o.optLong("renewCost"))}}

    private fun ensureMigrated(){
        if(p.getBoolean("room_v7_migrated",false))return
        val oldSubs=legacySubs();val oldStock=legacyStock();val oldHist=legacyHist();val oldServices=legacyServices()
        io{
            if(dao.subscriptionCount()==0&&oldSubs.isNotEmpty())dao.replaceSubscriptions(oldSubs.map(::toEntity))
            if(dao.accountCount()==0&&oldStock.isNotEmpty())writeStockDb(oldStock)
            if(oldHist.isNotEmpty())dao.replaceHistory(oldHist.map{HistoryEntity(it.id,it.subId,it.date,it.action,it.amount,it.method)})
            if(oldServices.isNotEmpty())dao.replaceServices(oldServices.map(::toEntity))
        }
        syncDirectories(oldSubs,oldStock)
        p.edit().putBoolean("room_v7_migrated",true).remove("subs").remove("stock").remove("account_masters").remove("stock_slots").remove("hist").remove("services").commit()
    }

    private fun toEntity(x:Sub)=SubscriptionEntity(x.id,clientKey(x.client,x.phone),x.client,x.phone,x.service,x.account,x.profile,x.type,x.price,x.start,x.end,x.status,x.paid,LocalCrypto.encrypt(c,x.pin),x.accountCost,x.paymentMethod,x.contacted,LocalCrypto.encrypt(c,x.password),providerKey(x.provider),x.provider,x.providerPhone,x.accountEnd,x.accountRenewCost,x.promiseDate,x.stockId,x.lastContact,x.purchaseDate)
    private fun fromEntity(x:SubscriptionEntity)=Sub(x.id,x.client,x.phone,x.service,x.account,x.profile,x.type,x.price,x.start,x.end,x.status,x.paid,LocalCrypto.decrypt(c,x.pin),x.accountCost,x.paymentMethod,x.contacted,LocalCrypto.decrypt(c,x.password),x.provider,x.providerPhone,x.accountEnd,x.accountRenewCost,x.promiseDate,x.stockId,x.lastContact,x.purchaseDate)
    private fun toEntity(x:ServiceTemplate)=ServiceEntity(x.id,x.name,x.type,x.durationDays,x.defaultPrice,x.provider,x.providerPhone,x.accountCost,x.renewCost)
    private fun fromEntity(x:ServiceEntity)=ServiceTemplate(x.id,x.name,x.type,x.durationDays,x.defaultPrice,x.provider,x.providerPhone,x.accountCost,x.renewCost)

    fun subs():MutableList<Sub> =io{dao.getSubscriptions().map(::fromEntity).toMutableList()}
    fun save(items:List<Sub>){
        io{dao.replaceSubscriptions(items.map(::toEntity))};syncDirectories(items,stock());syncReminders(items);autoBackupIfNeeded()
    }

    fun stock():MutableList<StockItem> =io{
        val accounts=dao.getAccounts().associateBy{it.id};dao.getSlots().mapNotNull{x->val a=accounts[x.masterId]?:return@mapNotNull null;StockItem(x.id,a.service,a.account,LocalCrypto.decrypt(c,a.password),x.profile,LocalCrypto.decrypt(c,x.pin),x.type,a.provider,a.providerPhone,a.accountEnd,a.accountCost,a.accountRenewCost,x.status,a.purchaseDate,a.id)}.toMutableList()
    }

    private fun writeStockDb(items:List<StockItem>){
        val normalized=items.map{x->x.copy(masterId=masterIdFor(x))}
        val accounts=normalized.groupBy{it.masterId}.map{(mid,list)->val x=list.first();AccountEntity(mid,x.service,x.account,LocalCrypto.encrypt(c,x.password),normalizedAccessType(x.type,x.profile),providerKey(x.provider),x.provider,x.providerPhone,x.accountEnd,x.accountCost,x.accountRenewCost,x.purchaseDate)}
        val slots=normalized.map{x->SlotEntity(x.id,x.masterId,x.profile,LocalCrypto.encrypt(c,x.pin),x.type,x.status)}
        dao.replaceStock(accounts,slots)
    }

    fun saveStock(items:List<StockItem>){
        io{writeStockDb(items)};syncDirectories(subs(),items);syncReminders(subs());autoBackupIfNeeded()
    }

    fun hist():MutableList<Hist> =io{dao.getHistory().map{Hist(it.id,it.subId,it.date,it.action,it.amount,it.method)}.toMutableList()}
    fun saveHist(h:List<Hist>){io{dao.replaceHistory(h.map{HistoryEntity(it.id,it.subId,it.date,it.action,it.amount,it.method)})};autoBackupIfNeeded()}

    fun services():MutableList<ServiceTemplate> =io{dao.getServices().map(::fromEntity).toMutableList()}
    fun saveServices(items:List<ServiceTemplate>){io{dao.replaceServices(items.map(::toEntity))};autoBackupIfNeeded()}

    fun clients():List<ClientRecord> =io{dao.getClients().map{ClientRecord(it.normalizedKey,it.name,it.phone,it.createdAt)}}
    fun providers():List<ProviderRecord> =io{dao.getProviders().map{ProviderRecord(it.normalizedKey,it.name,it.phone)}}

    private fun syncDirectories(subs:List<Sub>,stock:List<StockItem>){
        val today=LocalDate.now().toString()
        val clients=subs.filter{it.client.isNotBlank()}.groupBy{clientKey(it.client,it.phone)}.map{(k,list)->val x=list.maxByOrNull{it.id}!!;ClientEntity(k,k,x.client.trim(),x.phone,today)}
        val providerRows=(subs.map{Triple(it.provider,it.providerPhone,it.id)}+stock.map{Triple(it.provider,it.providerPhone,it.id)}).filter{it.first.isNotBlank()}.groupBy{providerKey(it.first)}.filterKeys{it.isNotBlank()}.map{(k,list)->val x=list.last();ProviderEntity(k,k,providerDisplayName(x.first),x.second)}
        io{dao.replaceClients(clients);dao.replaceProviders(providerRows)}
    }

    fun templates():Templates{
        val o=runCatching{JSONObject(p.getString("templates","{}")!!)}.getOrDefault(JSONObject());val d=Templates()
        val oldDelivery=o.optString("delivery",d.delivery);val delivery=if(oldDelivery.contains("{password}"))oldDelivery else oldDelivery.replace("Cuenta: {cuenta}","Cuenta: {cuenta}\nContraseña: {password}")
        return Templates(
            due3=o.optString("due3",d.due3),due1=o.optString("due1",d.due1),due0=o.optString("due0",d.due0),expired=o.optString("expired",d.expired),delivery=delivery,
            promise=o.optString("promise",d.promise),provider3=o.optString("provider3",d.provider3),provider1=o.optString("provider1",d.provider1),provider0=o.optString("provider0",d.provider0)
        )
    }
    fun saveTemplates(t:Templates){p.edit().putString("templates",JSONObject().apply{put("due3",t.due3);put("due1",t.due1);put("due0",t.due0);put("expired",t.expired);put("delivery",t.delivery);put("promise",t.promise);put("provider3",t.provider3);put("provider1",t.provider1);put("provider0",t.provider0)}.toString()).apply();syncReminders(subs());autoBackupIfNeeded()}

    private fun buildBackupJson():JSONObject{
        val ss=subs();val st=stock();val hh=hist();val svc=services();val masters=JSONArray();val slots=JSONArray();val stockLegacy=JSONArray();
        st.groupBy{masterIdFor(it)}.forEach{(mid,list)->val x=list.first();masters.put(JSONObject().apply{put("id",mid);put("service",x.service);put("account",x.account);put("password",x.password);put("type",normalizedAccessType(x.type,x.profile));put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountCost",x.accountCost);put("accountRenewCost",x.accountRenewCost);put("purchaseDate",x.purchaseDate)})}
        st.forEach{x->slots.put(JSONObject().apply{put("id",x.id);put("masterId",masterIdFor(x));put("profile",x.profile);put("pin",x.pin);put("type",x.type);put("status",x.status)});stockLegacy.put(JSONObject().apply{put("id",x.id);put("service",x.service);put("account",x.account);put("password",x.password);put("profile",x.profile);put("pin",x.pin);put("type",x.type);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountCost",x.accountCost);put("accountRenewCost",x.accountRenewCost);put("status",x.status);put("purchaseDate",x.purchaseDate);put("masterId",masterIdFor(x))})}
        val subsJson=JSONArray();ss.forEach{x->subsJson.put(JSONObject().apply{put("id",x.id);put("client",x.client);put("phone",x.phone);put("service",x.service);put("account",x.account);put("profile",x.profile);put("type",x.type);put("price",x.price);put("start",x.start);put("end",x.end);put("status",x.status);put("paid",x.paid);put("pin",x.pin);put("accountCost",x.accountCost);put("paymentMethod",x.paymentMethod);put("contacted",x.contacted);put("password",x.password);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountRenewCost",x.accountRenewCost);put("promiseDate",x.promiseDate);put("stockId",x.stockId);put("lastContact",x.lastContact);put("purchaseDate",x.purchaseDate)})}
        val histJson=JSONArray();hh.forEach{x->histJson.put(JSONObject().apply{put("id",x.id);put("subId",x.subId);put("date",x.date);put("action",x.action);put("amount",x.amount);put("method",x.method)})}
        val svcJson=JSONArray();svc.forEach{x->svcJson.put(JSONObject().apply{put("id",x.id);put("name",x.name);put("type",x.type);put("durationDays",x.durationDays);put("defaultPrice",x.defaultPrice);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountCost",x.accountCost);put("renewCost",x.renewCost)})}
        return JSONObject().apply{put("backupVersion",8);put("appVersion",BuildConfig.VERSION_NAME);put("storageEngine","ROOM_V1");put("subs",subsJson);put("stock",stockLegacy);put("account_masters",masters);put("stock_slots",slots);put("hist",histJson);put("templates",JSONObject(p.getString("templates","{}")!!));put("services",svcJson);put("darkMode",darkMode())}
    }
    fun backupPassword():String=LocalCrypto.decrypt(c,p.getString("backup_password","")?:"")
    fun hasBackupPassword():Boolean=backupPassword().length>=6
    fun setBackupPassword(value:String):Boolean{if(value.length<6)return false;p.edit().putString("backup_password",LocalCrypto.encrypt(c,value)).apply();return true}
    fun backup():String{val pass=backupPassword();require(pass.length>=6){"Configura una contraseña de respaldo antes de crear copias"};val json=buildBackupJson().toString(2);return BackupCrypto.encrypt(json,pass)}

    fun restore(text:String,password:String=backupPassword()):Boolean=runCatching{
        val raw=BackupCrypto.decrypt(text,password);val o=JSONObject(raw);val version=o.optInt("backupVersion",1);require(version in 1..8);require(o.has("subs"))
        emergencyBackupBeforeRestore()
        val e=p.edit().putString("subs",o.getJSONArray("subs").toString()).putString("stock",o.optJSONArray("stock")?.toString()?:"[]").putString("hist",o.optJSONArray("hist")?.toString()?:"[]").putString("templates",o.optJSONObject("templates")?.toString()?:"{}").putString("services",o.optJSONArray("services")?.toString()?:"[]");if(o.has("account_masters")&&o.has("stock_slots")){e.putString("account_masters",o.optJSONArray("account_masters")?.toString()?:"[]").putString("stock_slots",o.optJSONArray("stock_slots")?.toString()?:"[]")}else{e.remove("account_masters").remove("stock_slots")};if(o.has("darkMode"))e.putBoolean("dark_mode",o.optBoolean("darkMode",true));e.commit()
        val restoredSubs=legacySubs();val restoredStock=legacyStock();val restoredHist=legacyHist();val restoredServices=legacyServices();io{dao.replaceSubscriptions(restoredSubs.map(::toEntity));writeStockDb(restoredStock);dao.replaceHistory(restoredHist.map{HistoryEntity(it.id,it.subId,it.date,it.action,it.amount,it.method)});dao.replaceServices(restoredServices.map(::toEntity))};syncDirectories(restoredSubs,restoredStock);p.edit().remove("subs").remove("stock").remove("account_masters").remove("stock_slots").remove("hist").remove("services").apply();syncReminders(restoredSubs);autoBackupIfNeeded(true);true
    }.getOrDefault(false)

    fun darkMode():Boolean=p.getBoolean("dark_mode",true)
    fun setDarkMode(value:Boolean){p.edit().putBoolean("dark_mode",value).apply()}
    fun backupFolder():String=p.getString("backup_folder","")?:""
    fun lastAutoBackup():String=p.getString("last_auto_backup","")?:""
    fun setBackupFolder(uri:Uri):Boolean=runCatching{c.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION);p.edit().putString("backup_folder",uri.toString()).putString("last_auto_backup","").commit();autoBackupIfNeeded(true)}.getOrDefault(false)

    private fun emergencyBackupBeforeRestore(){runCatching{if(!hasBackupPassword())return;val raw=backupFolder();if(raw.isBlank())return;val tree=Uri.parse(raw);val docId=DocumentsContract.getTreeDocumentId(tree);val parent=DocumentsContract.buildDocumentUriUsingTree(tree,docId);val out=DocumentsContract.createDocument(c.contentResolver,parent,"application/octet-stream","ControlStreaming_PreRestore_${System.currentTimeMillis()}.nexo")?:return;c.contentResolver.openOutputStream(out)?.bufferedWriter()?.use{it.write(backup())}}}

    fun autoBackupIfNeeded(force:Boolean=false):Boolean=runCatching{
        if(!hasBackupPassword())return false
        val raw=backupFolder();if(raw.isBlank())return false
        val today=LocalDate.now().toString();if(!force&&lastAutoBackup()==today)return true
        val tree=Uri.parse(raw);val docId=DocumentsContract.getTreeDocumentId(tree);val parent=DocumentsContract.buildDocumentUriUsingTree(tree,docId)
        val out=DocumentsContract.createDocument(c.contentResolver,parent,"application/octet-stream","ControlStreaming_Auto_${today}_${System.currentTimeMillis()}.nexo")?:return false
        c.contentResolver.openOutputStream(out)?.bufferedWriter()?.use{it.write(backup())}
        p.edit().putString("last_auto_backup",today).apply();trimAutoBackups(tree);true
    }.getOrDefault(false)

    private fun trimAutoBackups(tree:Uri){runCatching{val parentId=DocumentsContract.getTreeDocumentId(tree);val children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parentId);val rows=mutableListOf<Pair<String,String>>();c.contentResolver.query(children,arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME),null,null,null)?.use{cur->val idIx=cur.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);val nameIx=cur.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);while(cur.moveToNext()){val id=cur.getString(idIx);val name=cur.getString(nameIx);if(name.startsWith("ControlStreaming_Auto_"))rows+=name to id}};rows.sortedByDescending{it.first}.drop(7).forEach{(_,id)->DocumentsContract.deleteDocument(c.contentResolver,DocumentsContract.buildDocumentUriUsingTree(tree,id))}}}

    private fun syncReminders(items:List<Sub>){ReminderScheduler.sync(c,items,stock(),templates())}
}

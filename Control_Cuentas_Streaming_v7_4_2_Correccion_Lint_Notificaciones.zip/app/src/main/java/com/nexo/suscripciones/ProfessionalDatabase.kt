package com.nexo.suscripciones

import android.content.Context
import androidx.room.*

@Entity(tableName="clients", indices=[Index(value=["normalizedKey"], unique=true)])
data class ClientEntity(
    @PrimaryKey val id:String,
    val normalizedKey:String,
    val name:String,
    val phone:String,
    val createdAt:String
)

@Entity(tableName="providers", indices=[Index(value=["normalizedKey"], unique=true)])
data class ProviderEntity(
    @PrimaryKey val id:String,
    val normalizedKey:String,
    val name:String,
    val phone:String
)

@Entity(tableName="accounts")
data class AccountEntity(
    @PrimaryKey val id:String,
    val service:String,
    val account:String,
    val password:String,
    val type:String,
    val providerKey:String,
    val provider:String,
    val providerPhone:String,
    val accountEnd:String,
    val accountCost:Long,
    val accountRenewCost:Long,
    val purchaseDate:String
)

@Entity(
    tableName="slots",
    foreignKeys=[ForeignKey(entity=AccountEntity::class,parentColumns=["id"],childColumns=["masterId"],onDelete=ForeignKey.CASCADE)],
    indices=[Index(value=["masterId"])]
)
data class SlotEntity(
    @PrimaryKey val id:Long,
    val masterId:String,
    val profile:String,
    val pin:String,
    val type:String,
    val status:String
)

@Entity(tableName="subscriptions", indices=[Index(value=["clientKey"]),Index(value=["providerKey"]),Index(value=["stockId"])])
data class SubscriptionEntity(
    @PrimaryKey val id:Long,
    val clientKey:String,
    val client:String,
    val phone:String,
    val service:String,
    val account:String,
    val profile:String,
    val type:String,
    val price:Long,
    val start:String,
    val end:String,
    val status:String,
    val paid:Boolean,
    val pin:String,
    val accountCost:Long,
    val paymentMethod:String,
    val contacted:Boolean,
    val password:String,
    val providerKey:String,
    val provider:String,
    val providerPhone:String,
    val accountEnd:String,
    val accountRenewCost:Long,
    val promiseDate:String,
    val stockId:Long,
    val lastContact:String,
    val purchaseDate:String
)

@Entity(tableName="history", indices=[Index(value=["subId"]),Index(value=["date"])])
data class HistoryEntity(@PrimaryKey val id:Long,val subId:Long,val date:String,val action:String,val amount:Long,val method:String)

@Entity(tableName="service_templates")
data class ServiceEntity(
    @PrimaryKey val id:Long,
    val name:String,
    val type:String,
    val durationDays:Int,
    val defaultPrice:Long,
    val provider:String,
    val providerPhone:String,
    val accountCost:Long,
    val renewCost:Long
)

@Dao
abstract class ProfessionalDao {
    @Query("SELECT * FROM subscriptions ORDER BY id") abstract fun getSubscriptions():List<SubscriptionEntity>
    @Query("DELETE FROM subscriptions") abstract fun clearSubscriptions()
    @Insert(onConflict=OnConflictStrategy.REPLACE) abstract fun insertSubscriptions(items:List<SubscriptionEntity>)
    @Transaction open fun replaceSubscriptions(items:List<SubscriptionEntity>){clearSubscriptions();if(items.isNotEmpty())insertSubscriptions(items)}

    @Query("SELECT * FROM accounts ORDER BY service, account") abstract fun getAccounts():List<AccountEntity>
    @Query("SELECT * FROM slots ORDER BY masterId, id") abstract fun getSlots():List<SlotEntity>
    @Query("DELETE FROM slots") abstract fun clearSlots()
    @Query("DELETE FROM accounts") abstract fun clearAccounts()
    @Insert(onConflict=OnConflictStrategy.REPLACE) abstract fun insertAccounts(items:List<AccountEntity>)
    @Insert(onConflict=OnConflictStrategy.REPLACE) abstract fun insertSlots(items:List<SlotEntity>)
    @Transaction open fun replaceStock(accounts:List<AccountEntity>,slots:List<SlotEntity>){clearSlots();clearAccounts();if(accounts.isNotEmpty())insertAccounts(accounts);if(slots.isNotEmpty())insertSlots(slots)}

    @Query("SELECT * FROM history ORDER BY id") abstract fun getHistory():List<HistoryEntity>
    @Query("DELETE FROM history") abstract fun clearHistory()
    @Insert(onConflict=OnConflictStrategy.REPLACE) abstract fun insertHistory(items:List<HistoryEntity>)
    @Transaction open fun replaceHistory(items:List<HistoryEntity>){clearHistory();if(items.isNotEmpty())insertHistory(items)}

    @Query("SELECT * FROM service_templates ORDER BY name") abstract fun getServices():List<ServiceEntity>
    @Query("DELETE FROM service_templates") abstract fun clearServices()
    @Insert(onConflict=OnConflictStrategy.REPLACE) abstract fun insertServices(items:List<ServiceEntity>)
    @Transaction open fun replaceServices(items:List<ServiceEntity>){clearServices();if(items.isNotEmpty())insertServices(items)}

    @Query("SELECT * FROM clients ORDER BY name") abstract fun getClients():List<ClientEntity>
    @Query("DELETE FROM clients") abstract fun clearClients()
    @Insert(onConflict=OnConflictStrategy.REPLACE) abstract fun insertClients(items:List<ClientEntity>)
    @Transaction open fun replaceClients(items:List<ClientEntity>){clearClients();if(items.isNotEmpty())insertClients(items)}

    @Query("SELECT * FROM providers ORDER BY name") abstract fun getProviders():List<ProviderEntity>
    @Query("DELETE FROM providers") abstract fun clearProviders()
    @Insert(onConflict=OnConflictStrategy.REPLACE) abstract fun insertProviders(items:List<ProviderEntity>)
    @Transaction open fun replaceProviders(items:List<ProviderEntity>){clearProviders();if(items.isNotEmpty())insertProviders(items)}

    @Query("SELECT COUNT(*) FROM subscriptions") abstract fun subscriptionCount():Int
    @Query("SELECT COUNT(*) FROM accounts") abstract fun accountCount():Int
}

@Database(
    entities=[ClientEntity::class,ProviderEntity::class,AccountEntity::class,SlotEntity::class,SubscriptionEntity::class,HistoryEntity::class,ServiceEntity::class],
    version=1,
    exportSchema=false
)
abstract class ProfessionalDatabase:RoomDatabase(){
    abstract fun dao():ProfessionalDao
    companion object{
        @Volatile private var INSTANCE:ProfessionalDatabase?=null
        fun get(context:Context):ProfessionalDatabase=INSTANCE?:synchronized(this){
            INSTANCE?:Room.databaseBuilder(context.applicationContext,ProfessionalDatabase::class.java,"control_streaming_v7.db")
                .build().also{INSTANCE=it}
        }
    }
}

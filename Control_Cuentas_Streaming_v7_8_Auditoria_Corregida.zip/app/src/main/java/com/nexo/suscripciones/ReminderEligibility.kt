package com.nexo.suscripciones

import java.time.LocalDate

/**
 * Evita avisos de ciclos anteriores. Sin efectos secundarios: permite probar
 * renovaciones, cortes, promesas y cambios de fecha sin Android ni alarmas.
 */
object ReminderEligibility {
    fun client(sub: Sub, kind: String, recordedEnd: String, days: Int, today: LocalDate = LocalDate.now()): Boolean {
        val snapshot = BusinessStateEngine.client(sub, today)
        return when (kind) {
            "OVERDUE" -> sub.end == recordedEnd && snapshot.state == ClientOperationState.OVERDUE
            "PROMISE" -> sub.promiseDate == recordedEnd && snapshot.state == ClientOperationState.PROMISE_DUE
            else -> sub.end == recordedEnd && snapshot.daysToEnd == days.toLong() &&
                    snapshot.state !in setOf(ClientOperationState.FINALIZED, ClientOperationState.WAITING)
        }
    }

    fun provider(end: String, kind: String, recordedEnd: String, days: Int, today: LocalDate = LocalDate.now()): Boolean {
        if (end != recordedEnd) return false
        val snapshot = BusinessStateEngine.provider(end, today)
        return if (kind == "PROVIDER_OVERDUE") snapshot.state == ProviderOperationState.OVERDUE
        else snapshot.daysToEnd == days.toLong()
    }
}

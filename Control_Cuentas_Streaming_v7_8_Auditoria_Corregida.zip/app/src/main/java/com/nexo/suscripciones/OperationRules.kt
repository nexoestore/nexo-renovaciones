package com.nexo.suscripciones

import java.time.LocalDate

enum class CoverageStatus { COVERED, MISSING_PROVIDER_DATE, INSUFFICIENT, INVALID }

object OperationRules {
    fun parseDate(value:String):LocalDate? = runCatching { LocalDate.parse(value.trim()) }.getOrNull()

    fun dateRangeValid(start:String,end:String):Boolean {
        val a=parseDate(start)?:return false
        val b=parseDate(end)?:return false
        return !b.isBefore(a)
    }

    fun optionalDateRangeValid(start:String,end:String):Boolean {
        if(start.isBlank()||end.isBlank()) return true
        return dateRangeValid(start,end)
    }

    fun renewalEnd(currentEnd:String,days:Int,today:LocalDate=LocalDate.now()):String {
        val old=parseDate(currentEnd)?:today
        val base=if(old.isBefore(today))today else old
        return base.plusDays(days.coerceAtLeast(1).toLong()).toString()
    }

    fun saleEnd(start:String, days:Int):LocalDate? {
        val initial=parseDate(start)?:return null
        if(days<=0)return null
        return initial.plusDays(days.toLong())
    }

    fun coverageForSale(start:String,days:Int,providerEnd:String):CoverageStatus {
        val saleEnd=saleEnd(start,days)?:return CoverageStatus.INVALID
        if(providerEnd.isBlank())return CoverageStatus.MISSING_PROVIDER_DATE
        val provider=parseDate(providerEnd)?:return CoverageStatus.INVALID
        return if(provider.isBefore(saleEnd))CoverageStatus.INSUFFICIENT else CoverageStatus.COVERED
    }

    fun providerRenewalValid(oldEnd:String,newEnd:String,today:LocalDate=LocalDate.now()):Boolean {
        val newDate=parseDate(newEnd)?:return false
        val previous=parseDate(oldEnd)
        return newDate.isAfter(previous?.takeIf{it.isAfter(today)}?:today)
    }

    fun phoneValidOrBlank(phone:String):Boolean {
        if(phone.isBlank()) return true
        return phone.filter(Char::isDigit).length>=7
    }

    fun uniqueProfileNames(names:List<String>):Boolean {
        val cleaned=names.map{it.trim().lowercase()}.filter{it.isNotBlank()}
        return cleaned.size==cleaned.distinct().size
    }

    fun amount(text:String):Long = text.filter(Char::isDigit).toLongOrNull()?:0L
}

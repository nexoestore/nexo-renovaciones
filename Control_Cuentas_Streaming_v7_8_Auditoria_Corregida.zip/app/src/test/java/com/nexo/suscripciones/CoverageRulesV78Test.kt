package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class CoverageRulesV78Test {
    @Test fun sale_exceeding_provider_date_is_blocked() {
        assertEquals(CoverageStatus.INSUFFICIENT,
            OperationRules.coverageForSale("2026-10-28", 30, "2026-11-01"))
    }
    @Test fun sale_covered_by_provider_is_allowed() {
        assertEquals(CoverageStatus.COVERED,
            OperationRules.coverageForSale("2026-10-28", 30, "2026-12-01"))
    }
    @Test fun missing_or_invalid_dates_never_appear_as_covered() {
        assertEquals(CoverageStatus.MISSING_PROVIDER_DATE,
            OperationRules.coverageForSale("2026-10-28", 30, ""))
        assertEquals(CoverageStatus.INVALID,
            OperationRules.coverageForSale("bad-date", 30, "2026-12-01"))
        assertEquals(CoverageStatus.INVALID,
            OperationRules.coverageForSale("2026-10-28", 0, "2026-12-01"))
    }
    @Test fun renewal_must_advance_provider_end() {
        val today=LocalDate.of(2026,10,28)
        assertTrue(OperationRules.providerRenewalValid("2026-10-25", "2026-11-27", today))
        assertFalse(OperationRules.providerRenewalValid("2026-11-15", "2026-11-15", today))
        assertFalse(OperationRules.providerRenewalValid("2026-11-15", "2026-11-01", today))
    }
    @Test fun existing_paid_client_extension_calculates_from_latest_expiry() {
        assertEquals("2026-11-27",OperationRules.renewalEnd("2026-10-14",30,LocalDate.of(2026,10,28)))
        assertEquals("2026-12-10",OperationRules.renewalEnd("2026-11-10",30,LocalDate.of(2026,10,28)))
    }
}

package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class ReminderEligibilityTest {
    private val today = LocalDate.of(2026, 10, 28)
    private fun client(end:String="2026-10-28",status:String="ACTIVO",promise:String="") = Sub(
        id=42,client="Cliente de prueba",phone="",service="Servicio",account="a",profile="p",
        type="PERFIL/PANTALLA",price=10000,start="2026-09-28",end=end,
        status=status,promiseDate=promise
    )

    @Test fun `aviso de hoy es valido solo para la fecha actual`() {
        assertTrue(ReminderEligibility.client(client(),"CLIENT","2026-10-28",0,today))
        assertFalse(ReminderEligibility.client(client("2026-11-27"),"CLIENT","2026-10-28",0,today))
        assertFalse(ReminderEligibility.client(client(status="CORTADO"),"CLIENT","2026-10-28",0,today))
    }

    @Test fun `un aviso vencido se retira despues de renovar o cortar`() {
        assertTrue(ReminderEligibility.client(client("2026-10-25"),"OVERDUE","2026-10-25",0,today))
        assertFalse(ReminderEligibility.client(client("2026-11-25"),"OVERDUE","2026-10-25",0,today))
        assertFalse(ReminderEligibility.client(client("2026-10-25","CORTADO"),"OVERDUE","2026-10-25",0,today))
    }

    @Test fun `promesa sustituye vencimiento y se valida por fecha`() {
        val s=client("2026-10-25","ESPERA","2026-10-29")
        assertFalse(ReminderEligibility.client(s,"CLIENT","2026-10-25",0,today))
        assertFalse(ReminderEligibility.client(s,"PROMISE","2026-10-29",0,today))
        assertTrue(ReminderEligibility.client(s,"PROMISE","2026-10-29",0,today.plusDays(1)))
    }

    @Test fun `proveedor renovado no recibe aviso del ciclo anterior`() {
        assertTrue(ReminderEligibility.provider("2026-10-25","PROVIDER_OVERDUE","2026-10-25",0,today))
        assertFalse(ReminderEligibility.provider("2026-11-25","PROVIDER_OVERDUE","2026-10-25",0,today))
        assertFalse(ReminderEligibility.provider("2026-11-25","PROVIDER","2026-10-25",0,today))
    }
}

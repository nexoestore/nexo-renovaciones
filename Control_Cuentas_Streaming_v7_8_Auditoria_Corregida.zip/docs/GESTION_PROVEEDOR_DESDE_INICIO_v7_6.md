# Gestión de proveedor desde Inicio — v7.6

Esta versión convierte **Atención proveedor** en una zona de trabajo.

## Desde Inicio
Cada cuenta próxima a vencer o vencida permite:
- abrir WhatsApp del proveedor con un mensaje preparado de consulta de renovación;
- registrar/actualizar el WhatsApp del proveedor si falta;
- renovar la cuenta con nueva fecha y costo;
- revisar clientes activos y accesos libres que dependen de esa cuenta;
- registrar la decisión **No renovar** sin borrar cuenta, clientes ni historial;
- abrir el módulo Proveedores para una revisión completa.

## Seguridad de la decisión
**No renovar** es una decisión operativa, no un borrado.
Si posteriormente se registra una renovación del proveedor, esa renovación pasa a ser la decisión más reciente y reemplaza visualmente el estado anterior.

## Datos
No se cambia el esquema de Room. La actualización mantiene compatibilidad con la base de datos y respaldos actuales.

# Control de Cuentas Streaming v7.8 — Correcciones de auditoría

Proyecto Android basado en el ZIP v7.7 entregado anteriormente. **Es el código fuente para compilar en GitHub Actions, NO una APK lista para instalar.**

## Implementado

1. **Decisión de proveedor «No renovar» unificada.** El contador de Inicio, Proveedores, Reportes y el planificador consultan el mismo estado. La decisión ya no depende de que el nombre del servicio coincida exactamente entre registros heredados; se identifica proveedor + cuenta + vencimiento. No permite registrar la misma decisión dos veces para el mismo ciclo. No se reprograman avisos de ese ciclo, y el sistema cancela los ya visibles cuando dejan de corresponder.
2. **Archivo de cuentas vencidas.** Si la cuenta está vencida, se marcó «No renovar», no tiene clientes activos ni accesos vendibles, se habilita «Cerrar y archivar». La cuenta desaparece de pendientes pero se conserva su historial en Proveedores → Cuentas archivadas. No elimina información ni credenciales guardadas. La acción queda registrada en historial.
3. **Validación de cobertura en ventas.** Las ventas de Stock y las ventas manuales avanzadas se bloquean si falta un vencimiento válido del proveedor o este no cubre la duración del cliente. Muestra la fecha calculada y el motivo del bloqueo. Existe una advertencia de cobertura insuficiente también en la tarjeta de perfiles con clientes activos.
4. **Corte sin reventa insegura.** «No renovó» finaliza al cliente, pero el acceso pasa a «No disponible» en lugar de publicarse inmediatamente como libre. El responsable debe confirmar que revocó el acceso real y que la cuenta del proveedor sigue vigente antes de habilitar el stock. La app NO puede revocar accesos en plataformas externas.
5. **Resguardo frente a doble pulsación.** Se evita cobrar dos veces al reabrir o repetir el mismo ciclo de renovación de proveedor. Se comprueba el vencimiento actual antes de guardar y se generan identificadores únicos de eventos, incluso ante múltiples registros el mismo milisegundo. Las nuevas asignaciones de Stock comprueban que el acceso no tenga ya cliente activo.
6. **Reportes y actividad.** Alerta de *posibles* gastos repetidos de proveedores; no borra ni corrige movimientos previos sin verificar. Actividad de Ajustes ahora se puede filtrar por Dinero, Gestión y Comunicaciones. Contadores de proveedores por atender usan la misma regla que Inicio.
7. **Privacidad y diagnóstico.** Stock oculta la contraseña por defecto. El diagnóstico se etiqueta «básico» y añade advertencias operativas sobre cobertura, fechas de proveedor y pagos sospechosamente repetidos; deja de afirmar que el 100/100 significa aprobación comercial completa.
8. **Avisos y compatibilidad.** Los avisos de proveedores usan una identidad estable por proveedor+cuenta; se cancelan alarmas y notificaciones heredadas al reconciliar los estados. No se alteró el esquema Room ni el `applicationId`.

## Alcance y límites

- No se ha compilado ni ejecutado una APK en un teléfono desde este entorno. Se verificó la sintaxis del archivo UI con el compilador Kotlin sin SDK; sus dependencias Android no están disponibles aquí. La **compilación Android/Compose completa está pendiente** de GitHub Actions.
- Las verificaciones con Kotlin puro de fechas, cobertura y validez de recordatorios pasaron. Se añadieron pruebas JUnit a `app/src/test`.
- Los antiguos registros aparentemente duplicados NO se borran; hay que comprobar que no representen transacciones reales.
- La notificación de WhatsApp sigue siendo un enlace con texto prellenado; no confirma que el mensaje se haya enviado.
- «Cortar» **no revoca de forma remota** perfiles de Disney/Prime/etc.; se bloquea el acceso en el inventario hasta verificarse la revocación externa.
- La gestión multivendedor, la venta de licencias y la publicación en Google Play no se incluyen en v7.8.

## Instalación segura y compilación

- `applicationId` conservado: `com.nexo.suscripciones`.
- `versionCode`: **39**; `versionName`: **7.8**; minSdk 26, targetSdk 36.
- **Antes de actualizar:** crear y conservar un respaldo local cifrado desde Ajustes, y comprobar contraseña/copia en un dispositivo de prueba. No publicar credenciales ni compartir el respaldo en conversaciones.
- Subir el ZIP al repositorio existente, quitando otros ZIP antiguos para que el workflow no extraiga el archivo equivocado. Ejecutar `Control Cuentas Streaming - Compilacion` en Acciones (GitHub Actions).
- Compilar con **la misma clave de firma** que la versión instalada. Si no coincide la firma, no desinstalar la APK anterior para forzar actualización: existe riesgo de perder los datos locales.
- Ver `VALIDACION_v7_8.txt` para lista completa de pruebas en Android antes de reemplazar la v7.7.

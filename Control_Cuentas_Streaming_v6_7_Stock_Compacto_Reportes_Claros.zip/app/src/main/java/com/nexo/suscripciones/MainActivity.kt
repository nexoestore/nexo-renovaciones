package com.nexo.suscripciones

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Sub(
    val id:Long=System.currentTimeMillis(), val client:String, val phone:String, val service:String,
    val account:String, val profile:String, val type:String, val price:Long, val start:String, val end:String,
    val status:String="ACTIVO", val paid:Boolean=true, val pin:String="", val accountCost:Long=0,
    val paymentMethod:String="Efectivo", val contacted:Boolean=false, val password:String="",
    val provider:String="", val providerPhone:String="", val accountEnd:String="", val accountRenewCost:Long=0,
    val promiseDate:String="", val stockId:Long=0, val lastContact:String="", val purchaseDate:String=""
)
data class StockItem(
    val id:Long=System.currentTimeMillis(), val service:String, val account:String, val password:String="",
    val profile:String="", val pin:String="", val type:String="PERFIL/PANTALLA", val provider:String="",
    val providerPhone:String="", val accountEnd:String="", val accountCost:Long=0, val accountRenewCost:Long=0,
    val status:String="DISPONIBLE", val purchaseDate:String=""
)
data class Hist(val id:Long=System.currentTimeMillis(),val subId:Long,val date:String,val action:String,val amount:Long=0,val method:String="")
data class Templates(
    val due3:String="Hola {cliente} 👋 Tu servicio {servicio} vence el {fecha}. Valor de renovación: ${'$'}{precio}.",
    val due1:String="Hola {cliente} 👋 Tu servicio {servicio} vence mañana ({fecha}). Valor: ${'$'}{precio}.",
    val due0:String="Hola {cliente} 👋 Tu servicio {servicio} vence hoy ({fecha}). Si deseas continuar, puedes renovar por ${'$'}{precio}.",
    val expired:String="Hola {cliente} 👋 Tu servicio {servicio} venció el {fecha}. Si deseas reactivarlo, escríbeme para renovar.",
    val delivery:String="Hola {cliente} 👋 Aquí tienes tus datos de {servicio}:\nCuenta: {cuenta}\nContraseña: {password}\nPerfil: {perfil}\nPIN/clave: {pin}\nVence: {fecha}\nGracias por preferir Nexo."
)
data class ServiceTemplate(
    val id:Long=System.currentTimeMillis(), val name:String, val type:String="CUENTA COMPLETA", val durationDays:Int=30,
    val defaultPrice:Long=0, val provider:String="", val providerPhone:String="", val accountCost:Long=0,
    val renewCost:Long=0
)
data class ProviderAccountSummary(
    val provider:String, val phone:String, val service:String, val account:String, val type:String,
    val cost:Long, val renewCost:Long, val purchaseDate:String, val end:String, val status:String,
    val income:Long, val renewSpent:Long, val subIds:List<Long>
)

class Store(private val c:Context){
 private val p=c.getSharedPreferences("nexo_db",Context.MODE_PRIVATE)
 fun subs():MutableList<Sub>{
  val a=JSONArray(p.getString("subs","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Sub(
   o.getLong("id"),o.getString("client"),o.optString("phone"),o.getString("service"),o.optString("account"),o.optString("profile"),o.optString("type","PERFIL"),o.optLong("price"),o.getString("start"),o.getString("end"),o.optString("status","ACTIVO"),o.optBoolean("paid",true),o.optString("pin"),o.optLong("accountCost"),o.optString("paymentMethod","Efectivo"),o.optBoolean("contacted",false),o.optString("password",""),o.optString("provider",""),o.optString("providerPhone",""),o.optString("accountEnd",""),o.optLong("accountRenewCost"),o.optString("promiseDate",""),o.optLong("stockId",0),o.optString("lastContact",""),o.optString("purchaseDate",o.optString("start",""))
  )}
 }
 fun save(items:List<Sub>){
  val a=JSONArray();items.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("client",x.client);put("phone",x.phone);put("service",x.service);put("account",x.account);put("profile",x.profile);put("type",x.type);put("price",x.price);put("start",x.start);put("end",x.end);put("status",x.status);put("paid",x.paid);put("pin",x.pin);put("accountCost",x.accountCost);put("paymentMethod",x.paymentMethod);put("contacted",x.contacted);put("password",x.password);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountRenewCost",x.accountRenewCost);put("promiseDate",x.promiseDate);put("stockId",x.stockId);put("lastContact",x.lastContact);put("purchaseDate",x.purchaseDate)})}
  p.edit().putString("subs",a.toString()).apply();ReminderScheduler.sync(c,items);autoBackupIfNeeded()
 }
 fun stock():MutableList<StockItem>{val a=JSONArray(p.getString("stock","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);StockItem(o.getLong("id"),o.optString("service"),o.optString("account"),o.optString("password"),o.optString("profile"),o.optString("pin"),o.optString("type","PERFIL/PANTALLA"),o.optString("provider"),o.optString("providerPhone"),o.optString("accountEnd"),o.optLong("accountCost"),o.optLong("accountRenewCost"),o.optString("status","DISPONIBLE"),o.optString("purchaseDate",""))}}
 fun saveStock(items:List<StockItem>){val a=JSONArray();items.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("service",x.service);put("account",x.account);put("password",x.password);put("profile",x.profile);put("pin",x.pin);put("type",x.type);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountCost",x.accountCost);put("accountRenewCost",x.accountRenewCost);put("status",x.status);put("purchaseDate",x.purchaseDate)})};p.edit().putString("stock",a.toString()).apply();autoBackupIfNeeded()}
 fun hist():MutableList<Hist>{val a=JSONArray(p.getString("hist","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Hist(o.getLong("id"),o.getLong("subId"),o.getString("date"),o.getString("action"),o.optLong("amount"),o.optString("method"))}}
 fun saveHist(h:List<Hist>){val a=JSONArray();h.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("subId",x.subId);put("date",x.date);put("action",x.action);put("amount",x.amount);put("method",x.method)})};p.edit().putString("hist",a.toString()).apply();autoBackupIfNeeded()}
 fun templates():Templates{val o=runCatching{JSONObject(p.getString("templates","{}")!!)}.getOrDefault(JSONObject());val d=Templates();val oldDelivery=o.optString("delivery",d.delivery);val delivery=if(oldDelivery.contains("{password}"))oldDelivery else oldDelivery.replace("Cuenta: {cuenta}","Cuenta: {cuenta}\nContraseña: {password}");return Templates(o.optString("due3",d.due3),o.optString("due1",d.due1),o.optString("due0",d.due0),o.optString("expired",d.expired),delivery)}
 fun saveTemplates(t:Templates){p.edit().putString("templates",JSONObject().apply{put("due3",t.due3);put("due1",t.due1);put("due0",t.due0);put("expired",t.expired);put("delivery",t.delivery)}.toString()).apply();autoBackupIfNeeded()}
 fun services():MutableList<ServiceTemplate>{val a=JSONArray(p.getString("services","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);ServiceTemplate(o.getLong("id"),o.optString("name"),o.optString("type","CUENTA COMPLETA"),o.optInt("durationDays",30),o.optLong("defaultPrice"),o.optString("provider"),o.optString("providerPhone"),o.optLong("accountCost"),o.optLong("renewCost"))}}
 fun saveServices(items:List<ServiceTemplate>){val a=JSONArray();items.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("name",x.name);put("type",x.type);put("durationDays",x.durationDays);put("defaultPrice",x.defaultPrice);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountCost",x.accountCost);put("renewCost",x.renewCost)})};p.edit().putString("services",a.toString()).apply();autoBackupIfNeeded()}
 fun backup():String=JSONObject().apply{put("backupVersion",5);put("appVersion","6.7");put("subs",JSONArray(p.getString("subs","[]")));put("stock",JSONArray(p.getString("stock","[]")));put("hist",JSONArray(p.getString("hist","[]")));put("templates",JSONObject(p.getString("templates","{}")!!));put("services",JSONArray(p.getString("services","[]")));put("darkMode",darkMode())}.toString(2)
 fun restore(text:String):Boolean=runCatching{val o=JSONObject(text);val e=p.edit().putString("subs",o.getJSONArray("subs").toString()).putString("stock",o.optJSONArray("stock")?.toString()?:"[]").putString("hist",o.optJSONArray("hist")?.toString()?:"[]").putString("templates",o.optJSONObject("templates")?.toString()?:"{}").putString("services",o.optJSONArray("services")?.toString()?:"[]");if(o.has("darkMode"))e.putBoolean("dark_mode",o.optBoolean("darkMode",true));e.commit();ReminderScheduler.sync(c,subs());autoBackupIfNeeded(true);true}.getOrDefault(false)
 fun darkMode():Boolean=p.getBoolean("dark_mode",true)
 fun setDarkMode(value:Boolean){p.edit().putBoolean("dark_mode",value).apply()}
 fun backupFolder():String=p.getString("backup_folder","")?:""
 fun lastAutoBackup():String=p.getString("last_auto_backup","")?:""
 fun setBackupFolder(uri:Uri):Boolean=runCatching{
  c.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
  p.edit().putString("backup_folder",uri.toString()).putString("last_auto_backup","").commit();autoBackupIfNeeded(true)
 }.getOrDefault(false)
 fun autoBackupIfNeeded(force:Boolean=false):Boolean=runCatching{
  val raw=backupFolder();if(raw.isBlank())return false
  val today=LocalDate.now().toString();if(!force&&lastAutoBackup()==today)return true
  val tree=Uri.parse(raw);val docId=DocumentsContract.getTreeDocumentId(tree);val parent=DocumentsContract.buildDocumentUriUsingTree(tree,docId)
  val out=DocumentsContract.createDocument(c.contentResolver,parent,"application/octet-stream","ControlStreaming_Auto_${today}_${System.currentTimeMillis()}.nexo")?:return false
  c.contentResolver.openOutputStream(out)?.bufferedWriter()?.use{it.write(backup())}
  p.edit().putString("last_auto_backup",today).apply();trimAutoBackups(tree);true
 }.getOrDefault(false)
 private fun trimAutoBackups(tree:Uri){runCatching{
  val parentId=DocumentsContract.getTreeDocumentId(tree);val children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parentId)
  val rows=mutableListOf<Pair<String,String>>()
  c.contentResolver.query(children,arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME),null,null,null)?.use{cur->val idIx=cur.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);val nameIx=cur.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);while(cur.moveToNext()){val id=cur.getString(idIx);val name=cur.getString(nameIx);if(name.startsWith("ControlStreaming_Auto_"))rows+=name to id}}
  rows.sortedByDescending{it.first}.drop(7).forEach{(_,id)->DocumentsContract.deleteDocument(c.contentResolver,DocumentsContract.buildDocumentUriUsingTree(tree,id))}
 }}
}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);ReminderScheduler.sync(this,Store(this).subs());if(android.os.Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),1001);setContent{NexoApp()}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun NexoApp(){
 val c=LocalContext.current
 val st=remember{Store(c)}
 var subs by remember{mutableStateOf(st.subs().toList())}
 var hist by remember{mutableStateOf(st.hist().toList())}
 var stock by remember{mutableStateOf(st.stock().toList())}
 var services by remember{mutableStateOf(st.services().toList())}
 var templates by remember{mutableStateOf(st.templates())}
 var tab by remember{mutableIntStateOf(0)}
 var add by remember{mutableStateOf(false)}
 var dark by remember{mutableStateOf(st.darkMode())}
 var editing by remember{mutableStateOf<Sub?>(null)}
 var searchOpen by remember{mutableStateOf(false)}
 fun persist(items:List<Sub>){subs=items;st.save(items)}
 fun persistStock(items:List<StockItem>){stock=items;st.saveStock(items)}
 fun persistServices(items:List<ServiceTemplate>){services=items;st.saveServices(items)}
 fun log(id:Long,a:String,m:Long=0,method:String=""){hist=hist+Hist(subId=id,date=LocalDate.now().toString(),action=a,amount=m,method=method);st.saveHist(hist);st.autoBackupIfNeeded(true)}
 fun contact(s:Sub){val date=LocalDate.now().toString();persist(subs.map{if(it.id==s.id)it.copy(contacted=true,lastContact=date)else it});log(s.id,"CONTACTADO POR WHATSAPP")}
 fun renew(s:Sub){val old=LocalDate.parse(s.end);val base=if(old.isBefore(LocalDate.now()))LocalDate.now() else old;persist(subs.map{if(it.id==s.id)it.copy(end=base.plusDays(30).toString(),status="ACTIVO",paid=true,contacted=false,promiseDate="")else it});log(s.id,"RENOVACIÓN +30 DÍAS",s.price,s.paymentMethod)}
 fun cut(s:Sub,reason:String){
  persist(subs.map{if(it.id==s.id)it.copy(status="CORTADO",contacted=true,promiseDate="")else it})
  if(s.stockId>0){persistStock(stock.map{if(it.id==s.stockId)it.copy(status="DISPONIBLE")else it})}
  else if(s.account.isNotBlank()&&stock.none{it.account==s.account&&it.profile==s.profile&&effectiveStockStatus(it)=="DISPONIBLE"}){
   persistStock(stock+StockItem(service=s.service,account=s.account,password=s.password,profile=s.profile,pin=s.pin,type=normalizedAccessType(s.type,s.profile),provider=s.provider,providerPhone=s.providerPhone,accountEnd=s.accountEnd,accountCost=s.accountCost,accountRenewCost=s.accountRenewCost,status="DISPONIBLE",purchaseDate=s.purchaseDate))
  }
  log(s.id,"BAJA • $reason • ${s.service} • ACCESO LIBERADO")
 }
 fun promise(s:Sub,date:String){persist(subs.map{if(it.id==s.id)it.copy(status="ESPERA",promiseDate=date)else it});log(s.id,"PROMESA DE PAGO • $date")}
 fun adjustEnd(s:Sub,newEnd:String,reason:String){val old=s.end;persist(subs.map{if(it.id==s.id)it.copy(end=newEnd,status="ACTIVO")else it});log(s.id,"AJUSTE VENCIMIENTO: $old → $newEnd${if(reason.isNotBlank())" • $reason" else ""}")}
 fun updateSub(updated:Sub){val clean=updated.copy(provider=normalizedProviderStorage(updated.provider));persist(subs.map{if(it.id==clean.id)clean else it});if(clean.stockId>0)persistStock(stock.map{if(it.id==clean.stockId)it.copy(service=clean.service,account=clean.account,password=clean.password,profile=clean.profile,pin=clean.pin,type=normalizedAccessType(clean.type,clean.profile),provider=clean.provider,providerPhone=clean.providerPhone,accountEnd=clean.accountEnd,accountCost=clean.accountCost,accountRenewCost=clean.accountRenewCost,purchaseDate=clean.purchaseDate)else it});log(clean.id,"EDICIÓN DE ENTREGA / CUENTA")}
 fun addStockItem(item:StockItem){val clean=item.copy(provider=normalizedProviderStorage(item.provider));persistStock(stock+clean);log(0L,"COMPRA STOCK • ${clean.provider.ifBlank{"Sin proveedor"}} • ${clean.service} • ${clean.account}",clean.accountCost,"Proveedor")}
 fun renewProvider(a:ProviderAccountSummary,newEnd:String,cost:Long){
  persist(subs.map{if(sameProvider(it.provider,a.provider)&&accountKey(it.account)==accountKey(a.account))it.copy(accountEnd=newEnd,accountRenewCost=cost,provider=normalizedProviderStorage(it.provider))else it})
  persistStock(stock.map{if(sameProvider(it.provider,a.provider)&&accountKey(it.account)==accountKey(a.account))it.copy(accountEnd=newEnd,accountRenewCost=cost,provider=normalizedProviderStorage(it.provider))else it})
  log(0L,"RENOVACIÓN PROVEEDOR • ${normalizedProviderStorage(a.provider)} • ${a.account} • $newEnd",cost,"Proveedor")
 }
 val streamDark=darkColorScheme(primary=StreamCyan,secondary=StreamBlue,tertiary=StreamAmber,background=Color(0xFF06111A),surface=Color(0xFF0A1823),surfaceVariant=Color(0xFF102536),outline=Color(0xFF3D6074),outlineVariant=Color(0xFF183447),onBackground=Color(0xFFF5FAFC),onSurface=Color(0xFFF5FAFC),onSurfaceVariant=Color(0xFFB8C7D1))
 val streamLight=lightColorScheme(primary=Color(0xFF007F8F),secondary=Color(0xFF1769E0),tertiary=Color(0xFF9B5D00),surfaceVariant=Color(0xFFE8F1F7))
 val appShapes=Shapes(small=RoundedCornerShape(12.dp),medium=RoundedCornerShape(18.dp),large=RoundedCornerShape(24.dp))
 MaterialTheme(colorScheme=if(dark)streamDark else streamLight,shapes=appShapes){
  Scaffold(
   containerColor=MaterialTheme.colorScheme.background,
   topBar={TopAppBar(title={BrandTitle()},actions={IconButton({searchOpen=true}){Icon(Icons.Default.Search,contentDescription="Buscar")};IconButton({tab=5}){Icon(Icons.Default.Settings,contentDescription="Ajustes")}},colors=TopAppBarDefaults.topAppBarColors(containerColor=MaterialTheme.colorScheme.background))},
   floatingActionButton={if(tab==0)ExtendedFloatingActionButton(onClick={add=true},containerColor=StreamCyan,contentColor=Color(0xFF001317),icon={Icon(Icons.Default.Inventory2,contentDescription=null)},text={Text("Nueva venta",fontWeight=FontWeight.Bold)})},
   bottomBar={NavigationBar(containerColor=MaterialTheme.colorScheme.surface){val labels=listOf("Inicio","Renovar","Stock","Proveedores","Reportes");val navIcons=listOf(Icons.Default.Home,Icons.Default.Refresh,Icons.Default.Inventory2,Icons.Default.Groups,Icons.Default.BarChart);labels.forEachIndexed{i,x->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(navIcons[i],contentDescription=x)},label={Text(x,fontSize=10.sp,maxLines=1)},colors=NavigationBarItemDefaults.colors(selectedIconColor=StreamCyan,selectedTextColor=StreamCyan,indicatorColor=StreamPurple.copy(alpha=.22f)))}}}
  ){pad->Box(Modifier.padding(pad)){when(tab){
   0->Home(subs,stock,hist,services,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,::contact,{editing=it})
   1->Renewals(subs,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,::contact,{editing=it})
   2->Accounts(subs,stock,hist,services,::persistStock,::addStockItem,{sold,item->val clean=sold.copy(provider=normalizedProviderStorage(sold.provider));persist(subs+clean);persistStock(stock.map{if(it.id==item.id)it.copy(status=if(isComplete(item))"ENTREGADA" else "OCUPADO")else it});log(clean.id,"VENTA / PAGO DESDE STOCK",clean.price,clean.paymentMethod);wa(c,clean,fillTemplate(templates.delivery,clean))},::adjustEnd,{editing=it})
   3->Providers(subs,stock,hist,::renewProvider)
   4->Reports(subs,stock,hist)
   else->More(subs,stock,hist,services,::persistServices,dark,{dark=it;st.setDarkMode(it)},templates,{templates=it;st.saveTemplates(it)},st,{subs=st.subs();hist=st.hist();stock=st.stock();services=st.services()})
  }}}
  if(add)AddDialog(services,{add=false}){x->val clean=x.copy(provider=normalizedProviderStorage(x.provider));persist(subs+clean);log(clean.id,"VENTA / PAGO",clean.price,clean.paymentMethod);wa(c,clean,fillTemplate(templates.delivery,clean));add=false}
  editing?.let{current->EditSubDialog(current,{editing=null}){updated->updateSub(updated);editing=null}}
  if(searchOpen)GlobalSearchDialog(subs,stock,templates,{searchOpen=false},{sub->wa(c,sub,fillTemplate(templates.delivery,sub))},{sub->searchOpen=false;editing=sub})
 }
}

val StreamCyan=Color(0xFF19E6E6)
val StreamBlue=Color(0xFF1E88FF)
val StreamGreen=Color(0xFF25D97B)
val StreamYellow=Color(0xFFFFD43B)
val StreamAmber=Color(0xFFFFA31A)
val StreamRed=Color(0xFFFF4052)
val StreamPurple=Color(0xFF9A63FF)

@Composable fun BrandTitle(){
 Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(9.dp)){
  Surface(shape=RoundedCornerShape(12.dp),color=StreamCyan.copy(alpha=.10f),border=BorderStroke(1.dp,StreamCyan.copy(alpha=.65f))){
   Box(Modifier.size(38.dp),contentAlignment=Alignment.Center){Text("N",color=StreamCyan,fontWeight=FontWeight.Black,style=MaterialTheme.typography.titleLarge)}
  }
  Column(verticalArrangement=Arrangement.spacedBy(1.dp)){
   Text("NEXO DIGITAL",style=MaterialTheme.typography.titleSmall,fontWeight=FontWeight.Black,maxLines=1)
   Text("Control Streaming",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
  }
 }
}

@Composable fun RenewalChip(label:String,count:Int,color:Color){
 Surface(shape=RoundedCornerShape(14.dp),color=color.copy(alpha=.12f),border=BorderStroke(1.dp,color.copy(alpha=.65f))){
  Column(Modifier.padding(horizontal=13.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){
   Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
   Text(count.toString(),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,color=color)
  }
 }
}

fun normalizedAccessType(type:String,profile:String=""):String{val u=type.uppercase();return if(u.contains("CUENTA COMPLETA")||(u.contains("CORREO/CONTRASEÑA")&&profile.isBlank()))"CUENTA COMPLETA" else "PERFIL/PANTALLA"}
fun isComplete(s:Sub)=normalizedAccessType(s.type,s.profile)=="CUENTA COMPLETA"
fun isComplete(x:StockItem)=normalizedAccessType(x.type,x.profile)=="CUENTA COMPLETA"

fun days(s:Sub)=ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.end))
fun accountDays(s:Sub)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.accountEnd))}.getOrDefault(999)
fun effectiveStockStatus(x:StockItem):String{val expired=x.accountEnd.isNotBlank()&&runCatching{LocalDate.parse(x.accountEnd).isBefore(LocalDate.now())}.getOrDefault(false);return if(expired)"NO_DISPONIBLE" else x.status}
fun stockAccountDays(x:StockItem)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(x.accountEnd))}.getOrDefault(999)
fun money(v:Long)="$${"%,d".format(v)}"
fun providerDisplayName(raw:String):String{
 val t=raw.trim();if(t.isBlank())return "Sin datos"
 val looksDomain=!t.contains(" ")&&t.contains(".")
 val uriText=if(t.startsWith("http://",true)||t.startsWith("https://",true))t else if(looksDomain)"https://$t" else ""
 if(uriText.isNotBlank()){val host=runCatching{Uri.parse(uriText).host?.removePrefix("www.")}.getOrNull().orEmpty();if(host.isNotBlank()){val base=host.substringBefore(".");return if(base.length<=5)base.uppercase() else base.replace("-"," ").split(" ").filter{it.isNotBlank()}.joinToString(" "){it.replaceFirstChar{c->c.uppercase()}}}}
 return t.trim().replace(Regex("\\s+")," ")
}
fun providerKey(raw:String):String{
 val display=providerDisplayName(raw).trim().lowercase()
 return display.replace(Regex("[^a-z0-9áéíóúüñ]"),"")
}
fun sameProvider(a:String,b:String):Boolean{val ka=providerKey(a);val kb=providerKey(b);return ka.isNotBlank()&&ka==kb}
fun accountKey(raw:String)=raw.trim().lowercase()
fun normalizedProviderStorage(raw:String):String{val d=providerDisplayName(raw);return if(d=="Sin datos")"" else d}
fun contactLabel(last:String):String{if(last.isBlank())return "CONTACTADO";val d=runCatching{LocalDate.parse(last)}.getOrNull()?:return "CONTACTADO";val today=LocalDate.now();if(d==today)return "CONTACTADO HOY";if(d==today.minusDays(1))return "CONTACTADO AYER";val m=listOf("ENE","FEB","MAR","ABR","MAY","JUN","JUL","AGO","SEP","OCT","NOV","DIC");return "CONTACTADO ${d.dayOfMonth} ${m[d.monthValue-1]}"}
fun monthPrefix():String=LocalDate.now().toString().take(7)
fun isSaleIncome(x:Hist)=x.action.contains("VENTA")||x.action.contains("RENOVACIÓN +30")
fun activityOwner(x:Hist,s:List<Sub>):String{if(x.subId!=0L)return s.find{it.id==x.subId}?.client?:"Cliente";val parts=x.action.split(" • ");return when{x.action.contains("PROVEEDOR")->providerDisplayName(parts.getOrNull(1)?:"Proveedor");x.action.contains("COMPRA STOCK")->providerDisplayName(parts.getOrNull(1)?:"Stock");else->"Operación"}}
fun providerAccounts(s:List<Sub>,stock:List<StockItem>,h:List<Hist>):List<ProviderAccountSummary>{
 val keys=(s.filter{it.provider.isNotBlank()&&it.account.isNotBlank()}.map{providerKey(it.provider) to accountKey(it.account)}+stock.filter{it.provider.isNotBlank()&&it.account.isNotBlank()}.map{providerKey(it.provider) to accountKey(it.account)}).filter{it.first.isNotBlank()&&it.second.isNotBlank()}.distinct()
 return keys.map{(pk,ak)->
  val ss=s.filter{providerKey(it.provider)==pk&&accountKey(it.account)==ak};val xs=stock.filter{providerKey(it.provider)==pk&&accountKey(it.account)==ak};val sub=ss.firstOrNull();val item=xs.firstOrNull()
  val rawProviders=(ss.map{it.provider}+xs.map{it.provider}).filter{it.isNotBlank()};val provider=rawProviders.minByOrNull{if(it.startsWith("http",true)||it.contains("."))1 else 0}?.let{normalizedProviderStorage(it)}?:pk
  val account=(ss.map{it.account}+xs.map{it.account}).firstOrNull{it.isNotBlank()}?:ak
  val subIds=ss.map{it.id};val income=h.filter{it.subId in subIds&&isSaleIncome(it)}.sumOf{it.amount}
  val renewSpent=h.filter{ev->if(!ev.action.contains("RENOVACIÓN PROVEEDOR"))false else{val parts=ev.action.split(" • ");parts.size>=3&&providerKey(parts[1])==pk&&accountKey(parts[2])==ak}}.sumOf{it.amount}
  val end=(ss.map{it.accountEnd}+xs.map{it.accountEnd}).firstOrNull{it.isNotBlank()}?:"";val purchase=(xs.map{it.purchaseDate}+ss.map{it.purchaseDate}+ss.map{it.start}).firstOrNull{it.isNotBlank()}?:""
  val cost=(ss.map{it.accountCost}+xs.map{it.accountCost}).maxOrNull()?:0L;val renewCost=(ss.map{it.accountRenewCost}+xs.map{it.accountRenewCost}).maxOrNull()?:0L
  val active=ss.any{it.status!="CORTADO"};val available=xs.any{effectiveStockStatus(it)=="DISPONIBLE"};val expired=end.isNotBlank()&&runCatching{LocalDate.parse(end).isBefore(LocalDate.now())}.getOrDefault(false);val status=when{expired->"VENCIDA";active->"ACTIVA";available->"STOCK";else->"NO DISPONIBLE"}
  ProviderAccountSummary(provider,item?.providerPhone?:sub?.providerPhone?:"",item?.service?:sub?.service?:"Servicio",account,item?.type?:sub?.type?:"CUENTA COMPLETA",cost,renewCost,purchase,end,status,income,renewSpent,subIds)
 }
}
fun monthlyAccountCosts(s:List<Sub>,stock:List<StockItem>):Long{
 val month=monthPrefix();val keys=(s.filter{it.provider.isNotBlank()&&it.account.isNotBlank()}.map{providerKey(it.provider) to accountKey(it.account)}+stock.filter{it.provider.isNotBlank()&&it.account.isNotBlank()}.map{providerKey(it.provider) to accountKey(it.account)}).distinct()
 return keys.sumOf{(pk,ak)->val ss=s.filter{providerKey(it.provider)==pk&&accountKey(it.account)==ak};val xs=stock.filter{providerKey(it.provider)==pk&&accountKey(it.account)==ak};val d=(xs.map{it.purchaseDate}+ss.map{it.purchaseDate}+ss.map{it.start}).firstOrNull{it.isNotBlank()}?:"";if(d.startsWith(month))(ss.map{it.accountCost}+xs.map{it.accountCost}).maxOrNull()?:0L else 0L}
}
fun fillTemplate(t:String,s:Sub):String{
 val values=mapOf("{cliente}" to s.client,"{servicio}" to s.service,"{fecha}" to s.end,"{precio}" to money(s.price),"{cuenta}" to s.account,"{perfil}" to s.profile,"{pin}" to s.pin,"{password}" to s.password)
 val optional=setOf("{cuenta}","{password}","{perfil}","{pin}")
 return t.lines()
  .filterNot{line->optional.any{key->line.contains(key)&&values[key].isNullOrBlank()}}
  .map{line->values.entries.fold(line){acc,(k,v)->acc.replace(k,v)}}
  .joinToString("\n")
  .replace(Regex("\n{3,}"),"\n\n")
  .trim()
}
fun messageFor(s:Sub,t:Templates):String=fillTemplate(when{days(s)<0->t.expired;days(s)==0L->t.due0;days(s)==1L->t.due1;else->t.due3},s)
fun wa(c:Context,s:Sub,msg:String){val u="https://wa.me/${s.phone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun ScreenHeader(title:String,subtitle:String){Column(verticalArrangement=Arrangement.spacedBy(4.dp)){Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black);Text(subtitle,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun SectionTitle(title:String,subtitle:String=""){Column(Modifier.padding(top=4.dp,bottom=2.dp)){Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);if(subtitle.isNotBlank())Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun MetricCard(label:String,value:String,accent:Color,modifier:Modifier=Modifier,icon:ImageVector?=null){
 val shape=RoundedCornerShape(18.dp)
 Card(modifier.border(1.dp,accent.copy(alpha=.45f),shape),shape=shape,colors=CardDefaults.cardColors(containerColor=accent.copy(alpha=.10f))){
  Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
   if(icon!=null)Surface(shape=RoundedCornerShape(50),color=accent.copy(alpha=.18f)){Box(Modifier.size(38.dp),contentAlignment=Alignment.Center){Icon(icon,contentDescription=null,tint=accent,modifier=Modifier.size(22.dp))}}
   Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(value,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Black,color=accent,maxLines=1);Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurface,maxLines=2)}
  }
 }
}
@Composable fun InfoBanner(title:String,body:String,accent:Color=StreamCyan){Surface(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),color=accent.copy(alpha=.09f)){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){Text(title,fontWeight=FontWeight.Bold,color=accent);Text(body,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
@Composable fun StatusBadge(label:String,color:Color){Surface(shape=RoundedCornerShape(50),color=color.copy(alpha=.16f),contentColor=color,border=BorderStroke(1.dp,color.copy(alpha=.40f))){Text(label,Modifier.padding(horizontal=9.dp,vertical=4.dp),style=MaterialTheme.typography.labelSmall,fontWeight=FontWeight.Bold)}}
@Composable fun EmptyState(text:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.35f))){Text(text,Modifier.padding(16.dp),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun InsightRow(label:String,value:String,accent:Color=MaterialTheme.colorScheme.onSurface,detail:String=""){Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(3.dp)){Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,color=accent,maxLines=2);if(detail.isNotBlank())Text(detail,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}

@Composable fun Home(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,services:List<ServiceTemplate>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val active=s.filter{it.status!="CORTADO"};val today=active.count{days(it)==0L};val expired=active.count{days(it)<0};val available=stock.count{effectiveStockStatus(it)=="DISPONIBLE"}
 val accounts=providerAccounts(s,stock,h);val providerDue=accounts.count{it.end.isNotBlank()&&runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(it.end)) in 0..3}.getOrDefault(false)}
 val month=monthPrefix();val salesMonth=h.filter{it.date.startsWith(month)&&isSaleIncome(it)}.sumOf{it.amount};val providerRenewMonth=h.filter{it.date.startsWith(month)&&it.action.contains("RENOVACIÓN PROVEEDOR")}.sumOf{it.amount};val costsMonth=monthlyAccountCosts(s,stock)+providerRenewMonth;val profitMonth=salesMonth-costsMonth
 val toCollect=active.filter{days(it)<=3||it.status=="ESPERA"}.sumOf{it.price};val promiseDue=active.count{it.status=="ESPERA"&&it.promiseDate.isNotBlank()&&runCatching{!LocalDate.parse(it.promiseDate).isAfter(LocalDate.now())}.getOrDefault(false)};val work=active.filter{days(it)<=3||it.status=="ESPERA"}.distinctBy{it.id}.sortedBy{it.end}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Operación de hoy","Mira primero lo que requiere atención")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){MetricCard("Clientes vencidos",expired.toString(),StreamRed,Modifier.weight(1f),Icons.Default.Warning);MetricCard("Vencen hoy",today.toString(),StreamYellow,Modifier.weight(1f),Icons.Default.Event)}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){MetricCard("Accesos disponibles",available.toString(),StreamBlue,Modifier.weight(1f),Icons.Default.Inventory2);MetricCard("Cuentas por vencer",providerDue.toString(),StreamAmber,Modifier.weight(1f),Icons.Default.Event)}}
  item{SectionTitle("Dinero","Tu negocio en números")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){MetricCard("Por cobrar",money(toCollect),StreamCyan,Modifier.weight(1f),Icons.Default.AccountBalanceWallet);MetricCard("Cobrado este mes",money(salesMonth),StreamBlue,Modifier.weight(1f),Icons.Default.TrendingUp)}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){MetricCard("Costos del mes",money(costsMonth),StreamRed,Modifier.weight(1f),Icons.Default.Payments);MetricCard("Ganancia del mes",money(profitMonth),if(profitMonth>=0)StreamGreen else StreamRed,Modifier.weight(1f),Icons.Default.TrendingUp)}}
  if(providerDue>0){item{SectionTitle("Atención inmediata","Cuentas del proveedor próximas al corte")};items(accounts.filter{it.end.isNotBlank()&&runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(it.end)) in 0..3}.getOrDefault(false)}.take(5)){a->ProviderAccountAlert(a)}}
  if(promiseDue>0)item{InfoBanner("Promesas de pago","$promiseDue cliente${if(promiseDue==1)"" else "s"} prometieron pagar y requieren seguimiento hoy.",StreamAmber)}
  item{SectionTitle("Clientes por gestionar","Cobra, renueva o define qué hacer con cada cliente")}
  if(work.isEmpty())item{EmptyState("Todo al día. No tienes clientes pendientes por gestionar.")}
  items(work.take(20)){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}
 }
}
@Composable fun ProviderAccountAlert(a:ProviderAccountSummary){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=StreamAmber.copy(alpha=.08f))){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(a.service,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("PROVEEDOR",StreamAmber)};Text(a.account,style=MaterialTheme.typography.bodySmall);Text("${providerDisplayName(a.provider)} • vence ${a.end} • renovar ${money(a.renewCost)}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}

@Composable fun ProviderDueCard(s:Sub){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(s.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("Corte ${s.accountEnd.ifBlank{"sin fecha"}}",StreamRed)};Text(s.account,style=MaterialTheme.typography.bodyMedium);Text("Proveedor · ${providerDisplayName(s.provider.ifBlank{"Sin asignar"})}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Renovación ${money(s.accountRenewCost)}",fontWeight=FontWeight.SemiBold)}}}

@Composable fun ProviderDueStockCard(x:StockItem){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(x.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("Corte ${x.accountEnd.ifBlank{"sin fecha"}}",StreamRed)};Text(x.account,style=MaterialTheme.typography.bodyMedium);Text("Proveedor · ${providerDisplayName(x.provider.ifBlank{"Sin asignar"})}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Costo de renovar ${money(x.accountRenewCost)}",fontWeight=FontWeight.SemiBold);StatusBadge(if(effectiveStockStatus(x)=="DISPONIBLE")"STOCK DISPONIBLE" else effectiveStockStatus(x).replace('_',' '),if(effectiveStockStatus(x)=="DISPONIBLE")StreamBlue else StreamRed)}}}

@Composable fun Renewals(s:List<Sub>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val groups=listOf("En 3 días" to s.filter{it.status!="CORTADO"&&days(it) in 2..3},"Mañana" to s.filter{it.status!="CORTADO"&&days(it)==1L},"Hoy" to s.filter{it.status!="CORTADO"&&days(it)==0L},"Vencidos" to s.filter{it.status!="CORTADO"&&days(it)<0&&it.status!="ESPERA"},"En espera" to s.filter{it.status=="ESPERA"})
 val total=groups.sumOf{it.second.size};var quick by remember{mutableStateOf(false)}
 val queue=s.filter{it.status!="CORTADO"&&(days(it)<=3||it.status=="ESPERA")}.sortedBy{it.end}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{ScreenHeader("Renovaciones","Cobra y renueva sin perder clientes")}
  if(queue.isNotEmpty())item{Button({quick=true},Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=StreamCyan,contentColor=Color(0xFF001317))){Icon(Icons.Default.Chat,contentDescription=null);Spacer(Modifier.width(8.dp));Text("Cobranza rápida · ${queue.size} ${if(queue.size==1)"pendiente" else "pendientes"}",fontWeight=FontWeight.Bold)}}
  item{LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){
   item{RenewalChip("Vencidos",groups.first{it.first=="Vencidos"}.second.size,StreamRed)}
   item{RenewalChip("Hoy",groups.first{it.first=="Hoy"}.second.size,StreamYellow)}
   item{RenewalChip("Mañana",groups.first{it.first=="Mañana"}.second.size,Color(0xFF91A6B8))}
   item{RenewalChip("En 3 días",groups.first{it.first=="En 3 días"}.second.size,StreamBlue)}
   item{RenewalChip("En espera",groups.first{it.first=="En espera"}.second.size,StreamPurple)}
  }}
  if(total==0)item{EmptyState("Todo al día. No hay clientes pendientes de renovación.")}
  groups.filter{it.second.isNotEmpty()}.forEach{(title,list)->item{SectionTitle(title,"${list.size} cliente${if(list.size==1)"" else "s"}")};items(list.sortedBy{it.end}){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}}
 }
 if(quick)QuickCollectionDialog(queue,{quick=false},wa,contact,renew)
}

@Composable fun ActionCard(s:Sub,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 var showAdjust by remember(s.id){mutableStateOf(false)};var showEnd by remember(s.id){mutableStateOf(false)};var showPromise by remember(s.id){mutableStateOf(false)};var more by remember(s.id){mutableStateOf(false)};val ctx=LocalContext.current
 val d=days(s);val status=when{ s.status=="ESPERA"->"EN ESPERA";d<0->"VENCIDO";d==0L->"VENCE HOY";d==1L->"MAÑANA";else->"PRÓXIMO"};val color=when{ s.status=="ESPERA"->StreamPurple;d<0->StreamRed;d==0L->StreamYellow;d==1L->Color(0xFF91A6B8);else->StreamCyan}
 Card(Modifier.fillMaxWidth().border(1.dp,color.copy(alpha=.28f),RoundedCornerShape(18.dp)),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(s.client,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text(s.service,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(status,color)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vence ${s.end}",style=MaterialTheme.typography.bodyMedium);Text(money(s.price),fontWeight=FontWeight.Bold)}
  Text(s.type,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.account.isNotBlank())Text(s.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.profile.isNotBlank())Text("Perfil ${s.profile}${if(s.pin.isNotBlank())"  ·  PIN guardado" else ""}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.contacted)StatusBadge(contactLabel(s.lastContact),StreamGreen)
  if(s.promiseDate.isNotBlank())Surface(shape=RoundedCornerShape(10.dp),color=StreamPurple.copy(alpha=.10f)){Text("Promesa de pago · ${s.promiseDate}",Modifier.padding(9.dp),style=MaterialTheme.typography.bodySmall,color=StreamPurple)}
  Button({wa(s);contact(s)},modifier=Modifier.fillMaxWidth()){Text("Cobrar por WhatsApp")}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({renew(s)},modifier=Modifier.weight(1f)){Text("Renovar +30")};if(d<=0)OutlinedButton({showPromise=true},modifier=Modifier.weight(1f)){Text("Dar plazo")}}
  if(d<=0)TextButton({showEnd=true},colors=ButtonDefaults.textButtonColors(contentColor=StreamRed),modifier=Modifier.fillMaxWidth()){Text("No renovó",fontWeight=FontWeight.Bold)}
  TextButton({more=!more},modifier=Modifier.fillMaxWidth()){Text(if(more)"Ocultar" else "Editar / credenciales")}
  if(more){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);OutlinedButton({wa(ctx,s,fillTemplate(Store(ctx).templates().delivery,s))},modifier=Modifier.fillMaxWidth()){Text("Enviar credenciales")};OutlinedButton({edit(s)},modifier=Modifier.fillMaxWidth()){Text("Editar entrega / cuenta")};OutlinedButton({showAdjust=true},modifier=Modifier.fillMaxWidth()){Text("Ajustar vencimiento")}}
 }}
 if(showAdjust)AdjustEndDialog(s,{showAdjust=false}){date,reason->adjust(s,date,reason);showAdjust=false};if(showEnd)EndServiceDialog(s,{showEnd=false}){reason->cut(s,reason);showEnd=false};if(showPromise)PromiseDialog(s,{showPromise=false}){date->promise(s,date);showPromise=false}
}

@Composable fun Accounts(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,services:List<ServiceTemplate>,saveStock:(List<StockItem>)->Unit,addStockItem:(StockItem)->Unit,sell:(Sub,StockItem)->Unit,adjust:(Sub,String,String)->Unit,edit:(Sub)->Unit){
 val ctx=LocalContext.current;val st=remember{Store(ctx)};var section by remember{mutableStateOf("STOCK")};var addStock by remember{mutableStateOf(false)};var selling by remember{mutableStateOf<StockItem?>(null)};var editingStock by remember{mutableStateOf<StockItem?>(null)}
 var query by remember{mutableStateOf("")};var stockFilter by remember{mutableStateOf("Todos")};var activeFilter by remember{mutableStateOf("Todos")};var expandedStockId by remember{mutableStateOf<Long?>(null)};var expandedActiveKey by remember{mutableStateOf<String?>(null)}
 val active=s.filter{it.status!="CORTADO"};val grouped=active.filter{it.account.isNotBlank()}.groupBy{"${providerKey(it.provider)}|${it.service.trim().lowercase()}|${accountKey(it.account)}"};val completeDelivered=active.count{isComplete(it)};val profileOccupied=active.count{!isComplete(it)}
 val visibleStock=stock.filter{it.status=="DISPONIBLE"||it.status=="NO_DISPONIBLE"};val completeStock=visibleStock.filter{isComplete(it)};val profileStock=visibleStock.filter{!isComplete(it)}
 val availableComplete=completeStock.count{effectiveStockStatus(it)=="DISPONIBLE"};val availableProfiles=profileStock.count{effectiveStockStatus(it)=="DISPONIBLE"};val unavailable=visibleStock.count{effectiveStockStatus(it)=="NO_DISPONIBLE"}
 val q=query.trim()
 val filteredStock=visibleStock.filter{x->
  val matches=q.isBlank()||listOf(x.service,x.account,x.profile,x.provider).any{it.contains(q,true)}
  val statusOk=when(stockFilter){"Disponibles"->effectiveStockStatus(x)=="DISPONIBLE";"No disponibles"->effectiveStockStatus(x)=="NO_DISPONIBLE";else->true}
  matches&&statusOk
 }.sortedWith(compareBy<StockItem>{it.service.lowercase()}.thenBy{it.account.lowercase()}.thenBy{it.profile.lowercase()})
 val activeEntries=grouped.entries.filter{e->
  val base=e.value.first();val matches=q.isBlank()||listOf(base.service,base.account,base.provider).any{it.contains(q,true)}||e.value.any{it.client.contains(q,true)||it.profile.contains(q,true)}
  val anyExpired=e.value.any{days(it)<0};val anyCurrent=e.value.any{days(it)>=0}
  val statusOk=when(activeFilter){"Activas"->anyCurrent;"Vencidas"->anyExpired;else->true}
  matches&&statusOk
 }.sortedWith(compareBy<Map.Entry<String,List<Sub>>>{it.value.first().service.lowercase()}.thenBy{it.value.first().account.lowercase()})
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{ScreenHeader("Stock","Encuentra rápido qué puedes vender y qué ya entregaste")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=section=="STOCK",onClick={section="STOCK"},label={Text("Para vender")},modifier=Modifier.weight(1f));FilterChip(selected=section=="ACTIVAS",onClick={section="ACTIVAS"},label={Text("Ya entregadas")},modifier=Modifier.weight(1f))}}
  item{OutlinedTextField(query,{query=it},label={Text("Buscar servicio, correo o cliente")},leadingIcon={Icon(Icons.Default.Search,contentDescription=null)},singleLine=true,modifier=Modifier.fillMaxWidth())}
  if(section=="STOCK"){
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Cuentas",availableComplete.toString(),Modifier.weight(1f),StreamBlue);MiniStat("Perfiles",availableProfiles.toString(),Modifier.weight(1f),StreamBlue);MiniStat("No disp.",unavailable.toString(),Modifier.weight(1f),if(unavailable>0)StreamRed else MaterialTheme.colorScheme.onSurfaceVariant)}}
   item{LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Todos","Disponibles","No disponibles")){x->FilterChip(selected=stockFilter==x,onClick={stockFilter=x},label={Text(x)})}}}
   item{Button({addStock=true},Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=StreamCyan,contentColor=Color(0xFF001317))){Text("＋  Agregar acceso al stock",fontWeight=FontWeight.Bold)}}
   if(filteredStock.isEmpty())item{EmptyState(if(q.isBlank())"No hay accesos con este filtro." else "No encontramos '$q' en el stock.")}
   items(filteredStock,key={it.id}){x->
    val salePrice=services.firstOrNull{it.name.equals(x.service,true)}?.defaultPrice?:0L
    CompactStockRow(x,salePrice,expandedStockId==x.id,{expandedStockId=if(expandedStockId==x.id)null else x.id},{selling=x},{editingStock=x},{saveStock(stock.map{if(it.id==x.id)it.copy(status=if(effectiveStockStatus(it)=="NO_DISPONIBLE")"DISPONIBLE" else "NO_DISPONIBLE")else it})})
   }
  }else{
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Cuentas entregadas",completeDelivered.toString(),Modifier.weight(1f),StreamBlue);MiniStat("Perfiles ocupados",profileOccupied.toString(),Modifier.weight(1f),StreamPurple)}}
   item{LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Todos","Activas","Vencidas")){x->FilterChip(selected=activeFilter==x,onClick={activeFilter=x},label={Text(x)})}}}
   if(activeEntries.isEmpty())item{EmptyState(if(q.isBlank())"No hay cuentas entregadas con este filtro." else "No encontramos '$q' entre las cuentas entregadas.")}
   items(activeEntries,key={it.key}){e->CompactActiveAccountCard(e.key,e.value,expandedActiveKey==e.key,{expandedActiveKey=if(expandedActiveKey==e.key)null else e.key},{x->wa(ctx,x,fillTemplate(st.templates().delivery,x))},{x->edit(x)})}
  }
 }
 if(addStock)AddStockDialog(services,{addStock=false}){item->addStockItem(item);addStock=false}
 selling?.let{item->SellStockDialog(item,services,{selling=null}){sub->sell(sub,item);selling=null}}
 editingStock?.let{item->EditStockDialog(item,{editingStock=null}){updated->saveStock(stock.map{if(it.id==updated.id)updated else it});editingStock=null}}
}

@Composable fun CompactStockRow(x:StockItem,salePrice:Long,expanded:Boolean,toggleExpand:()->Unit,sell:()->Unit,edit:()->Unit,toggleStatus:()->Unit){
 val status=effectiveStockStatus(x);val color=if(status=="DISPONIBLE")StreamBlue else StreamRed;val expectedProfit=if(salePrice>0)salePrice-x.accountCost else 0L
 Card(Modifier.fillMaxWidth().clickable{toggleExpand()},shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.48f))){Column(Modifier.padding(horizontal=12.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(x.service,fontWeight=FontWeight.Bold,maxLines=1);Text(x.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)};StatusBadge(status.replace('_',' '),color)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(if(isComplete(x))"Cuenta completa" else "Perfil ${x.profile.ifBlank{"sin nombre"}}",style=MaterialTheme.typography.labelMedium);Text(providerDisplayName(x.provider.ifBlank{"Sin proveedor"}),style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Text("Costo ${money(x.accountCost)}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);if(salePrice>0)Text("Venta ${money(salePrice)}",style=MaterialTheme.typography.labelSmall,color=StreamBlue);if(salePrice>0)Text("Gana ${money(expectedProfit)}",style=MaterialTheme.typography.labelSmall,color=if(expectedProfit>=0)StreamGreen else StreamRed)}
  if(status=="DISPONIBLE")Button(sell,Modifier.fillMaxWidth().heightIn(min=40.dp),colors=ButtonDefaults.buttonColors(containerColor=StreamCyan,contentColor=Color(0xFF001317))){Text(if(isComplete(x))"Vender" else "Asignar perfil",fontWeight=FontWeight.Bold)}
  if(expanded){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Text("Compra ${x.purchaseDate.ifBlank{"Sin fecha"}}  ·  Vence proveedor ${x.accountEnd.ifBlank{"Sin fecha"}}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Renovar cuenta ${money(x.accountRenewCost)}${if(x.password.isNotBlank())"  ·  Contraseña guardada" else ""}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(edit,Modifier.weight(1f)){Text("Editar")};OutlinedButton(toggleStatus,Modifier.weight(1f)){Text(if(status=="NO_DISPONIBLE")"Habilitar" else "No disponible")}}}
 }}
}

@Composable fun CompactActiveAccountCard(key:String,members:List<Sub>,expanded:Boolean,toggleExpand:()->Unit,credentials:(Sub)->Unit,edit:(Sub)->Unit){
 val ctx=LocalContext.current;val base=members.first();val complete=members.all{isComplete(it)};val cost=members.maxOfOrNull{it.accountCost}?:0L;val income=members.sumOf{it.price};val profit=income-cost;val expired=members.count{days(it)<0};val nearest=members.minByOrNull{runCatching{LocalDate.parse(it.end)}.getOrDefault(LocalDate.MAX)}?.end.orEmpty();val statusLabel=when{expired>0&&complete->"VENCIDA";expired>0->"$expired VENCIDO${if(expired==1)"" else "S"}";complete->"ENTREGADA";else->"${members.size} OCUPADO${if(members.size==1)"" else "S"}"};val statusColor=if(expired>0)StreamRed else if(complete)StreamCyan else StreamPurple
 Card(Modifier.fillMaxWidth().clickable{toggleExpand()},shape=RoundedCornerShape(15.dp)){Column(Modifier.padding(horizontal=12.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(base.service,fontWeight=FontWeight.Bold,maxLines=1);Text(base.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)};StatusBadge(statusLabel,statusColor)}
  if(complete){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(base.client,style=MaterialTheme.typography.bodyMedium,fontWeight=FontWeight.SemiBold);Text("Vence ${base.end}",style=MaterialTheme.typography.bodySmall,color=if(days(base)<0)StreamRed else MaterialTheme.colorScheme.onSurfaceVariant)}} else Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${members.size} perfil${if(members.size==1)"" else "es"} ocupado${if(members.size==1)"" else "s"}",style=MaterialTheme.typography.bodySmall);Text("Próximo: ${nearest.ifBlank{"Sin fecha"}}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
  if(expanded){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Costo",money(cost),Modifier.weight(1f));MiniStat("Ingreso",money(income),Modifier.weight(1f),StreamBlue);MiniStat("Ganancia",money(profit),Modifier.weight(1f),if(profit>=0)StreamGreen else StreamRed)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Proveedor",style=MaterialTheme.typography.bodySmall);Text(providerDisplayName(base.provider.ifBlank{"Sin asignar"}),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vence proveedor",style=MaterialTheme.typography.bodySmall);Text(base.accountEnd.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)};if(base.providerPhone.isNotBlank())OutlinedButton({waProvider(ctx,base.provider,base.providerPhone,base.account,base.service,base.accountEnd)},Modifier.fillMaxWidth()){Text("Contactar proveedor")};Text(if(complete)"Cliente" else "Perfiles / clientes",fontWeight=FontWeight.Bold);members.sortedBy{it.end}.forEach{x->ProfileRow(x,{credentials(x)},{edit(x)})}}
 }}
}

@Composable fun AddStockDialog(services:List<ServiceTemplate>,close:()->Unit,save:(StockItem)->Unit){
 var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var profile by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var type by remember{mutableStateOf("PERFIL/PANTALLA")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var purchaseDate by remember{mutableStateOf(LocalDate.now().toString())};var accountEnd by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 fun applyTemplate(t:ServiceTemplate){service=t.name;type=t.type;provider=t.provider;providerPhone=t.providerPhone;cost=t.accountCost.toString();renewCost=t.renewCost.toString();if(type=="CUENTA COMPLETA"){profile="";pin=""}}
 AlertDialog(onDismissRequest=close,title={Text("Agregar stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  if(services.isNotEmpty())item{Column{Text("PLANTILLAS RÁPIDAS",fontWeight=FontWeight.Bold);LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(services){t->AssistChip(onClick={applyTemplate(t)},label={Text(t.name)})}}}}
  item{Text("TIPO DE STOCK",fontWeight=FontWeight.Bold)};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=type=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA"},label={Text("Perfil / pantalla")},modifier=Modifier.weight(1f));FilterChip(selected=type=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA";profile="";pin=""},label={Text("Cuenta completa")},modifier=Modifier.weight(1f))}}
  item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};if(type=="PERFIL/PANTALLA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}}}
  item{Text("COMPRA / PROVEEDOR",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Fecha de compra AAAA-MM-DD",purchaseDate){purchaseDate=it}};item{F("Vence cuenta completa AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de compra",cost){cost=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=service.isNotBlank()&&account.isNotBlank(),onClick={save(StockItem(service=service,account=account,password=password,profile=if(type=="CUENTA COMPLETA")"" else profile,pin=if(type=="CUENTA COMPLETA")"" else pin,type=type,provider=normalizedProviderStorage(provider),providerPhone=providerPhone,accountEnd=accountEnd,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0,status="DISPONIBLE",purchaseDate=purchaseDate))}){Text("Guardar stock")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun EditStockDialog(x:StockItem,close:()->Unit,save:(StockItem)->Unit){
 var service by remember(x.id){mutableStateOf(x.service)};var account by remember(x.id){mutableStateOf(x.account)};var password by remember(x.id){mutableStateOf(x.password)};var profile by remember(x.id){mutableStateOf(x.profile)};var pin by remember(x.id){mutableStateOf(x.pin)};var type by remember(x.id){mutableStateOf(x.type)};var provider by remember(x.id){mutableStateOf(x.provider)};var providerPhone by remember(x.id){mutableStateOf(x.providerPhone)};var purchaseDate by remember(x.id){mutableStateOf(x.purchaseDate)};var accountEnd by remember(x.id){mutableStateOf(x.accountEnd)};var cost by remember(x.id){mutableStateOf(x.accountCost.toString())};var renewCost by remember(x.id){mutableStateOf(x.accountRenewCost.toString())}
 AlertDialog(onDismissRequest=close,title={Text("Editar stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=type=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA"},label={Text("Perfil")},modifier=Modifier.weight(1f));FilterChip(selected=type=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA"},label={Text("Cuenta completa")},modifier=Modifier.weight(1f))}}
  item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};if(type=="PERFIL/PANTALLA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave",pin){pin=it}}};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Fecha de compra AAAA-MM-DD",purchaseDate){purchaseDate=it}};item{F("Vence cuenta completa AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de compra",cost){cost=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=service.isNotBlank()&&account.isNotBlank(),onClick={save(x.copy(service=service,account=account,password=password,profile=if(type=="CUENTA COMPLETA")"" else profile,pin=if(type=="CUENTA COMPLETA")"" else pin,type=type,provider=normalizedProviderStorage(provider),providerPhone=providerPhone,accountEnd=accountEnd,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0,purchaseDate=purchaseDate))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun SellStockDialog(x:StockItem,services:List<ServiceTemplate>,close:()->Unit,save:(Sub)->Unit){
 val tpl=services.firstOrNull{it.name.equals(x.service,true)};var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var price by remember{mutableStateOf((tpl?.defaultPrice?:0).let{if(it>0)it.toString() else ""})};var method by remember{mutableStateOf("Nequi")};var start by remember{mutableStateOf(LocalDate.now().toString())};var duration by remember{mutableStateOf((tpl?.durationDays?:30).toString())}
 AlertDialog(onDismissRequest=close,title={Text("Venta rápida desde stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primary.copy(alpha=.08f))){Column(Modifier.padding(10.dp)){Text(x.service,fontWeight=FontWeight.Bold);Text(if(isComplete(x))"Cuenta completa" else x.profile.ifBlank{"Perfil / pantalla"},style=MaterialTheme.typography.bodySmall);Text(x.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
  item{Text("Solo completa cliente y cobro. Las credenciales y proveedor se toman del stock.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
  item{F("Cliente",client){client=it}};item{F("WhatsApp (57...)",phone){phone=it}};item{F("Precio cobrado",price){price=it}};item{F("Método de pago",method){method=it}};item{F("Inicio AAAA-MM-DD",start){start=it}};item{F("Duración en días",duration){duration=it}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&runCatching{LocalDate.parse(start)}.isSuccess,onClick={val d=LocalDate.parse(start);val n=duration.toLongOrNull()?.coerceAtLeast(1L)?:30L;save(Sub(client=client,phone=phone,service=x.service,account=x.account,profile=x.profile,type=normalizedAccessType(x.type,x.profile),price=price.filter{it.isDigit()}.toLongOrNull()?:0,start=d.toString(),end=d.plusDays(n).toString(),pin=x.pin,accountCost=x.accountCost,paymentMethod=method,password=x.password,provider=x.provider,providerPhone=x.providerPhone,accountEnd=x.accountEnd,accountRenewCost=x.accountRenewCost,stockId=x.id,purchaseDate=x.purchaseDate))}){Text("Guardar y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun MiniStat(label:String,value:String,modifier:Modifier=Modifier,valueColor:Color=MaterialTheme.colorScheme.onSurface){Surface(modifier,shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.55f)){Column(Modifier.padding(9.dp)){Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value,style=MaterialTheme.typography.bodyMedium,fontWeight=FontWeight.Bold,color=valueColor)}}}
@Composable fun ProfileRow(s:Sub,credentials:()->Unit,edit:()->Unit){
 val expired=days(s)<0;Column(verticalArrangement=Arrangement.spacedBy(6.dp)){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(if(isComplete(s))s.client else s.profile.ifBlank{s.client},fontWeight=FontWeight.SemiBold,maxLines=1);Text("${s.client}${if(!isComplete(s)&&s.profile.isNotBlank())" · ${s.profile}" else ""} · vence ${s.end}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)};StatusBadge(if(expired)"VENCIDO" else "ACTIVO",if(expired)StreamRed else StreamGreen)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(credentials,Modifier.weight(1f)){Text("Enviar datos")};TextButton(edit,Modifier.weight(1f)){Text("Editar")}}}
}
fun waProvider(c:Context,provider:String,phone:String,account:String,service:String,end:String){val msg="Hola $provider, necesito revisar${if(account.isNotBlank())" la cuenta $account" else ""}${if(service.isNotBlank())" de $service" else ""}.${if(end.isNotBlank())" Vence $end." else ""}";val u="https://wa.me/${phone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun Providers(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,renewProvider:(ProviderAccountSummary,String,Long)->Unit){
 val ctx=LocalContext.current;val accounts=providerAccounts(s,stock,h);val groups=accounts.groupBy{providerKey(it.provider)}.toSortedMap();var renewing by remember{mutableStateOf<ProviderAccountSummary?>(null)}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Proveedores","A quién compras y qué cuentas debes renovar")}
  if(groups.isNotEmpty()){
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Proveedores",groups.size.toString(),StreamBlue,Modifier.weight(1f),Icons.Default.Groups);MetricCard("Cuentas por vencer",accounts.count{it.end.isNotBlank()&&runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(it.end)) in 0..7}.getOrDefault(false)}.toString(),StreamAmber,Modifier.weight(1f),Icons.Default.Event)}}
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Invertido",money(accounts.sumOf{it.cost}),StreamRed,Modifier.weight(1f),Icons.Default.Payments);MetricCard("Ganancia acumulada",money(accounts.sumOf{it.income-it.cost-it.renewSpent}),if(accounts.sumOf{it.income-it.cost-it.renewSpent}>=0)StreamGreen else StreamRed,Modifier.weight(1f),Icons.Default.TrendingUp)}}
  }
  if(groups.isEmpty())item{EmptyState("Aún no hay proveedores. Registra una compra en Stock y aparecerá aquí automáticamente.")}
  groups.forEach{(_,list)->
   val name=list.firstOrNull()?.provider.orEmpty()
   val invested=list.sumOf{it.cost};val income=list.sumOf{it.income};val renews=list.sumOf{it.renewSpent};val profit=income-invested-renews;val due=list.count{it.end.isNotBlank()&&runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(it.end)) in 0..7}.getOrDefault(false)}
   item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(providerDisplayName(name),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("${list.size} cuenta${if(list.size==1)"" else "s"} registrada${if(list.size==1)"" else "s"}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(due>0)"$due por vencer" else "AL DÍA",if(due>0)StreamAmber else StreamGreen)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Invertido",money(invested),Modifier.weight(1f));MiniStat("Ingresos",money(income),Modifier.weight(1f),StreamCyan);MiniStat("Ganancia",money(profit),Modifier.weight(1f),if(profit>=0)StreamGreen else StreamRed)}
    val phone=list.firstOrNull{it.phone.isNotBlank()}?.phone?:"";if(phone.isNotBlank())OutlinedButton({waProvider(ctx,name,phone,"","","")},Modifier.fillMaxWidth()){Text("Contactar proveedor")}
   }}}
   items(list.sortedWith(compareBy<ProviderAccountSummary>{it.end.ifBlank{"9999"}}.thenBy{it.service})){a->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.45f))){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(a.service,fontWeight=FontWeight.Bold);Text(a.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(a.status,when(a.status){"VENCIDA"->StreamRed;"ACTIVA"->StreamCyan;"STOCK"->StreamGreen;else->StreamAmber})}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Costo",money(a.cost),Modifier.weight(1f));MiniStat("Ingreso acum.",money(a.income),Modifier.weight(1f),StreamCyan);MiniStat("Ganancia acum.",money(a.income-a.cost-a.renewSpent),Modifier.weight(1f),if(a.income-a.cost-a.renewSpent>=0)StreamGreen else StreamRed)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Compra",style=MaterialTheme.typography.bodySmall);Text(a.purchaseDate.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vence proveedor",style=MaterialTheme.typography.bodySmall);Text(a.end.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Renovar",style=MaterialTheme.typography.bodySmall);Text(money(a.renewCost),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){if(a.phone.isNotBlank())OutlinedButton({waProvider(ctx,a.provider,a.phone,a.account,a.service,a.end)},Modifier.weight(1f)){Text("WhatsApp")};Button({renewing=a},Modifier.weight(1f)){Text("Renovar cuenta")}}
   }}}
  }
 }
 renewing?.let{a->ProviderRenewDialog(a,{renewing=null}){end,cost->renewProvider(a,end,cost);renewing=null}}
}
@Composable fun ProviderRenewDialog(a:ProviderAccountSummary,close:()->Unit,save:(String,Long)->Unit){var end by remember(a.account){mutableStateOf(runCatching{val base=if(a.end.isNotBlank())LocalDate.parse(a.end) else LocalDate.now();base.plusDays(30).toString()}.getOrDefault(LocalDate.now().plusDays(30).toString()))};var cost by remember(a.account){mutableStateOf(a.renewCost.toString())};AlertDialog(onDismissRequest=close,title={Text("Renovar con proveedor")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("${a.service} • ${a.account}",fontWeight=FontWeight.Bold);Text("Proveedor: ${providerDisplayName(a.provider)}");F("Nuevo vencimiento AAAA-MM-DD",end){end=it};F("Costo pagado",cost){cost=it};Text("Este movimiento queda registrado como costo y actualiza la fecha de la cuenta.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}},confirmButton={Button({save(end,cost.filter{it.isDigit()}.toLongOrNull()?:0)},enabled=runCatching{LocalDate.parse(end)}.isSuccess){Text("Registrar renovación")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun Reports(s:List<Sub>,stock:List<StockItem>,h:List<Hist>){
 val month=monthPrefix();val monthHist=h.filter{it.date.startsWith(month)};val salesMonth=monthHist.filter{isSaleIncome(it)}.sumOf{it.amount};val renewProvider=monthHist.filter{it.action.contains("RENOVACIÓN PROVEEDOR")}.sumOf{it.amount};val costsMonth=monthlyAccountCosts(s,stock)+renewProvider;val profitMonth=salesMonth-costsMonth
 val active=s.count{it.status!="CORTADO"&&days(it)>=0};val newSales=monthHist.count{it.action.contains("VENTA")};val renewals=monthHist.count{it.action.contains("RENOVACIÓN +30")}
 val toCollect=s.filter{it.status!="CORTADO"&&(days(it)<=3||it.status=="ESPERA")}.sumOf{it.price};val occupiedProfiles=s.count{it.status!="CORTADO"&&!isComplete(it)};val totalProfiles=occupiedProfiles+stock.count{effectiveStockStatus(it)=="DISPONIBLE"&&!isComplete(it)};val occupancy=if(totalProfiles>0)occupiedProfiles*100/totalProfiles else 0
 val providers=providerAccounts(s,stock,h);val providerDue=providers.count{it.end.isNotBlank()&&runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(it.end)) in 0..7}.getOrDefault(false)};val providerGroups=providers.groupBy{providerKey(it.provider)};val bestProvider=providerGroups.entries.maxByOrNull{e->e.value.sumOf{it.income-it.cost-it.renewSpent}};val accountBest=providers.maxByOrNull{it.income-it.cost-it.renewSpent};val serviceBest=s.filter{it.status!="CORTADO"}.groupBy{it.service}.maxByOrNull{it.value.size}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Reportes","Cobros, costos y ganancia de este mes")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Cobrado este mes",money(salesMonth),StreamBlue,Modifier.weight(1f),Icons.Default.TrendingUp);MetricCard("Costos",money(costsMonth),StreamRed,Modifier.weight(1f),Icons.Default.Payments)}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Ganancia",money(profitMonth),if(profitMonth>=0)StreamGreen else StreamRed,Modifier.weight(1f),Icons.Default.TrendingUp);MetricCard("Por cobrar",money(toCollect),StreamCyan,Modifier.weight(1f),Icons.Default.AccountBalanceWallet)}}
  item{SectionTitle("Indicadores","Actividad registrada y clientes actuales")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Clientes activos ahora",active.toString(),Modifier.weight(1f),StreamBlue);MiniStat("Ventas nuevas este mes",newSales.toString(),Modifier.weight(1f),StreamCyan)}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Renovaciones este mes",renewals.toString(),Modifier.weight(1f),StreamGreen);MiniStat("Cuentas proveedor por vencer",providerDue.toString(),Modifier.weight(1f),StreamAmber)}
  }}}
  item{SectionTitle("Lo que más te conviene","Identifica rápido qué producto y proveedor dejan más ganancia")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){InsightRow("Servicio con más clientes",serviceBest?.key?:"Sin datos",StreamPurple);HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);InsightRow("Proveedor que más ganancia deja",bestProvider?.value?.firstOrNull()?.provider?.let{providerDisplayName(it)}?:"Sin datos",StreamGreen,bestProvider?.let{"${money(it.value.sumOf{x->x.income-x.cost-x.renewSpent})} de ganancia acumulada"}?:"");HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);InsightRow("Cuenta que más ganancia deja",accountBest?.service?:"Sin datos",StreamCyan,accountBest?.let{"${it.account} • ${money(it.income-it.cost-it.renewSpent)}"}?:"")}}}
  item{SectionTitle("Actividad reciente","Últimos movimientos del negocio")}
  if(h.isEmpty())item{EmptyState("Aún no hay movimientos registrados.")}
  items(h.sortedByDescending{it.id}.take(100)){x->ActivityRow(x,activityOwner(x,s))}
 }
}
@Composable fun ActivityRow(x:Hist,client:String){val isCost=x.action.contains("COMPRA STOCK")||x.action.contains("RENOVACIÓN PROVEEDOR");val amountColor=if(isCost)StreamRed else StreamGreen;Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.42f))){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(client,fontWeight=FontWeight.SemiBold);Text(x.action,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(x.date,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};if(x.amount>0)Text((if(isCost)"− " else "+ ")+money(x.amount),fontWeight=FontWeight.Bold,color=amountColor)}}}

@Composable fun More(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,services:List<ServiceTemplate>,setServices:(List<ServiceTemplate>)->Unit,dark:Boolean,setDark:(Boolean)->Unit,t:Templates,setT:(Templates)->Unit,st:Store,reload:()->Unit){
 var edit by remember{mutableStateOf(false)};var incident by remember{mutableStateOf(false)};var serviceDialog by remember{mutableStateOf(false)};var filter by remember{mutableStateOf("Todos")};var query by remember{mutableStateOf("")};val c=LocalContext.current;var backupMsg by remember{mutableStateOf("")}
 val createBackup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null)runCatching{c.contentResolver.openOutputStream(u)?.bufferedWriter()?.use{it.write(st.backup())};backupMsg="Respaldo guardado correctamente"}.onFailure{backupMsg="No se pudo guardar el respaldo"}}
 val openBackup=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)runCatching{val txt=c.contentResolver.openInputStream(u)?.bufferedReader()?.use{it.readText()}?:"";backupMsg=if(st.restore(txt)){reload();"Respaldo restaurado correctamente"} else "Archivo no compatible"}.onFailure{backupMsg="No se pudo restaurar"}}
 val chooseFolder=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()){u->if(u!=null){backupMsg=if(st.setBackupFolder(u))"Carpeta automática configurada" else "No se pudo configurar la carpeta"}}
 val filtered=h.sortedByDescending{it.id}.filter{x->val owner=activityOwner(x,s);(owner.contains(query,true)||x.action.contains(query,true))&&(filter=="Todos"||x.action.contains(filter,true))}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Ajustes","Plantillas, incidencias, actividad y respaldo")}
  item{SectionTitle("Operación")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Plantillas de servicios",fontWeight=FontWeight.Bold);StatusBadge(services.size.toString(),StreamPurple)};Text("Duración, precio, tipo, proveedor y costos para registrar compras y ventas más rápido.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton({serviceDialog=true},Modifier.fillMaxWidth()){Text("Administrar plantillas")};HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Text("Incidencias de cuenta",fontWeight=FontWeight.Bold);Text("Registra caídas y repone días a todos los clientes afectados.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton({incident=true},Modifier.fillMaxWidth()){Text("Registrar incidencia")}}}}
  item{SectionTitle("Actividad","Auditoría de ventas, renovaciones, ajustes y bajas")}
  item{OutlinedTextField(query,{query=it},label={Text("Buscar cliente, proveedor o movimiento")},singleLine=true,modifier=Modifier.fillMaxWidth())}
  item{LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Todos","VENTA","RENOVACIÓN","AJUSTE","BAJA","PROVEEDOR")){x->FilterChip(selected=filter==x,onClick={filter=x},label={Text(x.lowercase().replaceFirstChar{it.uppercase()})})}}}
  if(filtered.isEmpty())item{EmptyState("Sin actividad para este filtro.")}
  items(filtered.take(40)){x->ActivityRow(x,activityOwner(x,s))}
  item{SectionTitle("Aplicación")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Modo oscuro",fontWeight=FontWeight.SemiBold);Text("Identidad Nexo Digital",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(dark,setDark)};OutlinedButton({edit=true},Modifier.fillMaxWidth()){Text("Editar mensajes automáticos")};Text("v6.7 • stock compacto y reportes claros • API 36",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
  item{SectionTitle("Copia de seguridad","Protege los datos antes de cada actualización")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){Button({createBackup.launch("ControlStreaming_Backup_${LocalDate.now()}.nexo")},Modifier.fillMaxWidth()){Text("Crear respaldo local")};OutlinedButton({openBackup.launch(arrayOf("application/octet-stream","application/json","text/plain","*/*"))},Modifier.fillMaxWidth()){Text("Restaurar respaldo")};OutlinedButton({chooseFolder.launch(null)},Modifier.fillMaxWidth()){Text(if(st.backupFolder().isBlank())"Elegir carpeta para respaldo automático" else "Cambiar carpeta automática")};if(st.backupFolder().isNotBlank())Text("Respaldo automático diario activo • se conservan las últimas 7 copias",style=MaterialTheme.typography.bodySmall,color=StreamGreen);if(backupMsg.isNotBlank())Text(backupMsg,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
 }
 if(edit)TemplateDialog(t,{edit=false}){setT(it);edit=false};if(incident)IncidentDialog(s,st,{incident=false},reload);if(serviceDialog)ServiceTemplatesDialog(services,{serviceDialog=false}){setServices(it);serviceDialog=false}
}

@Composable fun IncidentDialog(s:List<Sub>,st:Store,close:()->Unit,reload:()->Unit){var account by remember{mutableStateOf("")};var type by remember{mutableStateOf("Cuenta caída")};var daysBack by remember{mutableStateOf("0")};AlertDialog(onDismissRequest=close,title={Text("⚠️ Incidencia")},text={Column{F("Cuenta / correo afectado",account){account=it};F("Tipo de incidencia",type){type=it};F("Días a reponer a todos (0 si aún no)",daysBack){daysBack=it};Text("Afectados: ${s.count{it.account==account&&it.status!="CORTADO"}}")}},confirmButton={Button({val n=daysBack.toIntOrNull()?:0;val affected=s.filter{it.account==account&&it.status!="CORTADO"};if(n>0)st.save(s.map{x->if(x.account==account&&x.status!="CORTADO")x.copy(end=LocalDate.parse(x.end).plusDays(n.toLong()).toString())else x});val hh=st.hist().toMutableList();affected.forEach{x->hh.add(Hist(subId=x.id,date=LocalDate.now().toString(),action="INCIDENCIA • $type • ${if(n>0)"REPOSICIÓN +$n DÍAS" else "ABIERTA"}"))};st.saveHist(hh);reload();close()},enabled=account.isNotBlank()){Text("Guardar incidencia")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun TemplateDialog(t:Templates,close:()->Unit,save:(Templates)->Unit){var a by remember{mutableStateOf(t.due3)};var b by remember{mutableStateOf(t.due1)};var c by remember{mutableStateOf(t.due0)};var d by remember{mutableStateOf(t.expired)};var e by remember{mutableStateOf(t.delivery)};AlertDialog(onDismissRequest=close,title={Text("Mensajes configurables")},text={LazyColumn{item{F("Vence en 3 días",a){a=it}};item{F("Vence mañana",b){b=it}};item{F("Vence hoy",c){c=it}};item{F("Vencido",d){d=it}};item{F("Entrega",e){e=it}}}},confirmButton={Button({save(Templates(a,b,c,d,e))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun RestoreDialog(close:()->Unit,restore:(String)->Unit){var text by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Restaurar respaldo")},text={Column{Text("Pega aquí el respaldo JSON exportado desde Nexo.");OutlinedTextField(text,{text=it},modifier=Modifier.fillMaxWidth().height(180.dp))}},confirmButton={Button({restore(text)},enabled=text.isNotBlank()){Text("Restaurar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun AddDialog(services:List<ServiceTemplate>,close:()->Unit,save:(Sub)->Unit){
 var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var profile by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var method by remember{mutableStateOf("Nequi")};var type by remember{mutableStateOf("CUENTA COMPLETA")};var start by remember{mutableStateOf(LocalDate.now().toString())};var duration by remember{mutableStateOf("30")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var purchaseDate by remember{mutableStateOf(LocalDate.now().toString())};var accountEnd by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 fun applyTemplate(t:ServiceTemplate){service=t.name;type=t.type;duration=t.durationDays.toString();price=if(t.defaultPrice>0)t.defaultPrice.toString() else "";provider=t.provider;providerPhone=t.providerPhone;cost=t.accountCost.toString();renewCost=t.renewCost.toString()}
 AlertDialog(onDismissRequest=close,title={Text("Nueva venta manual")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){
  if(services.isNotEmpty())item{Column{Text("PLANTILLAS RÁPIDAS",fontWeight=FontWeight.Bold);LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(services){t->AssistChip(onClick={applyTemplate(t)},label={Text(t.name)})}}}}
  item{Text("Para ahorrar tiempo, usa la pestaña Stock cuando el acceso ya esté cargado.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{F("Cliente",client){client=it}};item{F("WhatsApp (57...)",phone){phone=it}};item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};if(type!="CUENTA COMPLETA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave",pin){pin=it}}};item{F("Tipo de entrega",type){type=it}};item{F("Precio cobrado",price){price=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Método de pago",method){method=it}};item{F("Duración en días",duration){duration=it}};item{Text("DATOS DEL PROVEEDOR",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Fecha de compra AAAA-MM-DD",purchaseDate){purchaseDate=it}};item{F("Vence cuenta completa AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}};item{F("Inicio cliente AAAA-MM-DD",start){start=it}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&runCatching{LocalDate.parse(start)}.isSuccess,onClick={val d=LocalDate.parse(start);val n=duration.toLongOrNull()?.coerceAtLeast(1L)?:30L;save(Sub(client=client,phone=phone,service=service,account=account,profile=if(type=="CUENTA COMPLETA")"" else profile,pin=if(type=="CUENTA COMPLETA")"" else pin,type=normalizedAccessType(type,profile),password=password,price=price.filter{it.isDigit()}.toLongOrNull()?:0,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,paymentMethod=method,start=d.toString(),end=d.plusDays(n).toString(),provider=normalizedProviderStorage(provider),providerPhone=providerPhone,accountEnd=accountEnd,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0,purchaseDate=purchaseDate))}){Text("Guardar y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun EndServiceDialog(s:Sub,close:()->Unit,confirm:(String)->Unit){
 var reason by remember(s.id){mutableStateOf("No renovó")}
 AlertDialog(onDismissRequest=close,title={Text("Cliente no renovó")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("${s.client} • ${s.service}",fontWeight=FontWeight.Bold);Text("El acceso quedará disponible para vender nuevamente. Los datos del cliente y sus pagos se conservarán.")
  Text("Motivo",fontWeight=FontWeight.Bold);listOf("No renovó","Cliente canceló","Cambio de servicio","Problema con la cuenta","Otro").forEach{x->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=reason==x,onClick={reason=x});Text(x)}}
 }},confirmButton={Button(onClick={confirm(reason)}){Text("Confirmar no renovación")}},dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}

@Composable fun PromiseDialog(s:Sub,close:()->Unit,save:(String)->Unit){var date by remember(s.id){mutableStateOf(LocalDate.now().plusDays(1).toString())};AlertDialog(onDismissRequest=close,title={Text("Dar plazo")},text={Column{Text("Registra cuándo prometió pagar. No modifica el vencimiento real del servicio.");F("Fecha promesa AAAA-MM-DD",date){date=it};Row{listOf(1L,2L,3L).forEach{n->TextButton({date=LocalDate.now().plusDays(n).toString()}){Text("+$n día")}}}}},confirmButton={Button({save(date)},enabled=runCatching{LocalDate.parse(date)}.isSuccess){Text("Guardar plazo")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun AdjustEndDialog(s:Sub,close:()->Unit,save:(String,String)->Unit){
 var date by remember(s.id){mutableStateOf(s.end)}
 var reason by remember(s.id){mutableStateOf("")}
 fun addDays(n:Long){date=runCatching{LocalDate.parse(date).plusDays(n).toString()}.getOrDefault(s.end)}
 AlertDialog(
  onDismissRequest=close,
  title={Text("Ajustar vencimiento")},
  text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text("${s.client} • ${s.service}")
   Text("Vencimiento actual: ${s.end}")
   OutlinedTextField(value=date,onValueChange={date=it},label={Text("Nueva fecha AAAA-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
   Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1L,3L,5L,7L).forEach{n->OutlinedButton(onClick={addDays(n)},contentPadding=PaddingValues(horizontal=8.dp,vertical=6.dp)){Text("+$n")}}}
   OutlinedTextField(value=reason,onValueChange={reason=it},label={Text("Motivo (opcional)")},modifier=Modifier.fillMaxWidth())
   Text("Este ajuste no registra una venta ni una renovación pagada.",style=MaterialTheme.typography.bodySmall)
  }},
  confirmButton={Button(onClick={save(date,reason)},enabled=runCatching{LocalDate.parse(date)}.isSuccess){Text("Guardar")}},
  dismissButton={TextButton(onClick=close){Text("Cancelar")}}
 )
}

@Composable fun EditSubDialog(s:Sub,close:()->Unit,save:(Sub)->Unit){
 var client by remember(s.id){mutableStateOf(s.client)};var phone by remember(s.id){mutableStateOf(s.phone)};var service by remember(s.id){mutableStateOf(s.service)};var account by remember(s.id){mutableStateOf(s.account)};var password by remember(s.id){mutableStateOf(s.password)};var profile by remember(s.id){mutableStateOf(s.profile)};var pin by remember(s.id){mutableStateOf(s.pin)};var type by remember(s.id){mutableStateOf(s.type)};var price by remember(s.id){mutableStateOf(s.price.toString())};var cost by remember(s.id){mutableStateOf(s.accountCost.toString())};var method by remember(s.id){mutableStateOf(s.paymentMethod)};var start by remember(s.id){mutableStateOf(s.start)};var end by remember(s.id){mutableStateOf(s.end)};var provider by remember(s.id){mutableStateOf(s.provider)};var providerPhone by remember(s.id){mutableStateOf(s.providerPhone)};var purchaseDate by remember(s.id){mutableStateOf(s.purchaseDate.ifBlank{s.start})};var accountEnd by remember(s.id){mutableStateOf(s.accountEnd)};var renewCost by remember(s.id){mutableStateOf(s.accountRenewCost.toString())}
 AlertDialog(onDismissRequest=close,title={Text("Editar entrega / cuenta")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){
  item{Text("DATOS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{F("Cliente",client){client=it}};item{F("WhatsApp",phone){phone=it}};item{F("Servicio",service){service=it}}
  item{Text("CREDENCIALES",fontWeight=FontWeight.Bold)};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};item{F("Perfil / pantalla (opcional)",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}};item{F("Tipo de entrega",type){type=it}}
  item{Text("FECHAS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{F("Inicio AAAA-MM-DD",start){start=it}};item{F("Vence AAAA-MM-DD",end){end=it}}
  item{Text("VENTA",fontWeight=FontWeight.Bold)};item{F("Precio cobrado",price){price=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Método de pago",method){method=it}}
  item{Text("PROVEEDOR / CUENTA COMPLETA",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Fecha de compra AAAA-MM-DD",purchaseDate){purchaseDate=it}};item{F("Vencimiento de cuenta AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&runCatching{LocalDate.parse(start);LocalDate.parse(end)}.isSuccess,onClick={save(s.copy(client=client,phone=phone,service=service,account=account,password=password,profile=profile,pin=pin,type=type,price=price.filter{it.isDigit()}.toLongOrNull()?:0,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,paymentMethod=method,start=start,end=end,provider=normalizedProviderStorage(provider),providerPhone=providerPhone,accountEnd=accountEnd,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0,purchaseDate=purchaseDate))}){Text("Guardar cambios")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun QuickCollectionDialog(queue:List<Sub>,close:()->Unit,send:(Sub)->Unit,contact:(Sub)->Unit,renew:(Sub)->Unit){
 var index by remember{mutableIntStateOf(0)};if(queue.isEmpty()){close();return};val current=queue[index.coerceAtMost(queue.lastIndex)]
 AlertDialog(onDismissRequest=close,title={Text("Cobranza rápida ${index+1}/${queue.size}")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text(current.client,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text("${current.service} • vence ${current.end}");Text(money(current.price),style=MaterialTheme.typography.titleLarge,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold);if(current.lastContact.isNotBlank())Text(contactLabel(current.lastContact).replace("CONTACTADO ","Último contacto: ").lowercase().replaceFirstChar{it.uppercase()},style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Button({send(current);contact(current);if(index<queue.lastIndex)index++ else close()},Modifier.fillMaxWidth()){Text("WhatsApp y siguiente")};OutlinedButton({renew(current);if(index<queue.lastIndex)index++ else close()},Modifier.fillMaxWidth()){Text("Renovó +30 y siguiente")}}},confirmButton={if(index<queue.lastIndex)TextButton({index++}){Text("Omitir")}},dismissButton={TextButton(close){Text("Salir")}})
}

@Composable fun GlobalSearchDialog(s:List<Sub>,stock:List<StockItem>,templates:Templates,close:()->Unit,credentials:(Sub)->Unit,edit:(Sub)->Unit){
 var q by remember{mutableStateOf("")};val terms=q.trim();val clients=if(terms.length<2)emptyList() else s.filter{listOf(it.client,it.phone,it.service,it.account,it.profile,it.provider).any{x->x.contains(terms,true)}}.take(12);val items=if(terms.length<2)emptyList() else stock.filter{listOf(it.service,it.account,it.profile,it.provider).any{x->x.contains(terms,true)}}.take(12)
 AlertDialog(onDismissRequest=close,title={Text("Búsqueda global")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){item{OutlinedTextField(q,{q=it},label={Text("Cliente, correo, servicio, teléfono…")},singleLine=true,modifier=Modifier.fillMaxWidth())};if(terms.length<2)item{Text("Escribe al menos 2 caracteres.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};if(clients.isNotEmpty())item{Text("CLIENTES / ENTREGAS",fontWeight=FontWeight.Bold)};items(clients){x->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text(x.client,fontWeight=FontWeight.Bold);Text("${x.service} • ${x.account}",style=MaterialTheme.typography.bodySmall);Row{TextButton({credentials(x)}){Text("Credenciales")};TextButton({edit(x)}){Text("Editar")}}}}};if(items.isNotEmpty())item{Text("STOCK",fontWeight=FontWeight.Bold)};items(items){x->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text(x.service,fontWeight=FontWeight.Bold);Text(x.account,style=MaterialTheme.typography.bodySmall);Text("${if(isComplete(x))"Cuenta completa" else x.profile} • ${effectiveStockStatus(x)}",style=MaterialTheme.typography.labelSmall)}}}}},confirmButton={TextButton(close){Text("Cerrar")}})
}

@Composable fun ServiceTemplatesDialog(initial:List<ServiceTemplate>,close:()->Unit,save:(List<ServiceTemplate>)->Unit){
 var list by remember{mutableStateOf(initial)};var editId by remember{mutableStateOf<Long?>(null)};var name by remember{mutableStateOf("")};var type by remember{mutableStateOf("CUENTA COMPLETA")};var duration by remember{mutableStateOf("30")};var price by remember{mutableStateOf("")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 fun clear(){editId=null;name="";type="CUENTA COMPLETA";duration="30";price="";provider="";providerPhone="";cost="";renewCost=""}
 fun load(t:ServiceTemplate){editId=t.id;name=t.name;type=t.type;duration=t.durationDays.toString();price=t.defaultPrice.toString();provider=t.provider;providerPhone=t.providerPhone;cost=t.accountCost.toString();renewCost=t.renewCost.toString()}
 AlertDialog(onDismissRequest=close,title={Text("Plantillas de servicios")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){item{Text("Una plantilla completa automáticamente duración, precio y proveedor al crear stock o una venta.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{F("Servicio",name){name=it}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(type=="CUENTA COMPLETA",{type="CUENTA COMPLETA"},{Text("Cuenta completa")},modifier=Modifier.weight(1f));FilterChip(type=="PERFIL/PANTALLA",{type="PERFIL/PANTALLA"},{Text("Perfil")},modifier=Modifier.weight(1f))}};item{F("Duración (días)",duration){duration=it}};item{F("Precio habitual",price){price=it}};item{F("Proveedor habitual",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Costo de cuenta",cost){cost=it}};item{F("Costo de renovar",renewCost){renewCost=it}};item{Button({val item=ServiceTemplate(id=editId?:System.currentTimeMillis(),name=name,type=type,durationDays=duration.toIntOrNull()?.coerceAtLeast(1)?:30,defaultPrice=price.filter{it.isDigit()}.toLongOrNull()?:0,provider=normalizedProviderStorage(provider),providerPhone=providerPhone,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,renewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0);list=if(editId==null)list+item else list.map{if(it.id==item.id)item else it};clear()},enabled=name.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text(if(editId==null)"Agregar plantilla" else "Guardar cambios")}};if(list.isNotEmpty())item{Text("GUARDADAS",fontWeight=FontWeight.Bold)};items(list){t->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(9.dp)){Text(t.name,fontWeight=FontWeight.Bold);Text("${if(t.type=="CUENTA COMPLETA")"Cuenta completa" else "Perfil"} • ${t.durationDays} días • ${money(t.defaultPrice)}",style=MaterialTheme.typography.bodySmall);Row{TextButton({load(t)}){Text("Editar")};TextButton({list=list.filterNot{it.id==t.id}}){Text("Eliminar")}}}}}}},confirmButton={Button({save(list)}){Text("Guardar todo")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun F(l:String,v:String,c:(String)->Unit){OutlinedTextField(v,c,label={Text(l)},singleLine=false,modifier=Modifier.fillMaxWidth())}

plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }

android {
 namespace="com.nexo.suscripciones"
 compileSdk=36

 defaultConfig {
  applicationId="com.nexo.suscripciones"
  minSdk=26
  targetSdk=36
  versionCode=21
  versionName="6.5.2"
 }

 signingConfigs {
  create("release") {
   val keyPath = System.getenv("ANDROID_KEYSTORE_PATH")
   if (!keyPath.isNullOrBlank()) {
    storeFile = file(keyPath)
    storePassword = System.getenv("KEYSTORE_PASSWORD")
    keyAlias = System.getenv("KEY_ALIAS")
    keyPassword = System.getenv("KEY_PASSWORD")
   }
  }
 }

 buildTypes {
  getByName("release") {
   isMinifyEnabled=false
   if (!System.getenv("ANDROID_KEYSTORE_PATH").isNullOrBlank()) {
    signingConfig = signingConfigs.getByName("release")
   }
  }
 }

 compileOptions {
  sourceCompatibility = JavaVersion.VERSION_17
  targetCompatibility = JavaVersion.VERSION_17
 }
 kotlinOptions { jvmTarget = "17" }
 buildFeatures { compose=true }
 packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
 implementation(platform("androidx.compose:compose-bom:2024.12.01"))
 implementation("androidx.activity:activity-compose:1.10.0")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.compose.material:material-icons-extended")
 implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.ui:ui-tooling-preview")
 debugImplementation("androidx.compose.ui:ui-tooling")
 implementation("androidx.work:work-runtime-ktx:2.10.0")
 implementation("androidx.core:core-ktx:1.15.0")
}

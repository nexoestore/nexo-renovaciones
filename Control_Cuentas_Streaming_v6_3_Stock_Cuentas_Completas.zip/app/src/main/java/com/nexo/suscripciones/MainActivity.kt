package com.nexo.suscripciones

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Sub(val id:Long=System.currentTimeMillis(),val client:String,val phone:String,val service:String,val account:String,val profile:String,val type:String,val price:Long,val start:String,val end:String,val status:String="ACTIVO",val paid:Boolean=true,val pin:String="",val accountCost:Long=0,val paymentMethod:String="Efectivo",val contacted:Boolean=false,val password:String="",val provider:String="",val providerPhone:String="",val accountEnd:String="",val accountRenewCost:Long=0,val promiseDate:String="",val stockId:Long=0)
data class StockItem(val id:Long=System.currentTimeMillis(),val service:String,val account:String,val password:String="",val profile:String="",val pin:String="",val type:String="PERFIL/PANTALLA",val provider:String="",val providerPhone:String="",val accountEnd:String="",val accountCost:Long=0,val accountRenewCost:Long=0,val status:String="DISPONIBLE")
data class Hist(val id:Long=System.currentTimeMillis(),val subId:Long,val date:String,val action:String,val amount:Long=0,val method:String="")
data class Templates(val due3:String="Hola {cliente} 👋 Tu servicio {servicio} vence el {fecha}. Valor de renovación: ${'$'}{precio}.",val due1:String="Hola {cliente} 👋 Te recordamos que tu servicio {servicio} vence mañana ({fecha}). Valor: ${'$'}{precio}.",val due0:String="Hola {cliente} 👋 Tu servicio {servicio} vence hoy ({fecha}). Si deseas continuar, puedes renovar por ${'$'}{precio}.",val expired:String="Hola {cliente} 👋 Tu servicio {servicio} venció el {fecha}. Si deseas reactivarlo, escríbeme para renovar.",val delivery:String="Hola {cliente} 👋 Aquí tienes tus datos de {servicio}:\nCuenta: {cuenta}\nContraseña: {password}\nPerfil: {perfil}\nPIN/clave: {pin}\nVence: {fecha}\nGracias por preferir Nexo.")

class Store(private val c:Context){private val p=c.getSharedPreferences("nexo_db",Context.MODE_PRIVATE)
 fun subs():MutableList<Sub>{val a=JSONArray(p.getString("subs","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Sub(o.getLong("id"),o.getString("client"),o.optString("phone"),o.getString("service"),o.optString("account"),o.optString("profile"),o.optString("type","PERFIL"),o.optLong("price"),o.getString("start"),o.getString("end"),o.optString("status","ACTIVO"),o.optBoolean("paid",true),o.optString("pin"),o.optLong("accountCost"),o.optString("paymentMethod","Efectivo"),o.optBoolean("contacted",false),o.optString("password",""),o.optString("provider",""),o.optString("providerPhone",""),o.optString("accountEnd",""),o.optLong("accountRenewCost"),o.optString("promiseDate",""),o.optLong("stockId",0))}}
 fun save(s:List<Sub>){val a=JSONArray();s.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("client",x.client);put("phone",x.phone);put("service",x.service);put("account",x.account);put("profile",x.profile);put("type",x.type);put("price",x.price);put("start",x.start);put("end",x.end);put("status",x.status);put("paid",x.paid);put("pin",x.pin);put("accountCost",x.accountCost);put("paymentMethod",x.paymentMethod);put("contacted",x.contacted);put("password",x.password);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountRenewCost",x.accountRenewCost);put("promiseDate",x.promiseDate);put("stockId",x.stockId)})};p.edit().putString("subs",a.toString()).apply();ReminderScheduler.sync(c,s)}
 fun stock():MutableList<StockItem>{val a=JSONArray(p.getString("stock","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);StockItem(o.getLong("id"),o.optString("service"),o.optString("account"),o.optString("password"),o.optString("profile"),o.optString("pin"),o.optString("type","PERFIL/PANTALLA"),o.optString("provider"),o.optString("providerPhone"),o.optString("accountEnd"),o.optLong("accountCost"),o.optLong("accountRenewCost"),o.optString("status","DISPONIBLE"))}}
 fun saveStock(items:List<StockItem>){val a=JSONArray();items.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("service",x.service);put("account",x.account);put("password",x.password);put("profile",x.profile);put("pin",x.pin);put("type",x.type);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountCost",x.accountCost);put("accountRenewCost",x.accountRenewCost);put("status",x.status)})};p.edit().putString("stock",a.toString()).apply()}
 fun hist():MutableList<Hist>{val a=JSONArray(p.getString("hist","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Hist(o.getLong("id"),o.getLong("subId"),o.getString("date"),o.getString("action"),o.optLong("amount"),o.optString("method"))}}
 fun saveHist(h:List<Hist>){val a=JSONArray();h.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("subId",x.subId);put("date",x.date);put("action",x.action);put("amount",x.amount);put("method",x.method)})};p.edit().putString("hist",a.toString()).apply()}
 fun templates():Templates{val o=runCatching{JSONObject(p.getString("templates","{}")!!)}.getOrDefault(JSONObject());val d=Templates();val oldDelivery=o.optString("delivery",d.delivery);val delivery=if(oldDelivery.contains("{password}"))oldDelivery else oldDelivery.replace("Cuenta: {cuenta}","Cuenta: {cuenta}\nContraseña: {password}");return Templates(o.optString("due3",d.due3),o.optString("due1",d.due1),o.optString("due0",d.due0),o.optString("expired",d.expired),delivery)}
 fun saveTemplates(t:Templates){p.edit().putString("templates",JSONObject().apply{put("due3",t.due3);put("due1",t.due1);put("due0",t.due0);put("expired",t.expired);put("delivery",t.delivery)}.toString()).apply()}
 fun backup():String=JSONObject().apply{put("backupVersion",3);put("appVersion","6.3");put("subs",JSONArray(p.getString("subs","[]")));put("stock",JSONArray(p.getString("stock","[]")));put("hist",JSONArray(p.getString("hist","[]")));put("templates",JSONObject(p.getString("templates","{}")!!))}.toString(2)
 fun restore(text:String):Boolean=runCatching{val o=JSONObject(text);p.edit().putString("subs",o.getJSONArray("subs").toString()).putString("stock",o.optJSONArray("stock")?.toString()?:"[]").putString("hist",o.optJSONArray("hist")?.toString()?:"[]").putString("templates",o.optJSONObject("templates")?.toString()?:"{}").commit();ReminderScheduler.sync(c,subs());true}.getOrDefault(false)
}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);ReminderScheduler.sync(this,Store(this).subs());if(android.os.Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),1001);setContent{NexoApp()}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun NexoApp(){
 val c=LocalContext.current
 val st=remember{Store(c)}
 var subs by remember{mutableStateOf(st.subs().toList())}
 var hist by remember{mutableStateOf(st.hist().toList())}
 var stock by remember{mutableStateOf(st.stock().toList())}
 var templates by remember{mutableStateOf(st.templates())}
 var tab by remember{mutableIntStateOf(0)}
 var add by remember{mutableStateOf(false)}
 var dark by remember{mutableStateOf(false)}
 var editing by remember{mutableStateOf<Sub?>(null)}
 fun persist(s:List<Sub>){subs=s;st.save(s)}
 fun persistStock(items:List<StockItem>){stock=items;st.saveStock(items)}
 fun log(id:Long,a:String,m:Long=0,method:String=""){hist=hist+Hist(subId=id,date=LocalDate.now().toString(),action=a,amount=m,method=method);st.saveHist(hist)}
 fun renew(s:Sub){val old=LocalDate.parse(s.end);val base=if(old.isBefore(LocalDate.now()))LocalDate.now() else old;persist(subs.map{if(it.id==s.id)it.copy(end=base.plusDays(30).toString(),status="ACTIVO",paid=true,contacted=false)else it});log(s.id,"RENOVACIÓN +30 DÍAS",s.price,s.paymentMethod)}
 fun cut(s:Sub,reason:String){persist(subs.map{if(it.id==s.id)it.copy(status="CORTADO",profile=if(it.stockId>0)it.profile else "LIBRE",contacted=true)else it});if(s.stockId>0)persistStock(stock.map{if(it.id==s.stockId)it.copy(status="DISPONIBLE")else it});log(s.id,"BAJA • $reason • ${s.service} • ACCESO LIBERADO")}
 fun promise(s:Sub,date:String){persist(subs.map{if(it.id==s.id)it.copy(status="ESPERA",promiseDate=date)else it});log(s.id,"PROMESA DE PAGO • $date")}
 fun adjustEnd(s:Sub,newEnd:String,reason:String){val old=s.end;persist(subs.map{if(it.id==s.id)it.copy(end=newEnd,status="ACTIVO")else it});log(s.id,"AJUSTE VENCIMIENTO: $old → $newEnd${if(reason.isNotBlank())" • $reason" else ""}")}
 fun updateSub(updated:Sub){persist(subs.map{if(it.id==updated.id)updated else it});if(updated.stockId>0)persistStock(stock.map{if(it.id==updated.stockId)it.copy(service=updated.service,account=updated.account,password=updated.password,profile=updated.profile,pin=updated.pin,type=updated.type,provider=updated.provider,providerPhone=updated.providerPhone,accountEnd=updated.accountEnd,accountCost=updated.accountCost,accountRenewCost=updated.accountRenewCost)else it});log(updated.id,"EDICIÓN DE ENTREGA / CUENTA")}
 val streamDark=darkColorScheme(
  primary=StreamCyan,secondary=StreamGreen,tertiary=StreamAmber,
  background=Color(0xFF071018),surface=Color(0xFF0D1821),surfaceVariant=Color(0xFF17232C),
  outline=Color(0xFF70818D),outlineVariant=Color(0xFF26343E)
 )
 val streamLight=lightColorScheme(primary=Color(0xFF006B7D),secondary=Color(0xFF006C50),tertiary=Color(0xFF7A5900),surfaceVariant=Color(0xFFE7F0F4))
 val appShapes=Shapes(small=RoundedCornerShape(10.dp),medium=RoundedCornerShape(16.dp),large=RoundedCornerShape(22.dp))
 MaterialTheme(colorScheme=if(dark)streamDark else streamLight,shapes=appShapes){
  Scaffold(
   topBar={TopAppBar(
    title={Text("Control de Cuentas Streaming",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,maxLines=1)},
    colors=TopAppBarDefaults.topAppBarColors(containerColor=MaterialTheme.colorScheme.background)
   )},
   floatingActionButton={if(tab==0)FloatingActionButton({add=true},containerColor=MaterialTheme.colorScheme.primary){Text("＋",style=MaterialTheme.typography.titleLarge)}},
   bottomBar={NavigationBar(containerColor=MaterialTheme.colorScheme.surface){
    val labels=listOf("Inicio","Renovar","Cuentas","Reportes","Más")
    val glyphs=listOf("⌂","↻","▣","▤","☰")
    labels.forEachIndexed{i,x->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(glyphs[i],style=MaterialTheme.typography.titleMedium)},label={Text(x)})}
   }}
  ){pad->Box(Modifier.padding(pad)){when(tab){
   0->Home(subs,stock,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,{s->persist(subs.map{if(it.id==s.id)it.copy(contacted=true)else it});log(s.id,"CONTACTADO POR WHATSAPP")},{editing=it})
   1->Renewals(subs,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,{s->persist(subs.map{if(it.id==s.id)it.copy(contacted=true)else it});log(s.id,"CONTACTADO POR WHATSAPP")},{editing=it})
   2->Accounts(subs,stock,::persistStock,{sold,item->persist(subs+sold);persistStock(stock.map{if(it.id==item.id)it.copy(status="OCUPADO")else it});log(sold.id,"VENTA / PAGO DESDE STOCK",sold.price,sold.paymentMethod);wa(c,sold,fillTemplate(templates.delivery,sold))},::adjustEnd,{editing=it})
   3->Reports(subs,stock,hist)
   else->More(subs,stock,hist,dark,{dark=it},templates,{templates=it;st.saveTemplates(it)},st,{subs=st.subs();hist=st.hist();stock=st.stock()})
  }}}
  if(add)AddDialog({add=false}){s->persist(subs+s);log(s.id,"VENTA / PAGO",s.price,s.paymentMethod);wa(c,s,fillTemplate(templates.delivery,s));add=false}
  editing?.let{current->EditSubDialog(current,{editing=null}){updated->updateSub(updated);editing=null}}
 }
}

val StreamCyan=Color(0xFF27C9E8)
val StreamGreen=Color(0xFF49C878)
val StreamAmber=Color(0xFFFFB547)
val StreamRed=Color(0xFFFF5C68)
val StreamPurple=Color(0xFF9A7CFF)

fun days(s:Sub)=ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.end))
fun accountDays(s:Sub)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.accountEnd))}.getOrDefault(999)
fun effectiveStockStatus(x:StockItem):String{val expired=x.accountEnd.isNotBlank()&&runCatching{LocalDate.parse(x.accountEnd).isBefore(LocalDate.now())}.getOrDefault(false);return if(expired)"NO_DISPONIBLE" else x.status}
fun stockAccountDays(x:StockItem)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(x.accountEnd))}.getOrDefault(999)
fun money(v:Long)="$${"%,d".format(v)}"
fun fillTemplate(t:String,s:Sub):String{
 val values=mapOf("{cliente}" to s.client,"{servicio}" to s.service,"{fecha}" to s.end,"{precio}" to money(s.price),"{cuenta}" to s.account,"{perfil}" to s.profile,"{pin}" to s.pin,"{password}" to s.password)
 val optional=setOf("{cuenta}","{password}","{perfil}","{pin}")
 return t.lines()
  .filterNot{line->optional.any{key->line.contains(key)&&values[key].isNullOrBlank()}}
  .map{line->values.entries.fold(line){acc,(k,v)->acc.replace(k,v)}}
  .joinToString("\n")
  .replace(Regex("\n{3,}"),"\n\n")
  .trim()
}
fun messageFor(s:Sub,t:Templates):String=fillTemplate(when{days(s)<0->t.expired;days(s)==0L->t.due0;days(s)==1L->t.due1;else->t.due3},s)
fun wa(c:Context,s:Sub,msg:String){val u="https://wa.me/${s.phone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun ScreenHeader(title:String,subtitle:String){Column(verticalArrangement=Arrangement.spacedBy(3.dp)){Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text(subtitle,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun SectionTitle(title:String,subtitle:String=""){Column(Modifier.padding(top=4.dp,bottom=2.dp)){Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);if(subtitle.isNotBlank())Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun MetricCard(label:String,value:String,accent:Color,modifier:Modifier=Modifier){Card(modifier,colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.62f))){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){Text(value,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=accent);Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
@Composable fun StatusBadge(label:String,color:Color){Surface(shape=RoundedCornerShape(50),color=color.copy(alpha=.15f),contentColor=color){Text(label,Modifier.padding(horizontal=9.dp,vertical=4.dp),style=MaterialTheme.typography.labelSmall,fontWeight=FontWeight.Bold)}}
@Composable fun EmptyState(text:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.35f))){Text(text,Modifier.padding(16.dp),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}

@Composable fun Home(s:List<Sub>,stock:List<StockItem>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val today=s.count{it.status!="CORTADO"&&days(it)==0L};val tomorrow=s.count{it.status!="CORTADO"&&days(it)==1L};val d3=s.count{it.status!="CORTADO"&&days(it) in 2..3};val expired=s.count{it.status!="CORTADO"&&days(it)<0};val free=stock.count{effectiveStockStatus(it)=="DISPONIBLE"}+s.count{it.stockId==0&&(it.status=="CORTADO"||it.profile=="LIBRE")};val accounts=s.filter{it.account.isNotBlank()}.distinctBy{it.account};val stockAccounts=stock.filter{it.account.isNotBlank()}.distinctBy{it.account};val dueSubs=accounts.filter{accountDays(it) in 0..3};val dueStock=stockAccounts.filter{stockAccountDays(it) in 0..3&&dueSubs.none{s2->s2.account==it.account}};val providerDue=dueSubs.size+dueStock.size;val noSpace=s.groupBy{it.account}.count{it.key.isNotBlank()&&it.value.none{x->x.status=="CORTADO"||x.profile=="LIBRE"}};val value=s.filter{it.status!="CORTADO"&&days(it)<=3}.sumOf{it.price};val work=s.filter{it.status!="CORTADO"&&days(it)<=3}.sortedBy{it.end}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Panel de control","Hoy • ${LocalDate.now()}  ·  operación de streaming")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){MetricCard("Vencen hoy",today.toString(),if(today>0)StreamRed else StreamGreen,Modifier.weight(1f));MetricCard("Mañana",tomorrow.toString(),if(tomorrow>0)StreamAmber else StreamGreen,Modifier.weight(1f))}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){MetricCard("Vencidos",expired.toString(),if(expired>0)StreamRed else StreamGreen,Modifier.weight(1f));MetricCard("Disponibles",free.toString(),StreamGreen,Modifier.weight(1f))}}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Cuentas completas",fontWeight=FontWeight.Bold);Text("Inventario y proveedor",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(providerDue>0)"$providerDue por renovar" else "Al día",if(providerDue>0)StreamRed else StreamGreen)}
   HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Próximas al corte");Text(providerDue.toString(),fontWeight=FontWeight.Bold)}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Sin espacio");Text(noSpace.toString(),fontWeight=FontWeight.Bold)}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vencen en 2–3 días");Text(d3.toString(),fontWeight=FontWeight.Bold)}
  }}}
  item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primary.copy(alpha=.10f))){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Cobros próximos",fontWeight=FontWeight.Bold);Text("Valor por renovar",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Text(money(value),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}}}
  if(providerDue>0){item{SectionTitle("Cuentas por renovar","Vencimiento de proveedor en los próximos 3 días")};items(dueSubs){x->ProviderDueCard(x)};items(dueStock){x->ProviderDueStockCard(x)}}
  item{SectionTitle("Trabajo de hoy","Clientes que requieren seguimiento")}
  if(work.isEmpty())item{EmptyState("No tienes renovaciones o cortes pendientes para hoy.")}
  items(work){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}
 }
}

@Composable fun ProviderDueCard(s:Sub){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(s.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("Corte ${s.accountEnd.ifBlank{"sin fecha"}}",StreamRed)};Text(s.account,style=MaterialTheme.typography.bodyMedium);Text("Proveedor · ${s.provider.ifBlank{"Sin asignar"}}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Renovación ${money(s.accountRenewCost)}",fontWeight=FontWeight.SemiBold)}}}

@Composable fun ProviderDueStockCard(x:StockItem){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(x.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("Corte ${x.accountEnd.ifBlank{"sin fecha"}}",StreamRed)};Text(x.account,style=MaterialTheme.typography.bodyMedium);Text("Proveedor · ${x.provider.ifBlank{"Sin asignar"}}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Costo de renovar ${money(x.accountRenewCost)}",fontWeight=FontWeight.SemiBold);StatusBadge(if(effectiveStockStatus(x)=="DISPONIBLE")"STOCK DISPONIBLE" else effectiveStockStatus(x).replace('_',' '),if(effectiveStockStatus(x)=="DISPONIBLE")StreamGreen else StreamRed)}}}

@Composable fun Renewals(s:List<Sub>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val groups=listOf("En 3 días" to s.filter{it.status!="CORTADO"&&days(it) in 2..3},"Mañana" to s.filter{it.status!="CORTADO"&&days(it)==1L},"Hoy" to s.filter{it.status!="CORTADO"&&days(it)==0L},"Vencidos" to s.filter{it.status!="CORTADO"&&days(it)<0&&it.status!="ESPERA"},"En espera" to s.filter{it.status=="ESPERA"})
 val total=groups.sumOf{it.second.size}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{ScreenHeader("Renovaciones","Cobros, cortes y promesas de pago")}
  item{LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(groups){g->AssistChip(onClick={},label={Text("${g.first}  ${g.second.size}")})}}}
  if(total==0)item{EmptyState("Todo al día. No hay clientes pendientes de renovación.")}
  groups.filter{it.second.isNotEmpty()}.forEach{(title,list)->item{SectionTitle(title,"${list.size} cliente${if(list.size==1)"" else "s"}")};items(list.sortedBy{it.end}){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}}
 }
}

@Composable fun ActionCard(s:Sub,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 var showAdjust by remember(s.id){mutableStateOf(false)};var showEnd by remember(s.id){mutableStateOf(false)};var showPromise by remember(s.id){mutableStateOf(false)};var more by remember(s.id){mutableStateOf(false)};val ctx=LocalContext.current
 val d=days(s);val status=when{ s.status=="ESPERA"->"EN ESPERA";d<0->"VENCIDO";d==0L->"VENCE HOY";d==1L->"MAÑANA";else->"PRÓXIMO"};val color=when{ s.status=="ESPERA"->StreamPurple;d<0->StreamRed;d<=1->StreamAmber;else->StreamCyan}
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(s.client,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text(s.service,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(status,color)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vence ${s.end}",style=MaterialTheme.typography.bodyMedium);Text(money(s.price),fontWeight=FontWeight.Bold)}
  Text(s.type,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.account.isNotBlank())Text(s.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.profile.isNotBlank())Text("Perfil ${s.profile}${if(s.pin.isNotBlank())"  ·  PIN guardado" else ""}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.contacted)StatusBadge("CONTACTADO",StreamGreen)
  if(s.promiseDate.isNotBlank())Surface(shape=RoundedCornerShape(10.dp),color=StreamPurple.copy(alpha=.10f)){Text("Promesa de pago · ${s.promiseDate}",Modifier.padding(9.dp),style=MaterialTheme.typography.bodySmall,color=StreamPurple)}
  Button({wa(s);contact(s)},modifier=Modifier.fillMaxWidth()){Text("Cobrar por WhatsApp")}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({renew(s)},modifier=Modifier.weight(1f)){Text("Renovar +30")};if(d<=0)OutlinedButton({showPromise=true},modifier=Modifier.weight(1f)){Text("Dar plazo")}}
  if(d<=0)TextButton({showEnd=true},colors=ButtonDefaults.textButtonColors(contentColor=StreamRed),modifier=Modifier.fillMaxWidth()){Text("No renovó / finalizar servicio")}
  TextButton({more=!more},modifier=Modifier.fillMaxWidth()){Text(if(more)"Ocultar opciones" else "Más opciones")}
  if(more){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);OutlinedButton({wa(ctx,s,fillTemplate(Store(ctx).templates().delivery,s))},modifier=Modifier.fillMaxWidth()){Text("Enviar credenciales")};OutlinedButton({edit(s)},modifier=Modifier.fillMaxWidth()){Text("Editar entrega / cuenta")};OutlinedButton({showAdjust=true},modifier=Modifier.fillMaxWidth()){Text("Ajustar vencimiento")}}
 }}
 if(showAdjust)AdjustEndDialog(s,{showAdjust=false}){date,reason->adjust(s,date,reason);showAdjust=false};if(showEnd)EndServiceDialog(s,{showEnd=false}){reason->cut(s,reason);showEnd=false};if(showPromise)PromiseDialog(s,{showPromise=false}){date->promise(s,date);showPromise=false}
}

@Composable fun Accounts(s:List<Sub>,stock:List<StockItem>,saveStock:(List<StockItem>)->Unit,sell:(Sub,StockItem)->Unit,adjust:(Sub,String,String)->Unit,edit:(Sub)->Unit){
 val ctx=LocalContext.current
 val st=remember{Store(ctx)}
 var adjusting by remember{mutableStateOf<Sub?>(null)}
 var section by remember{mutableStateOf("CUENTAS")}
 var addStock by remember{mutableStateOf(false)}
 var selling by remember{mutableStateOf<StockItem?>(null)}
 var editingStock by remember{mutableStateOf<StockItem?>(null)}
 val grouped=s.filter{it.account.isNotBlank()}.groupBy{it.account}
 val occupied=s.count{it.status!="CORTADO"}
 val available=stock.count{effectiveStockStatus(it)=="DISPONIBLE"}+s.count{it.stockId==0&&(it.status=="CORTADO"||it.profile=="LIBRE")}
 val unavailable=stock.count{effectiveStockStatus(it)=="NO_DISPONIBLE"}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Cuentas y stock","Control de cuentas completas y accesos listos para vender")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
   FilterChip(selected=section=="CUENTAS",onClick={section="CUENTAS"},label={Text("Cuentas completas")},modifier=Modifier.weight(1f))
   FilterChip(selected=section=="STOCK",onClick={section="STOCK"},label={Text("Stock disponible")},modifier=Modifier.weight(1f))
  }}
  if(section=="CUENTAS"){
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Cuentas",grouped.size.toString(),StreamCyan,Modifier.weight(1f));MetricCard("Ocupados",occupied.toString(),StreamPurple,Modifier.weight(1f))}}
   if(grouped.isEmpty())item{EmptyState("Aún no hay cuentas completas registradas.")}
   items(grouped.entries.toList()){e->
    val base=e.value.first();val cost=e.value.maxOfOrNull{it.accountCost}?:0;val income=e.value.filter{it.status!="CORTADO"}.sumOf{it.price};val profit=income-cost;val active=e.value.count{it.status!="CORTADO"}
    Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
     Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(base.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text(e.key,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge("$active ocupado${if(active==1)"" else "s"}",if(active>0)StreamCyan else StreamGreen)}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Costo",money(cost),Modifier.weight(1f));MiniStat("Ingreso",money(income),Modifier.weight(1f));MiniStat("Utilidad",money(profit),Modifier.weight(1f),if(profit>=0)StreamGreen else StreamRed)}
     HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
     Text("Proveedor",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(base.provider.ifBlank{"Sin proveedor asignado"},fontWeight=FontWeight.SemiBold)
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vencimiento de cuenta",style=MaterialTheme.typography.bodySmall);Text(base.accountEnd.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Costo de renovar cuenta",style=MaterialTheme.typography.bodySmall);Text(money(base.accountRenewCost),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
     if(base.providerPhone.isNotBlank())OutlinedButton({waProvider(ctx,base)},Modifier.fillMaxWidth()){Text("Contactar proveedor")}
     SectionTitle("Accesos / perfiles")
     e.value.forEach{x->ProfileRow(x,{wa(ctx,x,fillTemplate(st.templates().delivery,x))},{edit(x)},{adjusting=x})}
    }}
   }
  }else{
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Disponibles",available.toString(),StreamGreen,Modifier.weight(1f));MetricCard("Ocupados",occupied.toString(),StreamCyan,Modifier.weight(1f));MetricCard("No disponibles",unavailable.toString(),if(unavailable>0)StreamRed else StreamGreen,Modifier.weight(1f))}}
   item{Button({addStock=true},Modifier.fillMaxWidth()){Text("+ Agregar stock")}}
   val services=(stock.map{it.service}+s.filter{it.status!="CORTADO"}.map{it.service}).filter{it.isNotBlank()}.distinct().sorted()
   if(services.isEmpty())item{EmptyState("Aún no hay stock registrado. Agrega cuentas completas o perfiles disponibles.")}
   services.forEach{service->
    item{StockServiceCard(service,stock.filter{it.service==service},s.filter{it.service==service&&it.status!="CORTADO"},{item->selling=item},{item->editingStock=item},{item->saveStock(stock.map{if(it.id==item.id)it.copy(status=if(effectiveStockStatus(it)=="NO_DISPONIBLE")"DISPONIBLE" else "NO_DISPONIBLE")else it})})}
   }
  }
 }
 adjusting?.let{x->AdjustEndDialog(x,{adjusting=null}){d,r->adjust(x,d,r);adjusting=null}}
 if(addStock)AddStockDialog({addStock=false}){item->saveStock(stock+item);addStock=false}
 selling?.let{item->SellStockDialog(item,{selling=null}){sub->sell(sub,item);selling=null}}
 editingStock?.let{item->EditStockDialog(item,{editingStock=null}){updated->saveStock(stock.map{if(it.id==updated.id)updated else it});editingStock=null}}
}

@Composable fun StockServiceCard(service:String,items:List<StockItem>,activeSubs:List<Sub>,sell:(StockItem)->Unit,edit:(StockItem)->Unit,toggle:(StockItem)->Unit){
 val available=items.count{effectiveStockStatus(it)=="DISPONIBLE"}
 val occupied=activeSubs.size
 val unavailable=items.count{effectiveStockStatus(it)=="NO_DISPONIBLE"}
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("$available disponibles",if(available>0)StreamGreen else StreamRed)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Disponibles",available.toString(),Modifier.weight(1f),StreamGreen);MiniStat("Ocupados",occupied.toString(),Modifier.weight(1f),StreamCyan);MiniStat("No disp.",unavailable.toString(),Modifier.weight(1f),if(unavailable>0)StreamRed else MaterialTheme.colorScheme.onSurface)}
  if(items.isEmpty())Text("No hay accesos cargados en stock para este servicio.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  items.forEach{x->StockItemRow(x,{sell(x)},{edit(x)},{toggle(x)})}
 }}
}

@Composable fun StockItemRow(x:StockItem,sell:()->Unit,edit:()->Unit,toggle:()->Unit){
 val status=effectiveStockStatus(x)
 val color=when(status){"DISPONIBLE"->StreamGreen;"OCUPADO"->StreamCyan;else->StreamRed}
 Column(verticalArrangement=Arrangement.spacedBy(6.dp)){
  HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(if(x.type.contains("CUENTA",true))"Cuenta completa" else x.profile.ifBlank{"Perfil / pantalla"},fontWeight=FontWeight.SemiBold);if(x.account.isNotBlank())Text(x.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);if(x.accountEnd.isNotBlank())Text("Vence cuenta: ${x.accountEnd}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(status.replace('_',' '),color)}
  if(status=="DISPONIBLE")Button(sell,Modifier.fillMaxWidth()){Text("Vender / asignar")}
  if(x.status=="OCUPADO")Text("Gestiona este acceso desde Cuentas completas.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant) else Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(edit,Modifier.weight(1f)){Text("Editar")};OutlinedButton(toggle,Modifier.weight(1f)){Text(if(status=="NO_DISPONIBLE")"Habilitar" else "No disponible")}}
 }
}

@Composable fun AddStockDialog(close:()->Unit,save:(StockItem)->Unit){
 var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var profile by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var type by remember{mutableStateOf("PERFIL/PANTALLA")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var accountEnd by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=close,title={Text("Agregar stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  item{Text("TIPO DE STOCK",fontWeight=FontWeight.Bold)}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=type=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA"},label={Text("Perfil / pantalla")},modifier=Modifier.weight(1f));FilterChip(selected=type=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA"},label={Text("Cuenta completa")},modifier=Modifier.weight(1f))}}
  item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}}
  if(type=="PERFIL/PANTALLA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}}}
  item{Text("PROVEEDOR",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Vence cuenta completa AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=service.isNotBlank()&&account.isNotBlank(),onClick={save(StockItem(service=service,account=account,password=password,profile=profile,pin=pin,type=type,provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0,status="DISPONIBLE"))}){Text("Guardar stock")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun EditStockDialog(x:StockItem,close:()->Unit,save:(StockItem)->Unit){
 var service by remember(x.id){mutableStateOf(x.service)};var account by remember(x.id){mutableStateOf(x.account)};var password by remember(x.id){mutableStateOf(x.password)};var profile by remember(x.id){mutableStateOf(x.profile)};var pin by remember(x.id){mutableStateOf(x.pin)};var type by remember(x.id){mutableStateOf(x.type)};var provider by remember(x.id){mutableStateOf(x.provider)};var providerPhone by remember(x.id){mutableStateOf(x.providerPhone)};var accountEnd by remember(x.id){mutableStateOf(x.accountEnd)};var cost by remember(x.id){mutableStateOf(x.accountCost.toString())};var renewCost by remember(x.id){mutableStateOf(x.accountRenewCost.toString())}
 AlertDialog(onDismissRequest=close,title={Text("Editar stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=type=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA"},label={Text("Perfil")},modifier=Modifier.weight(1f));FilterChip(selected=type=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA"},label={Text("Cuenta completa")},modifier=Modifier.weight(1f))}}
  item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};if(type=="PERFIL/PANTALLA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave",pin){pin=it}}};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Vence cuenta completa AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=service.isNotBlank()&&account.isNotBlank(),onClick={save(x.copy(service=service,account=account,password=password,profile=if(type=="CUENTA COMPLETA")"" else profile,pin=if(type=="CUENTA COMPLETA")"" else pin,type=type,provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun SellStockDialog(x:StockItem,close:()->Unit,save:(Sub)->Unit){
 var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var method by remember{mutableStateOf("Nequi")};var start by remember{mutableStateOf(LocalDate.now().toString())}
 AlertDialog(onDismissRequest=close,title={Text("Vender desde stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primary.copy(alpha=.08f))){Column(Modifier.padding(10.dp)){Text(x.service,fontWeight=FontWeight.Bold);Text(if(x.type.contains("CUENTA",true))"Cuenta completa" else x.profile.ifBlank{"Perfil / pantalla"},style=MaterialTheme.typography.bodySmall);Text(x.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
  item{F("Cliente",client){client=it}};item{F("WhatsApp (57...)",phone){phone=it}};item{F("Precio cobrado",price){price=it}};item{F("Método de pago",method){method=it}};item{F("Inicio AAAA-MM-DD",start){start=it}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&runCatching{LocalDate.parse(start)}.isSuccess,onClick={val d=LocalDate.parse(start);save(Sub(client=client,phone=phone,service=x.service,account=x.account,profile=x.profile,type=x.type,price=price.filter{it.isDigit()}.toLongOrNull()?:0,start=d.toString(),end=d.plusDays(30).toString(),pin=x.pin,accountCost=x.accountCost,paymentMethod=method,password=x.password,provider=x.provider,providerPhone=x.providerPhone,accountEnd=x.accountEnd,accountRenewCost=x.accountRenewCost,stockId=x.id))}){Text("Guardar y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun MiniStat(label:String,value:String,modifier:Modifier=Modifier,valueColor:Color=MaterialTheme.colorScheme.onSurface){Surface(modifier,shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.55f)){Column(Modifier.padding(9.dp)){Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value,style=MaterialTheme.typography.bodyMedium,fontWeight=FontWeight.Bold,color=valueColor)}}}
@Composable fun ProfileRow(s:Sub,credentials:()->Unit,edit:()->Unit,adjust:()->Unit){val free=s.status=="CORTADO";val expired=!free&&days(s)<0;Column(verticalArrangement=Arrangement.spacedBy(7.dp)){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(s.profile.ifBlank{s.type},fontWeight=FontWeight.SemiBold);if(!free)Text("${s.client}  ·  ${s.end}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(free)"LIBRE" else if(expired)"VENCIDO" else "ACTIVO",if(free)StreamGreen else if(expired)StreamRed else StreamCyan)};if(!free){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){TextButton(credentials,Modifier.weight(1f)){Text("Datos")};TextButton(edit,Modifier.weight(1f)){Text("Editar")};TextButton(adjust,Modifier.weight(1f)){Text("Fecha")}}}}}
fun waProvider(c:Context,s:Sub){val msg="Hola ${s.provider}, necesito revisar la cuenta ${s.account} de ${s.service}. Vence ${s.accountEnd}.";val u="https://wa.me/${s.providerPhone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun Reports(s:List<Sub>,stock:List<StockItem>,h:List<Hist>){
 val sales=h.filter{it.action.contains("VENTA")||it.action.contains("RENOVACIÓN")};val income=sales.sumOf{it.amount};val costEntries=(s.filter{it.account.isNotBlank()}.map{it.account to it.accountCost}+stock.filter{it.account.isNotBlank()}.map{it.account to it.accountCost});val costs=costEntries.groupBy{it.first}.values.sumOf{rows->rows.maxOfOrNull{it.second}?:0};val profit=income-costs;val active=s.count{it.status=="ACTIVO"&&days(it)>=0};val expired=s.count{it.status!="CORTADO"&&days(it)<0};val renewals=h.count{it.action.contains("RENOVACIÓN")}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Reportes","Dinero, cartera y actividad del negocio")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){MetricCard("Ingresos",money(income),StreamCyan,Modifier.weight(1f));MetricCard("Utilidad",money(profit),if(profit>=0)StreamGreen else StreamRed,Modifier.weight(1f))}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){MetricCard("Activos",active.toString(),StreamGreen,Modifier.weight(1f));MetricCard("Vencidos",expired.toString(),if(expired>0)StreamRed else StreamGreen,Modifier.weight(1f))}}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Resumen financiero",fontWeight=FontWeight.Bold);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Costo de cuentas");Text(money(costs),fontWeight=FontWeight.SemiBold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Renovaciones registradas");Text(renewals.toString(),fontWeight=FontWeight.SemiBold)}}}}
  item{SectionTitle("Actividad reciente","Ventas, renovaciones, ajustes y cambios")}
  if(h.isEmpty())item{EmptyState("Aún no hay movimientos registrados.")}
  items(h.sortedByDescending{it.id}.take(100)){x->val n=s.find{it.id==x.subId}?.client?:"Cliente";ActivityRow(x,n)}
 }
}
@Composable fun ActivityRow(x:Hist,client:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.42f))){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(client,fontWeight=FontWeight.SemiBold);Text(x.action,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(x.date,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};if(x.amount>0)Text(money(x.amount),fontWeight=FontWeight.Bold,color=StreamGreen)}}}

@Composable fun More(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,dark:Boolean,setDark:(Boolean)->Unit,t:Templates,setT:(Templates)->Unit,st:Store,reload:()->Unit){
 var edit by remember{mutableStateOf(false)};var incident by remember{mutableStateOf(false)};var filter by remember{mutableStateOf("Todos")};var query by remember{mutableStateOf("")};val c=LocalContext.current;var backupMsg by remember{mutableStateOf("")};val createBackup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null)runCatching{c.contentResolver.openOutputStream(u)?.bufferedWriter()?.use{it.write(st.backup())};backupMsg="Respaldo guardado correctamente"}.onFailure{backupMsg="No se pudo guardar el respaldo"}};val openBackup=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)runCatching{val txt=c.contentResolver.openInputStream(u)?.bufferedReader()?.use{it.readText()}?:"";if(st.restore(txt)){reload();backupMsg="Respaldo restaurado correctamente"}else backupMsg="Archivo no compatible"}}
 val filtered=h.sortedByDescending{it.id}.filter{x->val client=s.find{it.id==x.subId}?.client?:"Cliente";client.contains(query,true)&&(filter=="Todos"||x.action.contains(filter,true))};val providerNames=(s.map{it.provider}+stock.map{it.provider}).filter{it.isNotBlank()}.distinct().sorted();val clients=s.groupBy{it.client}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Más","Negocio, actividad y configuración")}
  item{SectionTitle("Negocio")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Proveedores",fontWeight=FontWeight.Bold);StatusBadge(providerNames.size.toString(),StreamCyan)};if(providerNames.isEmpty())Text("Sin proveedores registrados",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);providerNames.forEach{name->val accountCount=(s.filter{it.provider==name}.map{it.account}+stock.filter{it.provider==name}.map{it.account}).filter{it.isNotBlank()}.distinct().size;Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(name);Text("$accountCount cuenta${if(accountCount==1)"" else "s"}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}};OutlinedButton({incident=true},Modifier.fillMaxWidth()){Text("Registrar incidencia de cuenta")};HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Clientes",fontWeight=FontWeight.Bold);StatusBadge(clients.size.toString(),StreamGreen)};clients.entries.forEach{e->val total=h.filter{x->e.value.any{it.id==x.subId}&&x.amount>0}.sumOf{it.amount};val renews=h.count{x->e.value.any{it.id==x.subId}&&x.action.contains("RENOVACIÓN")};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column(Modifier.weight(1f)){Text(e.key);Text("$renews renovaciones",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Text(money(total),fontWeight=FontWeight.SemiBold)}}}}}
  item{SectionTitle("Actividad","Memoria comercial del negocio")}
  item{OutlinedTextField(query,{query=it},label={Text("Buscar cliente")},singleLine=true,modifier=Modifier.fillMaxWidth())}
  item{LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Todos","VENTA","RENOVACIÓN","AJUSTE","BAJA")){x->FilterChip(selected=filter==x,onClick={filter=x},label={Text(x.lowercase().replaceFirstChar{it.uppercase()})})}}}
  if(filtered.isEmpty())item{EmptyState("Sin actividad para este filtro.")}
  items(filtered.take(30)){x->ActivityRow(x,s.find{it.id==x.subId}?.client?:"Cliente")}
  item{SectionTitle("Aplicación")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Modo oscuro",fontWeight=FontWeight.SemiBold);Text("Apariencia de la aplicación",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(dark,setDark)};OutlinedButton({edit=true},Modifier.fillMaxWidth()){Text("Editar mensajes automáticos")}}}}
  item{SectionTitle("Copia de seguridad","Guarda tus datos en la memoria del teléfono")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){Button({createBackup.launch("Nexo_Backup_${LocalDate.now()}.nexo")},Modifier.fillMaxWidth()){Text("Crear respaldo local")};OutlinedButton({openBackup.launch(arrayOf("application/octet-stream","application/json","text/plain","*/*"))},Modifier.fillMaxWidth()){Text("Restaurar respaldo")};if(backupMsg.isNotBlank())Text(backupMsg,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
 }
 if(edit)TemplateDialog(t,{edit=false}){setT(it);edit=false};if(incident)IncidentDialog(s,st,{incident=false},reload)
}

@Composable fun IncidentDialog(s:List<Sub>,st:Store,close:()->Unit,reload:()->Unit){var account by remember{mutableStateOf("")};var type by remember{mutableStateOf("Cuenta caída")};var daysBack by remember{mutableStateOf("0")};AlertDialog(onDismissRequest=close,title={Text("⚠️ Incidencia")},text={Column{F("Cuenta / correo afectado",account){account=it};F("Tipo de incidencia",type){type=it};F("Días a reponer a todos (0 si aún no)",daysBack){daysBack=it};Text("Afectados: ${s.count{it.account==account&&it.status!="CORTADO"}}")}},confirmButton={Button({val n=daysBack.toIntOrNull()?:0;val affected=s.filter{it.account==account&&it.status!="CORTADO"};if(n>0)st.save(s.map{x->if(x.account==account&&x.status!="CORTADO")x.copy(end=LocalDate.parse(x.end).plusDays(n.toLong()).toString())else x});val hh=st.hist().toMutableList();affected.forEach{x->hh.add(Hist(subId=x.id,date=LocalDate.now().toString(),action="INCIDENCIA • $type • ${if(n>0)"REPOSICIÓN +$n DÍAS" else "ABIERTA"}"))};st.saveHist(hh);reload();close()},enabled=account.isNotBlank()){Text("Guardar incidencia")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun TemplateDialog(t:Templates,close:()->Unit,save:(Templates)->Unit){var a by remember{mutableStateOf(t.due3)};var b by remember{mutableStateOf(t.due1)};var c by remember{mutableStateOf(t.due0)};var d by remember{mutableStateOf(t.expired)};var e by remember{mutableStateOf(t.delivery)};AlertDialog(onDismissRequest=close,title={Text("Mensajes configurables")},text={LazyColumn{item{F("Vence en 3 días",a){a=it}};item{F("Vence mañana",b){b=it}};item{F("Vence hoy",c){c=it}};item{F("Vencido",d){d=it}};item{F("Entrega",e){e=it}}}},confirmButton={Button({save(Templates(a,b,c,d,e))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun RestoreDialog(close:()->Unit,restore:(String)->Unit){var text by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Restaurar respaldo")},text={Column{Text("Pega aquí el respaldo JSON exportado desde Nexo.");OutlinedTextField(text,{text=it},modifier=Modifier.fillMaxWidth().height(180.dp))}},confirmButton={Button({restore(text)},enabled=text.isNotBlank()){Text("Restaurar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun AddDialog(close:()->Unit,save:(Sub)->Unit){var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var profile by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var method by remember{mutableStateOf("Nequi")};var type by remember{mutableStateOf("PERFIL/PANTALLA")};var start by remember{mutableStateOf(LocalDate.now().toString())};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var accountEnd by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Nueva entrega de streaming")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){item{Text("Si el acceso ya está en Stock, véndelo desde Cuentas → Stock disponible para que cambie a Ocupado automáticamente.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{F("Cliente",client){client=it}};item{F("WhatsApp (57...)",phone){phone=it}};item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};item{F("Perfil / pantalla (opcional)",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}};item{F("Tipo de entrega",type){type=it}};item{F("Precio cobrado",price){price=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Método de pago",method){method=it}};item{Text("DATOS DEL PROVEEDOR",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Vence cuenta completa AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}};item{F("Inicio cliente AAAA-MM-DD",start){start=it}}}},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&runCatching{LocalDate.parse(start)}.isSuccess,onClick={val d=LocalDate.parse(start);save(Sub(client=client,phone=phone,service=service,account=account,profile=profile,pin=pin,type=type,password=password,price=price.filter{it.isDigit()}.toLongOrNull()?:0,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,paymentMethod=method,start=d.toString(),end=d.plusDays(30).toString(),provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0))}){Text("Guardar y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun EndServiceDialog(s:Sub,close:()->Unit,confirm:(String)->Unit){
 var reason by remember(s.id){mutableStateOf("No renovó")}
 AlertDialog(onDismissRequest=close,title={Text("Finalizar servicio")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("${s.client} • ${s.service}",fontWeight=FontWeight.Bold);Text("${s.profile} quedará disponible para otro cliente. El cliente, pagos y actividad se conservarán.")
  Text("Motivo",fontWeight=FontWeight.Bold);listOf("No renovó","Cliente canceló","Cambio de servicio","Problema con la cuenta","Otro").forEach{x->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=reason==x,onClick={reason=x});Text(x)}}
 }},confirmButton={Button(onClick={confirm(reason)}){Text("Finalizar servicio")}},dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}

@Composable fun PromiseDialog(s:Sub,close:()->Unit,save:(String)->Unit){var date by remember(s.id){mutableStateOf(LocalDate.now().plusDays(1).toString())};AlertDialog(onDismissRequest=close,title={Text("Dar plazo")},text={Column{Text("Registra cuándo prometió pagar. No modifica el vencimiento real del servicio.");F("Fecha promesa AAAA-MM-DD",date){date=it};Row{listOf(1L,2L,3L).forEach{n->TextButton({date=LocalDate.now().plusDays(n).toString()}){Text("+$n día")}}}}},confirmButton={Button({save(date)},enabled=runCatching{LocalDate.parse(date)}.isSuccess){Text("Guardar plazo")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun AdjustEndDialog(s:Sub,close:()->Unit,save:(String,String)->Unit){
 var date by remember(s.id){mutableStateOf(s.end)}
 var reason by remember(s.id){mutableStateOf("")}
 fun addDays(n:Long){date=runCatching{LocalDate.parse(date).plusDays(n).toString()}.getOrDefault(s.end)}
 AlertDialog(
  onDismissRequest=close,
  title={Text("Ajustar vencimiento")},
  text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text("${s.client} • ${s.service}")
   Text("Vencimiento actual: ${s.end}")
   OutlinedTextField(value=date,onValueChange={date=it},label={Text("Nueva fecha AAAA-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
   Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1L,3L,5L,7L).forEach{n->OutlinedButton(onClick={addDays(n)},contentPadding=PaddingValues(horizontal=8.dp,vertical=6.dp)){Text("+$n")}}}
   OutlinedTextField(value=reason,onValueChange={reason=it},label={Text("Motivo (opcional)")},modifier=Modifier.fillMaxWidth())
   Text("Este ajuste no registra una venta ni una renovación pagada.",style=MaterialTheme.typography.bodySmall)
  }},
  confirmButton={Button(onClick={save(date,reason)},enabled=runCatching{LocalDate.parse(date)}.isSuccess){Text("Guardar")}},
  dismissButton={TextButton(onClick=close){Text("Cancelar")}}
 )
}

@Composable fun EditSubDialog(s:Sub,close:()->Unit,save:(Sub)->Unit){
 var client by remember(s.id){mutableStateOf(s.client)};var phone by remember(s.id){mutableStateOf(s.phone)};var service by remember(s.id){mutableStateOf(s.service)};var account by remember(s.id){mutableStateOf(s.account)};var password by remember(s.id){mutableStateOf(s.password)};var profile by remember(s.id){mutableStateOf(s.profile)};var pin by remember(s.id){mutableStateOf(s.pin)};var type by remember(s.id){mutableStateOf(s.type)};var price by remember(s.id){mutableStateOf(s.price.toString())};var cost by remember(s.id){mutableStateOf(s.accountCost.toString())};var method by remember(s.id){mutableStateOf(s.paymentMethod)};var start by remember(s.id){mutableStateOf(s.start)};var end by remember(s.id){mutableStateOf(s.end)};var provider by remember(s.id){mutableStateOf(s.provider)};var providerPhone by remember(s.id){mutableStateOf(s.providerPhone)};var accountEnd by remember(s.id){mutableStateOf(s.accountEnd)};var renewCost by remember(s.id){mutableStateOf(s.accountRenewCost.toString())}
 AlertDialog(onDismissRequest=close,title={Text("Editar entrega / cuenta")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){
  item{Text("DATOS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{F("Cliente",client){client=it}};item{F("WhatsApp",phone){phone=it}};item{F("Servicio",service){service=it}}
  item{Text("CREDENCIALES",fontWeight=FontWeight.Bold)};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};item{F("Perfil / pantalla (opcional)",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}};item{F("Tipo de entrega",type){type=it}}
  item{Text("FECHAS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{F("Inicio AAAA-MM-DD",start){start=it}};item{F("Vence AAAA-MM-DD",end){end=it}}
  item{Text("VENTA",fontWeight=FontWeight.Bold)};item{F("Precio cobrado",price){price=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Método de pago",method){method=it}}
  item{Text("PROVEEDOR / CUENTA COMPLETA",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Vencimiento de cuenta AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&runCatching{LocalDate.parse(start);LocalDate.parse(end)}.isSuccess,onClick={save(s.copy(client=client,phone=phone,service=service,account=account,password=password,profile=profile,pin=pin,type=type,price=price.filter{it.isDigit()}.toLongOrNull()?:0,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,paymentMethod=method,start=start,end=end,provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0))}){Text("Guardar cambios")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun F(l:String,v:String,c:(String)->Unit){OutlinedTextField(v,c,label={Text(l)},singleLine=false,modifier=Modifier.fillMaxWidth())}

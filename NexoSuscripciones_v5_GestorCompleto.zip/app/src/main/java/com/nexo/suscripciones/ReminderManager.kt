package com.nexo.suscripciones

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.LocalDate
import java.time.ZoneId

object ReminderScheduler {
    private const val CHANNEL = "renovaciones"
    private val offsets = listOf(3, 1, 0)

    fun sync(context: Context, subs: List<Sub>) {
        createChannel(context)
        subs.forEach { sub ->
            offsets.forEach { days -> cancel(context, sub.id, days) }
            if (sub.status == "ACTIVO") offsets.forEach { days -> schedule(context, sub, days) }
        }
    }

    private fun schedule(context: Context, sub: Sub, daysBefore: Int) {
        val end = runCatching { LocalDate.parse(sub.end) }.getOrNull() ?: return
        val day = end.minusDays(daysBefore.toLong())
        val trigger = day.atTime(9, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (trigger <= System.currentTimeMillis()) return
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("id", sub.id); putExtra("client", sub.client); putExtra("phone", sub.phone)
            putExtra("service", sub.service); putExtra("end", sub.end); putExtra("days", daysBefore)
        }
        val pi = PendingIntent.getBroadcast(context, requestCode(sub.id, daysBefore), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(AlarmManager::class.java)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
    }

    private fun cancel(context: Context, id: Long, days: Int) {
        val pi = PendingIntent.getBroadcast(context, requestCode(id, days), Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pi != null) context.getSystemService(AlarmManager::class.java).cancel(pi)
    }

    private fun requestCode(id: Long, days: Int) = ((id xor (id ushr 32)).toInt() and 0x0fffffff) + days * 100000000

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Renovaciones y vencimientos", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Avisos 3 días antes, 1 día antes y el día del vencimiento"
            })
        }
    }

    fun show(context: Context, id: Long, client: String, phone: String, service: String, end: String, days: Int) {
        createChannel(context)
        val title = when(days) { 3 -> "🟠 Vence en 3 días"; 1 -> "🟠 Vence mañana"; else -> "🔴 Vence hoy" }
        val text = "$client • $service • $end"
        val msg = when(days) {
            0 -> "Hola $client 👋 Tu servicio $service vence hoy ($end). ¿Deseas renovarlo por otros 30 días?"
            1 -> "Hola $client 👋 Te recordamos que tu servicio $service vence mañana ($end). ¿Deseas renovarlo por otros 30 días?"
            else -> "Hola $client 👋 Tu servicio $service vence el $end. ¿Deseas renovarlo por otros 30 días?"
        }
        val url = "https://wa.me/${phone.filter { it.isDigit() }}?text=${Uri.encode(msg)}"
        val open = PendingIntent.getActivity(context, requestCode(id, days), Intent(Intent.ACTION_VIEW, Uri.parse(url)), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, CHANNEL).setSmallIcon(R.drawable.ic_stat_nexo).setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$text\nToca aquí para abrir WhatsApp con el mensaje preparado."))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(open).build()
        context.getSystemService(NotificationManager::class.java).notify(requestCode(id, days), n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.show(context, intent.getLongExtra("id",0), intent.getStringExtra("client")?:"Cliente", intent.getStringExtra("phone")?:"", intent.getStringExtra("service")?:"Servicio", intent.getStringExtra("end")?:"", intent.getIntExtra("days",0))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            ReminderScheduler.sync(context, Store(context).subs())
        }
    }
}

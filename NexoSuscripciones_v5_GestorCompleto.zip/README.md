# Nexo Suscripciones v3.0

App Android para controlar clientes, servicios, cuentas/perfiles, ventas, entregas, renovaciones, vencimientos, cortes, pagos, historial y reportes.

## Recordatorios automáticos locales (sin API ni nube)
Al guardar una venta, la app programa avisos Android a las 9:00 a. m.:
- 3 días antes del vencimiento.
- 1 día antes.
- El día del vencimiento.

Al tocar el aviso se abre WhatsApp con el número del cliente y el mensaje de renovación preparado. El usuario pulsa Enviar.

Cuando se renueva, los avisos anteriores se cancelan y se programan para el nuevo vencimiento. Al marcar un servicio como cortado se cancelan sus avisos. Después de reiniciar el celular o actualizar la app, se vuelven a programar los avisos activos.

En Android 13+ hay que aceptar el permiso de notificaciones al abrir la app.

## Compilar sin PC
Subir el contenido de este proyecto a un repositorio GitHub. GitHub Actions ejecuta `.github/workflows/build-apk.yml`. En Actions > ejecución > Artifacts se descarga `NexoSuscripciones-APK`, que contiene `app-debug.apk`.

## v4 - Identidad visual de la app y notificaciones
- Icono propio de Nexo Suscripciones en el launcher de Android.
- Icono N propio para las notificaciones de renovación/vencimiento.
- Las notificaciones aparecen bajo el canal "Renovaciones y vencimientos" y el nombre de la app "Nexo Suscripciones".
- Mantiene avisos locales a 3 días, 1 día y el día del vencimiento, sin API ni nube.

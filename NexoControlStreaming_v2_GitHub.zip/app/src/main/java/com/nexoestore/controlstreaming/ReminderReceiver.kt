package com.nexoestore.controlstreaming

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

object ReminderScheduler {
    private const val CHANNEL="renewals"
    fun scheduleAll(context: Context, items: List<Renewal>) {
        items.forEach { item ->
            listOf(5,3,1,0).forEach { days ->
                val whenMs=item.expiry-days*86400000L
                if(whenMs>System.currentTimeMillis()) {
                    val c=Calendar.getInstance().apply {
                        timeInMillis=whenMs; set(Calendar.HOUR_OF_DAY,9); set(Calendar.MINUTE,0); set(Calendar.SECOND,0)
                    }
                    val intent=Intent(context, ReminderReceiver::class.java).apply {
                        putExtra("customer",item.customer); putExtra("service",item.service)
                        putExtra("days",days); putExtra("id",item.id)
                    }
                    val pi=PendingIntent.getBroadcast(context,(item.id+days).hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                        .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.timeInMillis,pi)
                }
            }
        }
    }
}

class ReminderReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val nm=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel("renewals","Renovaciones",NotificationManager.IMPORTANCE_HIGH))
        val days=intent.getIntExtra("days",0)
        val customer=intent.getStringExtra("customer")?:"Cliente"
        val service=intent.getStringExtra("service")?:"Servicio"
        val text=if(days==0) "$service vence hoy" else "$service vence en $days día(s)"
        val open=PendingIntent.getActivity(context,0,Intent(context,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n=NotificationCompat.Builder(context,"renewals")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Renovación: $customer")
            .setContentText(text).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(open).build()
        nm.notify((intent.getStringExtra("id")+days).hashCode(),n)
    }
}

class BootReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if(intent.action==Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.scheduleAll(context, RenewalStore(context).all())
    }
}

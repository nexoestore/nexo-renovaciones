package com.nexoestore.controlstreaming

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Renewal(
    val id: String = UUID.randomUUID().toString(),
    var customer: String,
    var phone: String,
    var service: String,
    var price: Double,
    var expiry: Long,
    var notes: String = "",
    var active: Boolean = true
)

class RenewalStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("renewals", Context.MODE_PRIVATE)

    fun all(): MutableList<Renewal> {
        val arr = JSONArray(prefs.getString("items", "[]"))
        val result = mutableListOf<Renewal>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            result += Renewal(
                id=o.getString("id"), customer=o.getString("customer"),
                phone=o.optString("phone"), service=o.getString("service"),
                price=o.optDouble("price",0.0), expiry=o.getLong("expiry"),
                notes=o.optString("notes"), active=o.optBoolean("active",true)
            )
        }
        return result
    }

    fun save(items: List<Renewal>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("customer", it.customer); put("phone", it.phone)
                put("service", it.service); put("price", it.price); put("expiry", it.expiry)
                put("notes", it.notes); put("active", it.active)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
        ReminderScheduler.scheduleAll(context, items.filter { it.active })
    }

    fun upsert(item: Renewal) {
        val items=all()
        val i=items.indexOfFirst { it.id==item.id }
        if(i>=0) items[i]=item else items.add(item)
        save(items)
    }

    fun delete(id:String) = save(all().filterNot { it.id==id })
}

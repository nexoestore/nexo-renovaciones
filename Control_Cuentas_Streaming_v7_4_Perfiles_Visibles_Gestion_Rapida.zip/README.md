# Control de Cuentas Streaming v7.4

Actualización visual y operativa enfocada en cuentas vendidas por perfiles.

Base: v7.3 con Room, cifrado local, PIN/biometría, respaldos cifrados, validaciones, automatización y controles de calidad.

Novedades principales:
- Los perfiles libres ya no quedan ocultos cuando una cuenta tiene perfiles ocupados.
- En “Ya entregadas”, cada cuenta por perfiles muestra todos sus perfiles: LIBRE, OCUPADO o NO DISPONIBLE.
- Los perfiles se organizan en una cuadrícula de 3 columnas que se adapta a 3, 4, 5 o más perfiles sin desplazamiento horizontal.
- Tocar un perfil LIBRE abre “Asignar perfil”.
- Tocar un perfil OCUPADO abre su ficha de cliente con enviar datos, cobrar, renovar, editar y finalizar.
- Tocar un perfil NO DISPONIBLE abre su detalle para revisar/habilitar.
- Cada perfil ocupado muestra cliente y vencimiento corto (ej. 10 Oct).
- La cuenta muestra resumen: total de perfiles, libres y ocupados, además del vencimiento del proveedor.
- La vista “Ya entregadas” muestra también el total de perfiles libres para localizar capacidad disponible rápidamente.
- Se conserva toda la lógica y seguridad de v7.3.

Version: 7.4 (versionCode 32)
Application ID: com.nexo.suscripciones
Target SDK: 36

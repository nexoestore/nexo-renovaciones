# Control de Cuentas Streaming v6.1

Actualización incremental sobre v6.0, conservando el mismo package y almacenamiento local.

- Nombre visible nuevo: Control de Cuentas Streaming.
- Mensajes de entrega inteligentes: si Perfil/Pantalla o PIN/clave están vacíos, esas líneas no se envían por WhatsApp. Lo mismo aplica a campos opcionales de credenciales.
- Edición posterior de cada entrega: cliente, WhatsApp, servicio, correo/cuenta, contraseña, perfil, PIN, tipo, precio, costo, método de pago, fechas de inicio y fin, proveedor y fecha/costo de la cuenta maestra.
- Panel e inventario renombrados y visualmente orientados a streaming.
- Mantiene Centro de Control, renovaciones, promesa de pago, bajas, actividad, proveedores, incidencias, reportes, respaldo local y restauración.
- backupVersion permanece 2 para compatibilidad; appVersion 6.1.
- versionCode 14 / versionName 6.1.

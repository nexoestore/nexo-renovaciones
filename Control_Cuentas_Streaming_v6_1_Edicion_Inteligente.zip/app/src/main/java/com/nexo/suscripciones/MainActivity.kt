package com.nexo.suscripciones

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Sub(val id:Long=System.currentTimeMillis(),val client:String,val phone:String,val service:String,val account:String,val profile:String,val type:String,val price:Long,val start:String,val end:String,val status:String="ACTIVO",val paid:Boolean=true,val pin:String="",val accountCost:Long=0,val paymentMethod:String="Efectivo",val contacted:Boolean=false,val password:String="",val provider:String="",val providerPhone:String="",val accountEnd:String="",val accountRenewCost:Long=0,val promiseDate:String="")
data class Hist(val id:Long=System.currentTimeMillis(),val subId:Long,val date:String,val action:String,val amount:Long=0,val method:String="")
data class Templates(val due3:String="Hola {cliente} 👋 Tu servicio {servicio} vence el {fecha}. Valor de renovación: ${'$'}{precio}.",val due1:String="Hola {cliente} 👋 Te recordamos que tu servicio {servicio} vence mañana ({fecha}). Valor: ${'$'}{precio}.",val due0:String="Hola {cliente} 👋 Tu servicio {servicio} vence hoy ({fecha}). Si deseas continuar, puedes renovar por ${'$'}{precio}.",val expired:String="Hola {cliente} 👋 Tu servicio {servicio} venció el {fecha}. Si deseas reactivarlo, escríbeme para renovar.",val delivery:String="Hola {cliente} 👋 Aquí tienes tus datos de {servicio}:\nCuenta: {cuenta}\nContraseña: {password}\nPerfil: {perfil}\nPIN/clave: {pin}\nVence: {fecha}\nGracias por preferir Nexo.")

class Store(private val c:Context){private val p=c.getSharedPreferences("nexo_db",Context.MODE_PRIVATE)
 fun subs():MutableList<Sub>{val a=JSONArray(p.getString("subs","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Sub(o.getLong("id"),o.getString("client"),o.optString("phone"),o.getString("service"),o.optString("account"),o.optString("profile"),o.optString("type","PERFIL"),o.optLong("price"),o.getString("start"),o.getString("end"),o.optString("status","ACTIVO"),o.optBoolean("paid",true),o.optString("pin"),o.optLong("accountCost"),o.optString("paymentMethod","Efectivo"),o.optBoolean("contacted",false),o.optString("password",""),o.optString("provider",""),o.optString("providerPhone",""),o.optString("accountEnd",""),o.optLong("accountRenewCost"),o.optString("promiseDate",""))}}
 fun save(s:List<Sub>){val a=JSONArray();s.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("client",x.client);put("phone",x.phone);put("service",x.service);put("account",x.account);put("profile",x.profile);put("type",x.type);put("price",x.price);put("start",x.start);put("end",x.end);put("status",x.status);put("paid",x.paid);put("pin",x.pin);put("accountCost",x.accountCost);put("paymentMethod",x.paymentMethod);put("contacted",x.contacted);put("password",x.password);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountRenewCost",x.accountRenewCost);put("promiseDate",x.promiseDate)})};p.edit().putString("subs",a.toString()).apply();ReminderScheduler.sync(c,s)}
 fun hist():MutableList<Hist>{val a=JSONArray(p.getString("hist","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Hist(o.getLong("id"),o.getLong("subId"),o.getString("date"),o.getString("action"),o.optLong("amount"),o.optString("method"))}}
 fun saveHist(h:List<Hist>){val a=JSONArray();h.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("subId",x.subId);put("date",x.date);put("action",x.action);put("amount",x.amount);put("method",x.method)})};p.edit().putString("hist",a.toString()).apply()}
 fun templates():Templates{val o=runCatching{JSONObject(p.getString("templates","{}")!!)}.getOrDefault(JSONObject());val d=Templates();val oldDelivery=o.optString("delivery",d.delivery);val delivery=if(oldDelivery.contains("{password}"))oldDelivery else oldDelivery.replace("Cuenta: {cuenta}","Cuenta: {cuenta}\nContraseña: {password}");return Templates(o.optString("due3",d.due3),o.optString("due1",d.due1),o.optString("due0",d.due0),o.optString("expired",d.expired),delivery)}
 fun saveTemplates(t:Templates){p.edit().putString("templates",JSONObject().apply{put("due3",t.due3);put("due1",t.due1);put("due0",t.due0);put("expired",t.expired);put("delivery",t.delivery)}.toString()).apply()}
 fun backup():String=JSONObject().apply{put("backupVersion",2);put("appVersion","6.1");put("subs",JSONArray(p.getString("subs","[]")));put("hist",JSONArray(p.getString("hist","[]")));put("templates",JSONObject(p.getString("templates","{}")!!))}.toString(2)
 fun restore(text:String):Boolean=runCatching{val o=JSONObject(text);p.edit().putString("subs",o.getJSONArray("subs").toString()).putString("hist",o.optJSONArray("hist")?.toString()?:"[]").putString("templates",o.optJSONObject("templates")?.toString()?:"{}").commit();ReminderScheduler.sync(c,subs());true}.getOrDefault(false)
}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);ReminderScheduler.sync(this,Store(this).subs());if(android.os.Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),1001);setContent{NexoApp()}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun NexoApp(){
 val c=LocalContext.current
 val st=remember{Store(c)}
 var subs by remember{mutableStateOf(st.subs().toList())}
 var hist by remember{mutableStateOf(st.hist().toList())}
 var templates by remember{mutableStateOf(st.templates())}
 var tab by remember{mutableIntStateOf(0)}
 var add by remember{mutableStateOf(false)}
 var dark by remember{mutableStateOf(false)}
 var editing by remember{mutableStateOf<Sub?>(null)}
 fun persist(s:List<Sub>){subs=s;st.save(s)}
 fun log(id:Long,a:String,m:Long=0,method:String=""){hist=hist+Hist(subId=id,date=LocalDate.now().toString(),action=a,amount=m,method=method);st.saveHist(hist)}
 fun renew(s:Sub){val old=LocalDate.parse(s.end);val base=if(old.isBefore(LocalDate.now()))LocalDate.now() else old;persist(subs.map{if(it.id==s.id)it.copy(end=base.plusDays(30).toString(),status="ACTIVO",paid=true,contacted=false)else it});log(s.id,"RENOVACIÓN +30 DÍAS",s.price,s.paymentMethod)}
 fun cut(s:Sub,reason:String){persist(subs.map{if(it.id==s.id)it.copy(status="CORTADO",profile="LIBRE",contacted=true)else it});log(s.id,"BAJA • $reason • ${s.service} • ${s.profile} LIBERADO")}
 fun promise(s:Sub,date:String){persist(subs.map{if(it.id==s.id)it.copy(status="ESPERA",promiseDate=date)else it});log(s.id,"PROMESA DE PAGO • $date")}
 fun adjustEnd(s:Sub,newEnd:String,reason:String){val old=s.end;persist(subs.map{if(it.id==s.id)it.copy(end=newEnd,status="ACTIVO")else it});log(s.id,"AJUSTE VENCIMIENTO: $old → $newEnd${if(reason.isNotBlank())" • $reason" else ""}")}
 fun updateSub(updated:Sub){persist(subs.map{if(it.id==updated.id)updated else it});log(updated.id,"EDICIÓN DE ENTREGA / CUENTA")}
 val streamDark=darkColorScheme(primary=Color(0xFF20D8FF),secondary=Color(0xFF35E6A5),tertiary=Color(0xFFFFC857),background=Color(0xFF071018),surface=Color(0xFF0D1821),surfaceVariant=Color(0xFF162630))
 val streamLight=lightColorScheme(primary=Color(0xFF00687A),secondary=Color(0xFF006C50),tertiary=Color(0xFF7A5900))
 MaterialTheme(colorScheme=if(dark)streamDark else streamLight){
  Scaffold(
   topBar={TopAppBar(title={Column{Text("Control de Cuentas Streaming",fontWeight=FontWeight.Bold);Text("Cuentas • perfiles • renovaciones",style=MaterialTheme.typography.labelSmall)}})},
   floatingActionButton={if(tab==0)FloatingActionButton({add=true}){Text("+")}},
   bottomBar={NavigationBar{listOf("Inicio","Renovar","Cuentas","Reportes","Más").forEachIndexed{i,x->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(listOf("⌂","↻","📺","▤","☰")[i])},label={Text(x)})}}}
  ){pad->Box(Modifier.padding(pad)){when(tab){
   0->Home(subs,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,{s->persist(subs.map{if(it.id==s.id)it.copy(contacted=true)else it});log(s.id,"CONTACTADO POR WHATSAPP")},{editing=it})
   1->Renewals(subs,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,{s->persist(subs.map{if(it.id==s.id)it.copy(contacted=true)else it});log(s.id,"CONTACTADO POR WHATSAPP")},{editing=it})
   2->Accounts(subs,::adjustEnd,{editing=it})
   3->Reports(subs,hist)
   else->More(subs,hist,dark,{dark=it},templates,{templates=it;st.saveTemplates(it)},st,{subs=st.subs();hist=st.hist()})
  }}}
  if(add)AddDialog({add=false}){s->persist(subs+s);log(s.id,"VENTA / PAGO",s.price,s.paymentMethod);wa(c,s,fillTemplate(templates.delivery,s));add=false}
  editing?.let{current->EditSubDialog(current,{editing=null}){updated->updateSub(updated);editing=null}}
 }
}
fun days(s:Sub)=ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.end))
fun accountDays(s:Sub)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.accountEnd))}.getOrDefault(999)
fun money(v:Long)="$${"%,d".format(v)}"
fun fillTemplate(t:String,s:Sub):String{
 val values=mapOf("{cliente}" to s.client,"{servicio}" to s.service,"{fecha}" to s.end,"{precio}" to money(s.price),"{cuenta}" to s.account,"{perfil}" to s.profile,"{pin}" to s.pin,"{password}" to s.password)
 val optional=setOf("{cuenta}","{password}","{perfil}","{pin}")
 return t.lines()
  .filterNot{line->optional.any{key->line.contains(key)&&values[key].isNullOrBlank()}}
  .map{line->values.entries.fold(line){acc,(k,v)->acc.replace(k,v)}}
  .joinToString("\n")
  .replace(Regex("\n{3,}"),"\n\n")
  .trim()
}
fun messageFor(s:Sub,t:Templates):String=fillTemplate(when{days(s)<0->t.expired;days(s)==0L->t.due0;days(s)==1L->t.due1;else->t.due3},s)
fun wa(c:Context,s:Sub,msg:String){val u="https://wa.me/${s.phone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun Home(s:List<Sub>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val today=s.count{it.status!="CORTADO"&&days(it)==0L};val tomorrow=s.count{it.status!="CORTADO"&&days(it)==1L};val d3=s.count{it.status!="CORTADO"&&days(it) in 2..3};val expired=s.count{it.status!="CORTADO"&&days(it)<0};val free=s.count{it.status=="CORTADO"||it.profile=="LIBRE"};val accounts=s.filter{it.account.isNotBlank()}.distinctBy{it.account};val providerDue=accounts.count{accountDays(it) in 0..3};val noSpace=s.groupBy{it.account}.count{it.key.isNotBlank()&&it.value.none{x->x.status=="CORTADO"||x.profile=="LIBRE"}};val value=s.filter{it.status!="CORTADO"&&days(it)<=3}.sumOf{it.price}
 LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{Text("Panel Streaming",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Control diario • ${LocalDate.now()}")}
  item{ElevatedCard(Modifier.fillMaxWidth()){Text("⏱️ RENOVACIONES\n🔴 $today vencen hoy\n🟠 $tomorrow vencen mañana\n🟡 $d3 vencen en 3 días\n✂️ $expired pendientes de corte",Modifier.padding(14.dp))}}
  item{ElevatedCard(Modifier.fillMaxWidth()){Text("📺 INVENTARIO STREAMING\n🟢 $free perfiles disponibles\n🔴 $providerDue cuentas vencen al proveedor\n⚠️ $noSpace cuentas sin espacios",Modifier.padding(14.dp))}}
  item{ElevatedCard(Modifier.fillMaxWidth()){Text("💳 COBROS\n💰 ${money(value)} por renovar",Modifier.padding(14.dp))}}
  if(providerDue>0)item{Text("🚨 Cuentas maestras por renovar",fontWeight=FontWeight.Bold)}
  items(accounts.filter{accountDays(it) in 0..3}){x->Card(Modifier.fillMaxWidth()){Text("📺 ${x.service}\nCuenta: ${x.account}\nProveedor: ${x.provider.ifBlank{"Sin proveedor"}}\nVence proveedor: ${x.accountEnd}\nCosto renovación: ${money(x.accountRenewCost)}",Modifier.padding(12.dp))}}
  item{Text("Trabajo de hoy",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
  items(s.filter{it.status!="CORTADO"&&days(it)<=3}.sortedBy{it.end}){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}
 }
}

@Composable fun Renewals(s:List<Sub>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val groups=listOf("EN 3 DÍAS" to s.filter{it.status!="CORTADO"&&days(it) in 2..3},"MAÑANA" to s.filter{it.status!="CORTADO"&&days(it)==1L},"HOY" to s.filter{it.status!="CORTADO"&&days(it)==0L},"VENCIDOS / PENDIENTES" to s.filter{it.status!="CORTADO"&&days(it)<0&&it.status!="ESPERA"},"EN ESPERA" to s.filter{it.status=="ESPERA"})
 LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text("Renovaciones de streaming",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};groups.forEach{(title,list)->item{Text("$title (${list.size})",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)};if(list.isEmpty())item{Text("Sin clientes")};items(list.sortedBy{it.end}){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}}}
}

@Composable fun ActionCard(s:Sub,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 var showAdjust by remember(s.id){mutableStateOf(false)};var showEnd by remember(s.id){mutableStateOf(false)};var showPromise by remember(s.id){mutableStateOf(false)};val ctx=LocalContext.current
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
  Text("${if(days(s)<0)"🔴" else if(days(s)<=1)"🟠" else "🟡"} ${s.client} • ${s.service}",fontWeight=FontWeight.Bold)
  Text("${s.type} • vence ${s.end} • ${money(s.price)}")
  if(s.account.isNotBlank())Text("📧 ${s.account}",style=MaterialTheme.typography.bodySmall)
  if(s.profile.isNotBlank())Text("👤 Perfil: ${s.profile}${if(s.pin.isNotBlank())" • PIN guardado" else ""}",style=MaterialTheme.typography.bodySmall)
  if(s.contacted)Text("✓ Contactado",style=MaterialTheme.typography.labelMedium)
  Button({wa(ctx,s,fillTemplate(Store(ctx).templates().delivery,s))},modifier=Modifier.fillMaxWidth()){Text("📤 Enviar credenciales")}
  OutlinedButton({edit(s)},modifier=Modifier.fillMaxWidth()){Text("✏️ Editar entrega / cuenta")}
  OutlinedButton({showAdjust=true},modifier=Modifier.fillMaxWidth()){Text("📅 Ajustar vencimiento")}
  Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){Button({wa(s);contact(s)},contentPadding=PaddingValues(8.dp)){Text("WhatsApp")};OutlinedButton({renew(s)},contentPadding=PaddingValues(8.dp)){Text("+30")};if(days(s)<=0)OutlinedButton({showEnd=true},contentPadding=PaddingValues(8.dp)){Text("No renovó")}}
  if(days(s)<=0)OutlinedButton({showPromise=true},modifier=Modifier.fillMaxWidth()){Text("⏳ Dar plazo / promesa de pago")};if(s.promiseDate.isNotBlank())Text("Prometió pagar: ${s.promiseDate}")
 }}
 if(showAdjust)AdjustEndDialog(s,{showAdjust=false}){date,reason->adjust(s,date,reason);showAdjust=false};if(showEnd)EndServiceDialog(s,{showEnd=false}){reason->cut(s,reason);showEnd=false};if(showPromise)PromiseDialog(s,{showPromise=false}){date->promise(s,date);showPromise=false}
}

@Composable fun Accounts(s:List<Sub>,adjust:(Sub,String,String)->Unit,edit:(Sub)->Unit){
 val ctx=LocalContext.current;val st=remember{Store(ctx)};var adjusting by remember{mutableStateOf<Sub?>(null)};val g=s.groupBy{it.account.ifBlank{"Sin cuenta"}}
 LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  item{Text("Cuentas maestras y perfiles",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("${g.size} cuentas • ${s.count{it.status!="CORTADO"}} ocupados • ${s.count{it.status=="CORTADO"||it.profile=="LIBRE"}} disponibles")}
  items(g.entries.toList()){e->val base=e.value.first();val cost=e.value.maxOfOrNull{it.accountCost}?:0;val income=e.value.filter{it.status!="CORTADO"}.sumOf{it.price};Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
   Text("📺 ${base.service}",fontWeight=FontWeight.Bold);Text("📧 ${e.key}");Text("🏪 ${base.provider.ifBlank{"Proveedor sin asignar"}}\n📅 Corte de cuenta: ${base.accountEnd.ifBlank{"Sin fecha"}}\n💵 Renovación proveedor: ${money(base.accountRenewCost)}\nCosto: ${money(cost)} • Ingreso: ${money(income)} • Utilidad: ${money(income-cost)}")
   if(base.providerPhone.isNotBlank())OutlinedButton({waProvider(ctx,base)},Modifier.fillMaxWidth()){Text("💬 Contactar proveedor")}
   e.value.forEach{x->HorizontalDivider();Text("${if(x.status=="CORTADO")"🟢 LIBRE" else if(days(x)<0)"🔴" else "🔵"} ${x.profile.ifBlank{x.type}} ${if(x.status!="CORTADO")"— ${x.client} — ${x.end}" else ""}");if(x.status!="CORTADO"){Button({wa(ctx,x,fillTemplate(st.templates().delivery,x))},Modifier.fillMaxWidth()){Text("📤 Enviar credenciales")};OutlinedButton({edit(x)},Modifier.fillMaxWidth()){Text("✏️ Editar datos entregados")};OutlinedButton({adjusting=x},Modifier.fillMaxWidth()){Text("📅 Ajustar vencimiento cliente")}}}
  }}}
 }
 adjusting?.let{x->AdjustEndDialog(x,{adjusting=null}){d,r->adjust(x,d,r);adjusting=null}}
}
fun waProvider(c:Context,s:Sub){val msg="Hola ${s.provider}, necesito revisar la cuenta ${s.account} de ${s.service}. Vence ${s.accountEnd}.";val u="https://wa.me/${s.providerPhone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}
@Composable fun Reports(s:List<Sub>,h:List<Hist>){val sales=h.filter{it.action.contains("VENTA")||it.action.contains("RENOVACIÓN")};val income=sales.sumOf{it.amount};val costs=s.groupBy{it.account}.values.sumOf{it.maxOfOrNull{x->x.accountCost}?:0};LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Reportes y estadísticas",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};item{Card(Modifier.fillMaxWidth()){Text("Ingresos registrados: ${money(income)}\nCostos de cuentas: ${money(costs)}\nUtilidad estimada: ${money(income-costs)}\nClientes activos: ${s.count{it.status=="ACTIVO"&&days(it)>=0}}\nVencidos: ${s.count{it.status!="CORTADO"&&days(it)<0}}\nRenovaciones: ${h.count{it.action.contains("RENOVACIÓN")}}",Modifier.padding(14.dp))}};item{Text("Historial de pagos",fontWeight=FontWeight.Bold)};items(h.sortedByDescending{it.id}){x->val n=s.find{it.id==x.subId}?.client?:"Cliente";Text("${x.date} • $n • ${x.action}${if(x.amount>0)" • ${money(x.amount)} ${x.method}" else ""}")}}}
@Composable fun More(s:List<Sub>,h:List<Hist>,dark:Boolean,setDark:(Boolean)->Unit,t:Templates,setT:(Templates)->Unit,st:Store,reload:()->Unit){
 var edit by remember{mutableStateOf(false)};var restore by remember{mutableStateOf(false)};var incident by remember{mutableStateOf(false)};var filter by remember{mutableStateOf("Todos")};var query by remember{mutableStateOf("")};val c=LocalContext.current;var backupMsg by remember{mutableStateOf("")};val createBackup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null)runCatching{c.contentResolver.openOutputStream(u)?.bufferedWriter()?.use{it.write(st.backup())};backupMsg="✅ Respaldo guardado en la memoria"}.onFailure{backupMsg="❌ No se pudo guardar"}};val openBackup=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)runCatching{val txt=c.contentResolver.openInputStream(u)?.bufferedReader()?.use{it.readText()}?:"";if(st.restore(txt)){reload();backupMsg="✅ Respaldo restaurado"}else backupMsg="❌ Archivo no compatible"}}
 val filtered=h.sortedByDescending{it.id}.filter{x->val client=s.find{it.id==x.subId}?.client?:"Cliente";client.contains(query,true)&&(filter=="Todos"||x.action.contains(filter,true))}
 LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{Text("Actividad",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)}
  item{Text("Memoria comercial del negocio: ventas, renovaciones, pagos, ajustes y bajas.")}
  item{OutlinedTextField(query,{query=it},label={Text("Buscar cliente")},singleLine=true,modifier=Modifier.fillMaxWidth())}
  item{Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf("Todos","VENTA","RENOVACIÓN","AJUSTE","BAJA").forEach{x->FilterChip(selected=filter==x,onClick={filter=x},label={Text(x.lowercase().replaceFirstChar{it.uppercase()})})}}}
  if(filtered.isEmpty())item{Text("Sin actividad para este filtro.")}
  items(filtered.take(100)){x->val sub=s.find{it.id==x.subId};Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text("${x.date} • ${sub?.client?:"Cliente"}",fontWeight=FontWeight.Bold);Text(x.action);if(x.amount>0)Text("${money(x.amount)} • ${x.method}")}}}
  item{HorizontalDivider();Text("Proveedores",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
  val providerRows=s.filter{it.provider.isNotBlank()}.groupBy{it.provider}
  if(providerRows.isEmpty())item{Text("Sin proveedores registrados. Se agregan desde Nueva venta.")}
  items(providerRows.entries.toList()){e->val accounts=e.value.distinctBy{it.account};Text("🏪 ${e.key} • ${accounts.size} cuentas • Próximo vencimiento: ${accounts.mapNotNull{runCatching{LocalDate.parse(it.accountEnd)}.getOrNull()}.minOrNull()?:"Sin fecha"}")}
  item{Button({incident=true},Modifier.fillMaxWidth()){Text("⚠️ Registrar incidencia de cuenta")}}
  item{HorizontalDivider();Text("Clientes",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
  items(s.groupBy{it.client}.entries.toList()){e->val total=h.filter{x->e.value.any{it.id==x.subId}&&x.amount>0}.sumOf{it.amount};val renews=h.count{x->e.value.any{it.id==x.subId}&&x.action.contains("RENOVACIÓN")};Text("${e.key} • Renovaciones: $renews • Total: ${money(total)}")}
  item{HorizontalDivider();Text("Configuración",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
  item{Row(verticalAlignment=Alignment.CenterVertically){Text("🌙 Modo oscuro",Modifier.weight(1f));Switch(dark,setDark)}}
  item{Button({edit=true},Modifier.fillMaxWidth()){Text("⚙️ Editar mensajes")}}
  item{Text("🛡️ Copia de seguridad local",fontWeight=FontWeight.Bold)}
  item{Button({createBackup.launch("Nexo_Backup_${LocalDate.now()}.nexo")},Modifier.fillMaxWidth()){Text("💾 CREAR RESPALDO")}}
  item{OutlinedButton({openBackup.launch(arrayOf("application/octet-stream","application/json","text/plain","*/*"))},Modifier.fillMaxWidth()){Text("♻️ RESTAURAR RESPALDO")}}
  if(backupMsg.isNotBlank())item{Text(backupMsg)}
 }
 if(edit)TemplateDialog(t,{edit=false}){setT(it);edit=false};if(restore)RestoreDialog({restore=false}){if(st.restore(it)){reload();restore=false}};if(incident)IncidentDialog(s,st,{incident=false},reload)
}
@Composable fun IncidentDialog(s:List<Sub>,st:Store,close:()->Unit,reload:()->Unit){var account by remember{mutableStateOf("")};var type by remember{mutableStateOf("Cuenta caída")};var daysBack by remember{mutableStateOf("0")};AlertDialog(onDismissRequest=close,title={Text("⚠️ Incidencia")},text={Column{F("Cuenta / correo afectado",account){account=it};F("Tipo de incidencia",type){type=it};F("Días a reponer a todos (0 si aún no)",daysBack){daysBack=it};Text("Afectados: ${s.count{it.account==account&&it.status!="CORTADO"}}")}},confirmButton={Button({val n=daysBack.toIntOrNull()?:0;val affected=s.filter{it.account==account&&it.status!="CORTADO"};if(n>0)st.save(s.map{x->if(x.account==account&&x.status!="CORTADO")x.copy(end=LocalDate.parse(x.end).plusDays(n.toLong()).toString())else x});val hh=st.hist().toMutableList();affected.forEach{x->hh.add(Hist(subId=x.id,date=LocalDate.now().toString(),action="INCIDENCIA • $type • ${if(n>0)"REPOSICIÓN +$n DÍAS" else "ABIERTA"}"))};st.saveHist(hh);reload();close()},enabled=account.isNotBlank()){Text("Guardar incidencia")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun TemplateDialog(t:Templates,close:()->Unit,save:(Templates)->Unit){var a by remember{mutableStateOf(t.due3)};var b by remember{mutableStateOf(t.due1)};var c by remember{mutableStateOf(t.due0)};var d by remember{mutableStateOf(t.expired)};var e by remember{mutableStateOf(t.delivery)};AlertDialog(onDismissRequest=close,title={Text("Mensajes configurables")},text={LazyColumn{item{F("Vence en 3 días",a){a=it}};item{F("Vence mañana",b){b=it}};item{F("Vence hoy",c){c=it}};item{F("Vencido",d){d=it}};item{F("Entrega",e){e=it}}}},confirmButton={Button({save(Templates(a,b,c,d,e))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun RestoreDialog(close:()->Unit,restore:(String)->Unit){var text by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Restaurar respaldo")},text={Column{Text("Pega aquí el respaldo JSON exportado desde Nexo.");OutlinedTextField(text,{text=it},modifier=Modifier.fillMaxWidth().height(180.dp))}},confirmButton={Button({restore(text)},enabled=text.isNotBlank()){Text("Restaurar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun AddDialog(close:()->Unit,save:(Sub)->Unit){var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var profile by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var method by remember{mutableStateOf("Nequi")};var type by remember{mutableStateOf("PERFIL/PANTALLA")};var start by remember{mutableStateOf(LocalDate.now().toString())};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var accountEnd by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Nueva entrega de streaming")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){item{F("Cliente",client){client=it}};item{F("WhatsApp (57...)",phone){phone=it}};item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};item{F("Perfil / pantalla (opcional)",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}};item{F("Tipo de entrega",type){type=it}};item{F("Precio cobrado",price){price=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Método de pago",method){method=it}};item{Text("DATOS DEL PROVEEDOR",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Vence cuenta proveedor AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo renovación proveedor",renewCost){renewCost=it}};item{F("Inicio cliente AAAA-MM-DD",start){start=it}}}},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&runCatching{LocalDate.parse(start)}.isSuccess,onClick={val d=LocalDate.parse(start);save(Sub(client=client,phone=phone,service=service,account=account,profile=profile,pin=pin,type=type,password=password,price=price.filter{it.isDigit()}.toLongOrNull()?:0,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,paymentMethod=method,start=d.toString(),end=d.plusDays(30).toString(),provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0))}){Text("Guardar y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun EndServiceDialog(s:Sub,close:()->Unit,confirm:(String)->Unit){
 var reason by remember(s.id){mutableStateOf("No renovó")}
 AlertDialog(onDismissRequest=close,title={Text("Finalizar servicio")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("${s.client} • ${s.service}",fontWeight=FontWeight.Bold);Text("${s.profile} quedará disponible para otro cliente. El cliente, pagos y actividad se conservarán.")
  Text("Motivo",fontWeight=FontWeight.Bold);listOf("No renovó","Cliente canceló","Cambio de servicio","Problema con la cuenta","Otro").forEach{x->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=reason==x,onClick={reason=x});Text(x)}}
 }},confirmButton={Button(onClick={confirm(reason)}){Text("Finalizar servicio")}},dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}

@Composable fun PromiseDialog(s:Sub,close:()->Unit,save:(String)->Unit){var date by remember(s.id){mutableStateOf(LocalDate.now().plusDays(1).toString())};AlertDialog(onDismissRequest=close,title={Text("Dar plazo")},text={Column{Text("Registra cuándo prometió pagar. No modifica el vencimiento real del servicio.");F("Fecha promesa AAAA-MM-DD",date){date=it};Row{listOf(1L,2L,3L).forEach{n->TextButton({date=LocalDate.now().plusDays(n).toString()}){Text("+$n día")}}}}},confirmButton={Button({save(date)},enabled=runCatching{LocalDate.parse(date)}.isSuccess){Text("Guardar plazo")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun AdjustEndDialog(s:Sub,close:()->Unit,save:(String,String)->Unit){
 var date by remember(s.id){mutableStateOf(s.end)}
 var reason by remember(s.id){mutableStateOf("")}
 fun addDays(n:Long){date=runCatching{LocalDate.parse(date).plusDays(n).toString()}.getOrDefault(s.end)}
 AlertDialog(
  onDismissRequest=close,
  title={Text("Ajustar vencimiento")},
  text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text("${s.client} • ${s.service}")
   Text("Vencimiento actual: ${s.end}")
   OutlinedTextField(value=date,onValueChange={date=it},label={Text("Nueva fecha AAAA-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
   Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1L,3L,5L,7L).forEach{n->OutlinedButton(onClick={addDays(n)},contentPadding=PaddingValues(horizontal=8.dp,vertical=6.dp)){Text("+$n")}}}
   OutlinedTextField(value=reason,onValueChange={reason=it},label={Text("Motivo (opcional)")},modifier=Modifier.fillMaxWidth())
   Text("Este ajuste no registra una venta ni una renovación pagada.",style=MaterialTheme.typography.bodySmall)
  }},
  confirmButton={Button(onClick={save(date,reason)},enabled=runCatching{LocalDate.parse(date)}.isSuccess){Text("Guardar")}},
  dismissButton={TextButton(onClick=close){Text("Cancelar")}}
 )
}

@Composable fun EditSubDialog(s:Sub,close:()->Unit,save:(Sub)->Unit){
 var client by remember(s.id){mutableStateOf(s.client)};var phone by remember(s.id){mutableStateOf(s.phone)};var service by remember(s.id){mutableStateOf(s.service)};var account by remember(s.id){mutableStateOf(s.account)};var password by remember(s.id){mutableStateOf(s.password)};var profile by remember(s.id){mutableStateOf(s.profile)};var pin by remember(s.id){mutableStateOf(s.pin)};var type by remember(s.id){mutableStateOf(s.type)};var price by remember(s.id){mutableStateOf(s.price.toString())};var cost by remember(s.id){mutableStateOf(s.accountCost.toString())};var method by remember(s.id){mutableStateOf(s.paymentMethod)};var start by remember(s.id){mutableStateOf(s.start)};var end by remember(s.id){mutableStateOf(s.end)};var provider by remember(s.id){mutableStateOf(s.provider)};var providerPhone by remember(s.id){mutableStateOf(s.providerPhone)};var accountEnd by remember(s.id){mutableStateOf(s.accountEnd)};var renewCost by remember(s.id){mutableStateOf(s.accountRenewCost.toString())}
 AlertDialog(onDismissRequest=close,title={Text("Editar entrega / cuenta")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){
  item{Text("DATOS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{F("Cliente",client){client=it}};item{F("WhatsApp",phone){phone=it}};item{F("Servicio",service){service=it}}
  item{Text("CREDENCIALES",fontWeight=FontWeight.Bold)};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};item{F("Perfil / pantalla (opcional)",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}};item{F("Tipo de entrega",type){type=it}}
  item{Text("FECHAS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{F("Inicio AAAA-MM-DD",start){start=it}};item{F("Vence AAAA-MM-DD",end){end=it}}
  item{Text("VENTA",fontWeight=FontWeight.Bold)};item{F("Precio cobrado",price){price=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Método de pago",method){method=it}}
  item{Text("PROVEEDOR / CUENTA MAESTRA",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Corte de cuenta AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo renovación proveedor",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&runCatching{LocalDate.parse(start);LocalDate.parse(end)}.isSuccess,onClick={save(s.copy(client=client,phone=phone,service=service,account=account,password=password,profile=profile,pin=pin,type=type,price=price.filter{it.isDigit()}.toLongOrNull()?:0,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,paymentMethod=method,start=start,end=end,provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0))}){Text("Guardar cambios")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun F(l:String,v:String,c:(String)->Unit){OutlinedTextField(v,c,label={Text(l)},singleLine=false,modifier=Modifier.fillMaxWidth())}

# Nexo Suscripciones v5.2

Actualización incremental sobre v5.1. Conserva la base de datos `nexo_db` y todos los campos anteriores.

## Mejoras
- Nuevo campo **Contraseña del correo / cuenta** en Nueva venta / entrega.
- La contraseña se guarda junto con la suscripción y es compatible con registros anteriores (queda vacía si no existía).
- Botón visible **📤 Enviar credenciales** en cada tarjeta de cliente/renovación.
- El mensaje de credenciales usa Servicio, Cuenta, Contraseña, Perfil, PIN y Vencimiento.
- Las plantillas antiguas de entrega se migran automáticamente para añadir `{password}` sin borrar el resto del texto configurado.
- Respaldo/restauración incluye el nuevo campo porque forma parte de `subs`.
- versionCode 7 / versionName 5.2.

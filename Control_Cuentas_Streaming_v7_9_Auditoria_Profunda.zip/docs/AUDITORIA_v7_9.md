# Auditoría profunda v7.9 (sobre v7.8)

**Alcance:** lectura completa del código fuente (Kotlin, manifiesto, Gradle, workflow, pruebas, documentos de Play Store).
**Limitación importante:** en el entorno de la auditoría no hay compilador Kotlin ni SDK de Android. Los cambios **no se han compilado ni ejecutado**. Lo que sí se verificó: equilibrio de llaves/paréntesis de todos los `.kt` (el original y el modificado), validez de YAML y del manifiesto XML, ausencia de funciones duplicadas, y la lógica pura (retención de copias y plantillas) simulada aparte. La compilación y las pruebas deben pasar en GitHub Actions antes de instalar.

## A. Errores encontrados y CORREGIDOS

| # | Gravedad | Problema | Corrección |
|---|---|---|---|
| 1 | **Alta** | Los mensajes a clientes y proveedores salían con **doble símbolo de moneda** («Valor: $$25.000»): la plantilla traía `$` y `money()` ya lo incluye. Afectaba a las plantillas por defecto **y** a las ya guardadas. | Plantillas por defecto corregidas; `fillTemplate` y la plantilla de proveedor normalizan también las plantillas ya guardadas. |
| 2 | **Alta** | **Respaldos automáticos: se destruía el historial.** Cada movimiento forzaba una copia y solo se conservaban las últimas 7 → tras 7 operaciones del mismo día no quedaba ninguna copia de días anteriores. | Se conserva la copia más reciente de cada uno de los últimos 7 **días**; forzado limitado a 1 por minuto (`BackupRetention`, con pruebas). |
| 3 | **Alta** | El respaldo creaba primero el archivo y después generaba el contenido: si fallaba, quedaba un archivo **vacío** que además podía desplazar a copias buenas. | El contenido se genera antes de crear el archivo; los archivos vacíos nunca cuentan como copia y se eliminan. |
| 4 | **Alta** | Un fallo de copia automática era **silencioso**: el usuario creía estar protegido. | Aviso rojo en Ajustes cuando el último intento falló. |
| 5 | **Alta** | **Restaurar** reemplazaba todos los datos con un solo toque, sin confirmación; además la restauración no era atómica (si fallaba a medias quedaba una mezcla) y dejaba contraseñas en texto plano en `SharedPreferences` si fallaba. | Confirmación explícita; el respaldo se valida completo **antes** de tocar nada; reemplazo en una sola transacción de Room (`replaceAll`); ya no se escriben credenciales en preferencias. |
| 6 | **Alta** | Si la clave del Keystore no estaba disponible, `decrypt` devolvía `""` y el siguiente guardado **borraba la credencial para siempre**. Además esa contraseña vacía/ilegible podía usarse como contraseña de respaldo. | Se conserva el valor cifrado intacto; en mensajes se trata como vacío (nunca se envía texto cifrado al cliente); la contraseña de respaldo ilegible se ignora. |
| 7 | Media | **Incidencias**: todos los clientes afectados recibían el mismo `id` de historial (mismo milisegundo) y `REPLACE` dejaba **solo uno**. Además la cuenta se comparaba distinguiendo mayúsculas. | Ids únicos; comparación con `accountKey`. |
| 8 | Media | **Cobranza rápida** saltaba un cliente tras cada renovación (la cola se acorta y el índice también avanzaba). El contador podía mostrar «5/4». | Corregido. |
| 9 | Media | Códigos de alarma/notificación `(id & 0xFFFFFF) + código×1.000.000` **se solapaban**: dos entregas distintas podían pisarse un aviso. | Nueva mezcla del identificador completo. |
| 10 | Media | Cuentas completas: «Habilitar» no pedía confirmar la revocación del acceso y se podía «habilitar» con el proveedor vencido (al renovar al proveedor quedaba vendible sin verificar). | Confirmación; bloqueado mientras el proveedor esté vencido. |
| 11 | Media | Entregas con **fecha inválida** no aparecían en Inicio ni en Renovar y no generaban avisos (invisibles). | Grupo «Revisar fecha» en Renovar y aviso en Inicio. |
| 12 | Media | Tras restaurar, las plantillas y el modo oscuro seguían con los valores anteriores en memoria (y podían sobrescribir lo restaurado al editar). | Se recargan tras restaurar. |
| 13 | Media | `isSaleIncome` usaba `contains("VENTA")`: una compra a un proveedor llamado «VentasTV» contaba como **ingreso**. | `startsWith`. |
| 14 | Media | Renovar a un cliente más allá del vencimiento del proveedor no avisaba. | Aviso (no bloquea) en el diálogo de renovación. |
| 15 | Baja | `ClientRecord.createdAt` se sobrescribía con la fecha de hoy en cada guardado. | Se conserva la fecha real. |
| 16 | Baja | Abrir WhatsApp sin teléfono o sin app/navegador **cerraba la app** o abría un enlace vacío. | `openWhatsApp` con aviso. |
| 17 | Baja | «Dar plazo» → «Ajustar vencimiento» dejaba la promesa anterior visible. | Se limpia. |
| 18 | Baja | La búsqueda global ofrecía «Credenciales» para clientes ya dados de baja. | Oculto para CORTADO. |
| 19 | Baja | Tocar dos veces el mismo aviso no volvía a abrir la pestaña. | `requestNonce`. |
| 20 | Baja | Los receptores de alarma/arranque trabajaban en el hilo principal. | `goAsync()` + hilo. |
| 21 | Baja | `BootReceiver` exportado sin necesidad. | `exported=false`. |
| 22 | Baja | Sustitución secuencial de variables: un dato que contenga `{pin}` se volvía a sustituir. | Un solo recorrido. |
| 23 | Proceso | El workflow tomaba **un ZIP cualquiera** si había varios, y los artefactos se llamaban «v7.6». | Falla si hay más de un ZIP; nombres v7.9. |

Versión: `7.9` / `versionCode 40`. Sin cambios de esquema Room ni de `applicationId`.

## B. Hallazgos NO corregidos (decisión tuya o requieren pruebas en dispositivo)

1. **Hilo principal bloqueado.** `Store` usa `runBlocking` y cada guardado reescribe tablas completas, sincroniza avisos y puede escribir una copia (PBKDF2 150.000 iteraciones). Con muchos datos habrá tirones/ANR. Recomendado: mover a `ViewModel` + corrutinas.
2. **Avisos perdidos.** Si el teléfono está apagado/sin batería a las 9:00, ese aviso no se entrega al encender (solo se reprograman los futuros). Se usan alarmas inexactas (`setAndAllowWhileIdle`) que Android puede retrasar.
3. **Cuenta duplicada en Stock.** Añadir otra vez el mismo correo/servicio/proveedor crea un segundo «maestro» (tarjeta separada) y duplica el costo del mes. Para añadir perfiles a una cuenta existente hoy hay que editar, no volver a crearla.
4. **Nombre de proveedor.** Un proveedor escrito sin espacios y con punto (`ana.garcia`, `ana.lopez`) se interpreta como dominio y ambos pasan a llamarse «ANA»: se mezclarían sus cuentas y pagos.
5. **«Eliminar registro de prueba»** borra también los movimientos de dinero de esa entrega y deja el acceso `DISPONIBLE` (no `NO_DISPONIBLE`). Úsalo solo si de verdad no se entregó nada.
6. **Ids por `System.currentTimeMillis()`** (clientes, stock, plantillas): colisión posible si se crean dos en el mismo milisegundo (p. ej. importaciones masivas futuras).
7. **Privacidad:** nombres, teléfonos y correos de cuentas se guardan **sin cifrar** en Room (solo contraseñas/PIN van cifradas); no hay `FLAG_SECURE` (capturas y vista de apps recientes muestran datos). El texto de «Privacidad» lo dice correctamente solo de contraseñas/PIN.
8. **Incidencias** extienden fechas sin comprobar cobertura del proveedor; las renovaciones solo advierten.
9. El historial se interpreta separando por « • »: un proveedor/cuenta que contenga ese separador rompería la coincidencia de pagos.
10. Room `version=1` con `exportSchema=false` y sin migraciones: el primer cambio de esquema futuro exigirá migración explícita. Lint con `abortOnError=false`, sin minificación.

## C. Antes de instalar
1. Crea un respaldo cifrado en la v7.8 instalada y guárdalo fuera del teléfono.
2. Sube **un solo ZIP** al repositorio y ejecuta el workflow. Revisa primero el reporte de pruebas (`Diagnostico-Pruebas-v7.9`).
3. Instala con **la misma firma**; no desinstales la anterior.
4. Prueba: enviar una renovación por WhatsApp (sin «$$»), restaurar un respaldo (aparece la confirmación), forzar un fallo de carpeta de respaldo (aparece el aviso), cobranza rápida con 3 clientes, incidencia con varios clientes (un movimiento por cliente).

## D. Ronda 2 (a partir de tus capturas)
- **Cuentas que el proveedor no renueva (30 días):** nueva casilla «Cuenta de un solo ciclo» al agregar stock (sin avisos de renovación) y botón **Archivar cuenta vencida** en Stock (cuentas completas y por perfiles). Salen de Stock, se conserva el historial en Proveedores → Cuentas archivadas.
- **Stock más limpio:** las cuentas no disponibles quedan plegadas bajo «Ver cuentas no disponibles (N)»; lo vendible aparece primero.
- **Colores:** chips seleccionados y menú inferior pasan del morado por defecto de Material al turquesa de marca (modo oscuro y claro).
- **Menú:** «Proveedore» cortado → «Proveedor», con icono de tienda.

---

## D. Ampliación v7.9: cuentas que el proveedor no renueva (de un solo ciclo)

Problema reportado: cuentas de 30 días que el proveedor no renueva con el mismo correo quedaban en Stock como «NO DISPONIBLE» en rojo, con el mensaje «Renuévala en Proveedores», que no tenía salida.

| Mejora | Cómo funciona |
|---|---|
| **Cuenta de un solo ciclo** | Casilla al crear la cuenta y botón en la tarjeta de Stock («Marcar como cuenta de un solo ciclo»). Es **permanente** por proveedor+cuenta (antes solo se ignoraba un ciclo y los avisos volvían al cambiar la fecha). No genera avisos ni pendientes de renovación al proveedor. Se incluye en los respaldos. |
| **Archivar vencidas** | Si está vencida y sin clientes activos, «Archivar cuenta» la quita de Stock conservando historial. Si vuelves a comprar el mismo correo, se reabre. |
| **Cambiar al cliente de cuenta** | Editar entrega → «Cambiar a otra cuenta libre»: lista cuentas libres del mismo servicio que cubren la fecha del cliente, mueve al cliente, deja la cuenta vieja «No disponible» hasta verificar el corte y envía los datos nuevos por WhatsApp. |
| **Vender «hasta que venza la cuenta»** | En la venta desde Stock, un botón ajusta la duración a los días que le quedan a la cuenta (antes la venta de 30 días se bloqueaba si la cuenta tenía menos). |

## E. Colores e iconos (evaluación)
- **Color con significado** en Stock: azul = libre, **gris = vencida**, **ámbar = bloqueada por verificar**, morado = «1 CICLO». Antes todo lo no vendible era rojo, igual que una alerta real, y no se distinguía una cuenta muerta de una pendiente de verificación.
- **Modo claro:** el cian (#19E6E6) sobre fondo blanco era casi ilegible; ahora los textos/acentos usan el color primario del tema (cian en oscuro, verde-azulado oscuro en claro). La barra inferior también.
- **Barra inferior:** la etiqueta «Proveedores» se cortaba («Proveedore»); ahora «Proveedor» con icono de tienda (más claro que el de grupo de personas).
- Pendiente (decisión de diseño): reducir el uso de rojo para estados que no son errores y usar iconos por tipo de servicio.

Recordatorio: nada de esto se ha compilado ni probado en un teléfono.

# Auditoría profunda v7.9 (sobre v7.8)

**Alcance:** lectura completa del código fuente (Kotlin, manifiesto, Gradle, workflow, pruebas, documentos de Play Store).
**Limitación importante:** en el entorno de la auditoría no hay compilador Kotlin ni SDK de Android. Los cambios **no se han compilado ni ejecutado**. Lo que sí se verificó: equilibrio de llaves/paréntesis de todos los `.kt` (el original y el modificado), validez de YAML y del manifiesto XML, ausencia de funciones duplicadas, y la lógica pura (retención de copias y plantillas) simulada aparte. La compilación y las pruebas deben pasar en GitHub Actions antes de instalar.

## A. Errores encontrados y CORREGIDOS

| # | Gravedad | Problema | Corrección |
|---|---|---|---|
| 1 | **Alta** | Los mensajes a clientes y proveedores salían con **doble símbolo de moneda** («Valor: $$25.000»): la plantilla traía `$` y `money()` ya lo incluye. Afectaba a las plantillas por defecto **y** a las ya guardadas. | Plantillas por defecto corregidas; `fillTemplate` y la plantilla de proveedor normalizan también las plantillas ya guardadas. |
| 2 | **Alta** | **Respaldos automáticos: se destruía el historial.** Cada movimiento forzaba una copia y solo se conservaban las últimas 7 → tras 7 operaciones del mismo día no quedaba ninguna copia de días anteriores. | Se conserva la copia más reciente de cada uno de los últimos 7 **días**; forzado limitado a 1 por minuto (`BackupRetention`, con pruebas). |
| 3 | **Alta** | El respaldo creaba primero el archivo y después generaba el contenido: si fallaba, quedaba un archivo **vacío** que además podía desplazar a copias buenas. | El contenido se genera antes de crear el archivo; los archivos vacíos nunca cuentan como copia y se eliminan. |
| 4 | **Alta** | Un fallo de copia automática era **silencioso**: el usuario creía estar protegido. | Aviso rojo en Ajustes cuando el último intento falló. |
| 5 | **Alta** | **Restaurar** reemplazaba todos los datos con un solo toque, sin confirmación; además la restauración no era atómica (si fallaba a medias quedaba una mezcla) y dejaba contraseñas en texto plano en `SharedPreferences` si fallaba. | Confirmación explícita; el respaldo se valida completo **antes** de tocar nada; reemplazo en una sola transacción de Room (`replaceAll`); ya no se escriben credenciales en preferencias. |
| 6 | **Alta** | Si la clave del Keystore no estaba disponible, `decrypt` devolvía `""` y el siguiente guardado **borraba la credencial para siempre**. Además esa contraseña vacía/ilegible podía usarse como contraseña de respaldo. | Se conserva el valor cifrado intacto; en mensajes se trata como vacío (nunca se envía texto cifrado al cliente); la contraseña de respaldo ilegible se ignora. |
| 7 | Media | **Incidencias**: todos los clientes afectados recibían el mismo `id` de historial (mismo milisegundo) y `REPLACE` dejaba **solo uno**. Además la cuenta se comparaba distinguiendo mayúsculas. | Ids únicos; comparación con `accountKey`. |
| 8 | Media | **Cobranza rápida** saltaba un cliente tras cada renovación (la cola se acorta y el índice también avanzaba). El contador podía mostrar «5/4». | Corregido. |
| 9 | Media | Códigos de alarma/notificación `(id & 0xFFFFFF) + código×1.000.000` **se solapaban**: dos entregas distintas podían pisarse un aviso. | Nueva mezcla del identificador completo. |
| 10 | Media | Cuentas completas: «Habilitar» no pedía confirmar la revocación del acceso y se podía «habilitar» con el proveedor vencido (al renovar al proveedor quedaba vendible sin verificar). | Confirmación; bloqueado mientras el proveedor esté vencido. |
| 11 | Media | Entregas con **fecha inválida** no aparecían en Inicio ni en Renovar y no generaban avisos (invisibles). | Grupo «Revisar fecha» en Renovar y aviso en Inicio. |
| 12 | Media | Tras restaurar, las plantillas y el modo oscuro seguían con los valores anteriores en memoria (y podían sobrescribir lo restaurado al editar). | Se recargan tras restaurar. |
| 13 | Media | `isSaleIncome` usaba `contains("VENTA")`: una compra a un proveedor llamado «VentasTV» contaba como **ingreso**. | `startsWith`. |
| 14 | Media | Renovar a un cliente más allá del vencimiento del proveedor no avisaba. | Aviso (no bloquea) en el diálogo de renovación. |
| 15 | Baja | `ClientRecord.createdAt` se sobrescribía con la fecha de hoy en cada guardado. | Se conserva la fecha real. |
| 16 | Baja | Abrir WhatsApp sin teléfono o sin app/navegador **cerraba la app** o abría un enlace vacío. | `openWhatsApp` con aviso. |
| 17 | Baja | «Dar plazo» → «Ajustar vencimiento» dejaba la promesa anterior visible. | Se limpia. |
| 18 | Baja | La búsqueda global ofrecía «Credenciales» para clientes ya dados de baja. | Oculto para CORTADO. |
| 19 | Baja | Tocar dos veces el mismo aviso no volvía a abrir la pestaña. | `requestNonce`. |
| 20 | Baja | Los receptores de alarma/arranque trabajaban en el hilo principal. | `goAsync()` + hilo. |
| 21 | Baja | `BootReceiver` exportado sin necesidad. | `exported=false`. |
| 22 | Baja | Sustitución secuencial de variables: un dato que contenga `{pin}` se volvía a sustituir. | Un solo recorrido. |
| 23 | Proceso | El workflow tomaba **un ZIP cualquiera** si había varios, y los artefactos se llamaban «v7.6». | Falla si hay más de un ZIP; nombres v7.9. |

Versión: `7.9` / `versionCode 40`. Sin cambios de esquema Room ni de `applicationId`.

## B. Hallazgos NO corregidos (decisión tuya o requieren pruebas en dispositivo)

1. **Hilo principal bloqueado.** `Store` usa `runBlocking` y cada guardado reescribe tablas completas, sincroniza avisos y puede escribir una copia (PBKDF2 150.000 iteraciones). Con muchos datos habrá tirones/ANR. Recomendado: mover a `ViewModel` + corrutinas.
2. **Avisos perdidos.** Si el teléfono está apagado/sin batería a las 9:00, ese aviso no se entrega al encender (solo se reprograman los futuros). Se usan alarmas inexactas (`setAndAllowWhileIdle`) que Android puede retrasar.
3. **Cuenta duplicada en Stock.** Añadir otra vez el mismo correo/servicio/proveedor crea un segundo «maestro» (tarjeta separada) y duplica el costo del mes. Para añadir perfiles a una cuenta existente hoy hay que editar, no volver a crearla.
4. **Nombre de proveedor.** Un proveedor escrito sin espacios y con punto (`ana.garcia`, `ana.lopez`) se interpreta como dominio y ambos pasan a llamarse «ANA»: se mezclarían sus cuentas y pagos.
5. **«Eliminar registro de prueba»** borra también los movimientos de dinero de esa entrega y deja el acceso `DISPONIBLE` (no `NO_DISPONIBLE`). Úsalo solo si de verdad no se entregó nada.
6. **Ids por `System.currentTimeMillis()`** (clientes, stock, plantillas): colisión posible si se crean dos en el mismo milisegundo (p. ej. importaciones masivas futuras).
7. **Privacidad:** nombres, teléfonos y correos de cuentas se guardan **sin cifrar** en Room (solo contraseñas/PIN van cifradas); no hay `FLAG_SECURE` (capturas y vista de apps recientes muestran datos). El texto de «Privacidad» lo dice correctamente solo de contraseñas/PIN.
8. **Incidencias** extienden fechas sin comprobar cobertura del proveedor; las renovaciones solo advierten.
9. El historial se interpreta separando por « • »: un proveedor/cuenta que contenga ese separador rompería la coincidencia de pagos.
10. Room `version=1` con `exportSchema=false` y sin migraciones: el primer cambio de esquema futuro exigirá migración explícita. Lint con `abortOnError=false`, sin minificación.

## C. Antes de instalar
1. Crea un respaldo cifrado en la v7.8 instalada y guárdalo fuera del teléfono.
2. Sube **un solo ZIP** al repositorio y ejecuta el workflow. Revisa primero el reporte de pruebas (`Diagnostico-Pruebas-v7.9`).
3. Instala con **la misma firma**; no desinstales la anterior.
4. Prueba: enviar una renovación por WhatsApp (sin «$$»), restaurar un respaldo (aparece la confirmación), forzar un fallo de carpeta de respaldo (aparece el aviso), cobranza rápida con 3 clientes, incidencia con varios clientes (un movimiento por cliente).

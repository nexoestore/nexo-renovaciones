package com.nexo.suscripciones

/** Reglas de mensajes sin dependencias de Android: se prueban con JUnit puro. */

fun money(v:Long)="$${"%,d".format(v)}"

/** Una credencial que sigue cifrada (clave del Keystore no disponible) se trata como vacía en mensajes y pantallas. */
fun readableOrBlank(value:String):String=if(value.startsWith("enc1:"))"" else value

/** Ingreso = venta nueva o renovación de cliente. startsWith (no contains): "COMPRA STOCK • VentasTV" es un gasto. */
fun isSaleIncome(x:Hist)=x.action.startsWith("VENTA")||x.action.startsWith("RENOVACIÓN +")

fun fillTemplate(t:String,s:Sub):String{
 val values=mapOf("{cliente}" to s.client,"{servicio}" to s.service,"{fecha}" to s.end,"{precio}" to money(s.price),"{cuenta}" to s.account,"{perfil}" to s.profile,"{pin}" to readableOrBlank(s.pin),"{password}" to readableOrBlank(s.password))
 val optional=setOf("{cuenta}","{password}","{perfil}","{pin}")
 // Plantillas guardadas con "${'$'}{precio}" generaban "$$25.000": money() ya incluye el símbolo.
 val source=t.replace("${'$'}{precio}","{precio}")
 val tokens=Regex("\\{(cliente|servicio|fecha|precio|cuenta|perfil|pin|password)\\}")
 return source.lines()
  .filterNot{line->optional.any{key->line.contains(key)&&values[key].isNullOrBlank()}}
  // Un solo recorrido: un dato (p. ej. una contraseña) que contenga "{pin}" no se vuelve a sustituir.
  .map{line->tokens.replace(line){m->values["{"+m.groupValues[1]+"}"]?:m.value}}
  .joinToString("\n")
  .replace(Regex("\n{3,}"),"\n\n")
  .trim()
}

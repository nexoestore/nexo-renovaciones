# Borrador de ficha de Google Play

## Nombre
Control de Cuentas Streaming

## Descripción corta
Gestiona cuentas, perfiles, stock, renovaciones, cobros y proveedores desde un solo lugar.

## Descripción completa
Control de Cuentas Streaming está diseñada para negocios que administran accesos a servicios digitales y necesitan mantener el control diario de sus cuentas, perfiles, clientes, renovaciones y costos.

Funciones principales:

- Centro de control con trabajo pendiente del día.
- Cuentas completas y perfiles separados correctamente.
- Stock disponible listo para vender.
- Venta rápida reutilizando credenciales y datos del proveedor.
- Plantillas de servicios para registrar operaciones con menos pasos.
- Renovaciones, vencidos y promesas de pago.
- Cobranza rápida por WhatsApp.
- Control de proveedores y vencimientos de cuentas.
- Reportes de ingresos, costos y utilidad.
- Búsqueda global por cliente, correo, servicio o proveedor.
- Respaldo local manual y automático.

La información se guarda localmente en el dispositivo. La aplicación no incluye publicidad ni analítica de terceros en esta versión.

## Aviso de independencia

Control de Cuentas Streaming es una herramienta administrativa independiente. No está afiliada, patrocinada ni respaldada por proveedores de streaming o servicios digitales de terceros. El usuario es responsable de utilizar la aplicación y gestionar accesos conforme a los términos de los servicios que administre.

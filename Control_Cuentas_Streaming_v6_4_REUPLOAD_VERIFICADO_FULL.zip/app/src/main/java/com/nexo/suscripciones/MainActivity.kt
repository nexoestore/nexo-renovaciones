package com.nexo.suscripciones

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Sub(
    val id:Long=System.currentTimeMillis(), val client:String, val phone:String, val service:String,
    val account:String, val profile:String, val type:String, val price:Long, val start:String, val end:String,
    val status:String="ACTIVO", val paid:Boolean=true, val pin:String="", val accountCost:Long=0,
    val paymentMethod:String="Efectivo", val contacted:Boolean=false, val password:String="",
    val provider:String="", val providerPhone:String="", val accountEnd:String="", val accountRenewCost:Long=0,
    val promiseDate:String="", val stockId:Long=0, val lastContact:String=""
)
data class StockItem(
    val id:Long=System.currentTimeMillis(), val service:String, val account:String, val password:String="",
    val profile:String="", val pin:String="", val type:String="PERFIL/PANTALLA", val provider:String="",
    val providerPhone:String="", val accountEnd:String="", val accountCost:Long=0, val accountRenewCost:Long=0,
    val status:String="DISPONIBLE"
)
data class Hist(val id:Long=System.currentTimeMillis(),val subId:Long,val date:String,val action:String,val amount:Long=0,val method:String="")
data class Templates(
    val due3:String="Hola {cliente} 👋 Tu servicio {servicio} vence el {fecha}. Valor de renovación: ${'$'}{precio}.",
    val due1:String="Hola {cliente} 👋 Tu servicio {servicio} vence mañana ({fecha}). Valor: ${'$'}{precio}.",
    val due0:String="Hola {cliente} 👋 Tu servicio {servicio} vence hoy ({fecha}). Si deseas continuar, puedes renovar por ${'$'}{precio}.",
    val expired:String="Hola {cliente} 👋 Tu servicio {servicio} venció el {fecha}. Si deseas reactivarlo, escríbeme para renovar.",
    val delivery:String="Hola {cliente} 👋 Aquí tienes tus datos de {servicio}:\nCuenta: {cuenta}\nContraseña: {password}\nPerfil: {perfil}\nPIN/clave: {pin}\nVence: {fecha}\nGracias por preferir Nexo."
)
data class ServiceTemplate(
    val id:Long=System.currentTimeMillis(), val name:String, val type:String="CUENTA COMPLETA", val durationDays:Int=30,
    val defaultPrice:Long=0, val provider:String="", val providerPhone:String="", val accountCost:Long=0,
    val renewCost:Long=0
)

class Store(private val c:Context){
 private val p=c.getSharedPreferences("nexo_db",Context.MODE_PRIVATE)
 fun subs():MutableList<Sub>{
  val a=JSONArray(p.getString("subs","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Sub(
   o.getLong("id"),o.getString("client"),o.optString("phone"),o.getString("service"),o.optString("account"),o.optString("profile"),o.optString("type","PERFIL"),o.optLong("price"),o.getString("start"),o.getString("end"),o.optString("status","ACTIVO"),o.optBoolean("paid",true),o.optString("pin"),o.optLong("accountCost"),o.optString("paymentMethod","Efectivo"),o.optBoolean("contacted",false),o.optString("password",""),o.optString("provider",""),o.optString("providerPhone",""),o.optString("accountEnd",""),o.optLong("accountRenewCost"),o.optString("promiseDate",""),o.optLong("stockId",0),o.optString("lastContact","")
  )}
 }
 fun save(items:List<Sub>){
  val a=JSONArray();items.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("client",x.client);put("phone",x.phone);put("service",x.service);put("account",x.account);put("profile",x.profile);put("type",x.type);put("price",x.price);put("start",x.start);put("end",x.end);put("status",x.status);put("paid",x.paid);put("pin",x.pin);put("accountCost",x.accountCost);put("paymentMethod",x.paymentMethod);put("contacted",x.contacted);put("password",x.password);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountRenewCost",x.accountRenewCost);put("promiseDate",x.promiseDate);put("stockId",x.stockId);put("lastContact",x.lastContact)})}
  p.edit().putString("subs",a.toString()).apply();ReminderScheduler.sync(c,items);autoBackupIfNeeded()
 }
 fun stock():MutableList<StockItem>{val a=JSONArray(p.getString("stock","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);StockItem(o.getLong("id"),o.optString("service"),o.optString("account"),o.optString("password"),o.optString("profile"),o.optString("pin"),o.optString("type","PERFIL/PANTALLA"),o.optString("provider"),o.optString("providerPhone"),o.optString("accountEnd"),o.optLong("accountCost"),o.optLong("accountRenewCost"),o.optString("status","DISPONIBLE"))}}
 fun saveStock(items:List<StockItem>){val a=JSONArray();items.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("service",x.service);put("account",x.account);put("password",x.password);put("profile",x.profile);put("pin",x.pin);put("type",x.type);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountEnd",x.accountEnd);put("accountCost",x.accountCost);put("accountRenewCost",x.accountRenewCost);put("status",x.status)})};p.edit().putString("stock",a.toString()).apply();autoBackupIfNeeded()}
 fun hist():MutableList<Hist>{val a=JSONArray(p.getString("hist","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Hist(o.getLong("id"),o.getLong("subId"),o.getString("date"),o.getString("action"),o.optLong("amount"),o.optString("method"))}}
 fun saveHist(h:List<Hist>){val a=JSONArray();h.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("subId",x.subId);put("date",x.date);put("action",x.action);put("amount",x.amount);put("method",x.method)})};p.edit().putString("hist",a.toString()).apply();autoBackupIfNeeded()}
 fun templates():Templates{val o=runCatching{JSONObject(p.getString("templates","{}")!!)}.getOrDefault(JSONObject());val d=Templates();val oldDelivery=o.optString("delivery",d.delivery);val delivery=if(oldDelivery.contains("{password}"))oldDelivery else oldDelivery.replace("Cuenta: {cuenta}","Cuenta: {cuenta}\nContraseña: {password}");return Templates(o.optString("due3",d.due3),o.optString("due1",d.due1),o.optString("due0",d.due0),o.optString("expired",d.expired),delivery)}
 fun saveTemplates(t:Templates){p.edit().putString("templates",JSONObject().apply{put("due3",t.due3);put("due1",t.due1);put("due0",t.due0);put("expired",t.expired);put("delivery",t.delivery)}.toString()).apply();autoBackupIfNeeded()}
 fun services():MutableList<ServiceTemplate>{val a=JSONArray(p.getString("services","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);ServiceTemplate(o.getLong("id"),o.optString("name"),o.optString("type","CUENTA COMPLETA"),o.optInt("durationDays",30),o.optLong("defaultPrice"),o.optString("provider"),o.optString("providerPhone"),o.optLong("accountCost"),o.optLong("renewCost"))}}
 fun saveServices(items:List<ServiceTemplate>){val a=JSONArray();items.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("name",x.name);put("type",x.type);put("durationDays",x.durationDays);put("defaultPrice",x.defaultPrice);put("provider",x.provider);put("providerPhone",x.providerPhone);put("accountCost",x.accountCost);put("renewCost",x.renewCost)})};p.edit().putString("services",a.toString()).apply();autoBackupIfNeeded()}
 fun backup():String=JSONObject().apply{put("backupVersion",4);put("appVersion","6.4");put("subs",JSONArray(p.getString("subs","[]")));put("stock",JSONArray(p.getString("stock","[]")));put("hist",JSONArray(p.getString("hist","[]")));put("templates",JSONObject(p.getString("templates","{}")!!));put("services",JSONArray(p.getString("services","[]")))}.toString(2)
 fun restore(text:String):Boolean=runCatching{val o=JSONObject(text);p.edit().putString("subs",o.getJSONArray("subs").toString()).putString("stock",o.optJSONArray("stock")?.toString()?:"[]").putString("hist",o.optJSONArray("hist")?.toString()?:"[]").putString("templates",o.optJSONObject("templates")?.toString()?:"{}").putString("services",o.optJSONArray("services")?.toString()?:"[]").commit();ReminderScheduler.sync(c,subs());autoBackupIfNeeded(true);true}.getOrDefault(false)
 fun backupFolder():String=p.getString("backup_folder","")?:""
 fun lastAutoBackup():String=p.getString("last_auto_backup","")?:""
 fun setBackupFolder(uri:Uri):Boolean=runCatching{
  c.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
  p.edit().putString("backup_folder",uri.toString()).putString("last_auto_backup","").commit();autoBackupIfNeeded(true)
 }.getOrDefault(false)
 fun autoBackupIfNeeded(force:Boolean=false):Boolean=runCatching{
  val raw=backupFolder();if(raw.isBlank())return false
  val today=LocalDate.now().toString();if(!force&&lastAutoBackup()==today)return true
  val tree=Uri.parse(raw);val docId=DocumentsContract.getTreeDocumentId(tree);val parent=DocumentsContract.buildDocumentUriUsingTree(tree,docId)
  val out=DocumentsContract.createDocument(c.contentResolver,parent,"application/octet-stream","ControlStreaming_Auto_${today}_${System.currentTimeMillis()}.nexo")?:return false
  c.contentResolver.openOutputStream(out)?.bufferedWriter()?.use{it.write(backup())}
  p.edit().putString("last_auto_backup",today).apply();trimAutoBackups(tree);true
 }.getOrDefault(false)
 private fun trimAutoBackups(tree:Uri){runCatching{
  val parentId=DocumentsContract.getTreeDocumentId(tree);val children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parentId)
  val rows=mutableListOf<Pair<String,String>>()
  c.contentResolver.query(children,arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME),null,null,null)?.use{cur->val idIx=cur.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);val nameIx=cur.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);while(cur.moveToNext()){val id=cur.getString(idIx);val name=cur.getString(nameIx);if(name.startsWith("ControlStreaming_Auto_"))rows+=name to id}}
  rows.sortedByDescending{it.first}.drop(7).forEach{(_,id)->DocumentsContract.deleteDocument(c.contentResolver,DocumentsContract.buildDocumentUriUsingTree(tree,id))}
 }}
}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);ReminderScheduler.sync(this,Store(this).subs());if(android.os.Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),1001);setContent{NexoApp()}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun NexoApp(){
 val c=LocalContext.current
 val st=remember{Store(c)}
 var subs by remember{mutableStateOf(st.subs().toList())}
 var hist by remember{mutableStateOf(st.hist().toList())}
 var stock by remember{mutableStateOf(st.stock().toList())}
 var services by remember{mutableStateOf(st.services().toList())}
 var templates by remember{mutableStateOf(st.templates())}
 var tab by remember{mutableIntStateOf(0)}
 var add by remember{mutableStateOf(false)}
 var dark by remember{mutableStateOf(false)}
 var editing by remember{mutableStateOf<Sub?>(null)}
 var searchOpen by remember{mutableStateOf(false)}
 fun persist(items:List<Sub>){subs=items;st.save(items)}
 fun persistStock(items:List<StockItem>){stock=items;st.saveStock(items)}
 fun persistServices(items:List<ServiceTemplate>){services=items;st.saveServices(items)}
 fun log(id:Long,a:String,m:Long=0,method:String=""){hist=hist+Hist(subId=id,date=LocalDate.now().toString(),action=a,amount=m,method=method);st.saveHist(hist);st.autoBackupIfNeeded(true)}
 fun contact(s:Sub){val date=LocalDate.now().toString();persist(subs.map{if(it.id==s.id)it.copy(contacted=true,lastContact=date)else it});log(s.id,"CONTACTADO POR WHATSAPP")}
 fun renew(s:Sub){val old=LocalDate.parse(s.end);val base=if(old.isBefore(LocalDate.now()))LocalDate.now() else old;persist(subs.map{if(it.id==s.id)it.copy(end=base.plusDays(30).toString(),status="ACTIVO",paid=true,contacted=false,promiseDate="")else it});log(s.id,"RENOVACIÓN +30 DÍAS",s.price,s.paymentMethod)}
 fun cut(s:Sub,reason:String){
  persist(subs.map{if(it.id==s.id)it.copy(status="CORTADO",contacted=true,promiseDate="")else it})
  if(s.stockId>0){persistStock(stock.map{if(it.id==s.stockId)it.copy(status="DISPONIBLE")else it})}
  else if(s.account.isNotBlank()&&stock.none{it.account==s.account&&it.profile==s.profile&&effectiveStockStatus(it)=="DISPONIBLE"}){
   persistStock(stock+StockItem(service=s.service,account=s.account,password=s.password,profile=s.profile,pin=s.pin,type=normalizedAccessType(s.type,s.profile),provider=s.provider,providerPhone=s.providerPhone,accountEnd=s.accountEnd,accountCost=s.accountCost,accountRenewCost=s.accountRenewCost,status="DISPONIBLE"))
  }
  log(s.id,"BAJA • $reason • ${s.service} • ACCESO LIBERADO")
 }
 fun promise(s:Sub,date:String){persist(subs.map{if(it.id==s.id)it.copy(status="ESPERA",promiseDate=date)else it});log(s.id,"PROMESA DE PAGO • $date")}
 fun adjustEnd(s:Sub,newEnd:String,reason:String){val old=s.end;persist(subs.map{if(it.id==s.id)it.copy(end=newEnd,status="ACTIVO")else it});log(s.id,"AJUSTE VENCIMIENTO: $old → $newEnd${if(reason.isNotBlank())" • $reason" else ""}")}
 fun updateSub(updated:Sub){persist(subs.map{if(it.id==updated.id)updated else it});if(updated.stockId>0)persistStock(stock.map{if(it.id==updated.stockId)it.copy(service=updated.service,account=updated.account,password=updated.password,profile=updated.profile,pin=updated.pin,type=normalizedAccessType(updated.type,updated.profile),provider=updated.provider,providerPhone=updated.providerPhone,accountEnd=updated.accountEnd,accountCost=updated.accountCost,accountRenewCost=updated.accountRenewCost)else it});log(updated.id,"EDICIÓN DE ENTREGA / CUENTA")}
 val streamDark=darkColorScheme(primary=StreamCyan,secondary=StreamGreen,tertiary=StreamAmber,background=Color(0xFF071018),surface=Color(0xFF0D1821),surfaceVariant=Color(0xFF17232C),outline=Color(0xFF70818D),outlineVariant=Color(0xFF26343E))
 val streamLight=lightColorScheme(primary=Color(0xFF006B7D),secondary=Color(0xFF006C50),tertiary=Color(0xFF7A5900),surfaceVariant=Color(0xFFE7F0F4))
 val appShapes=Shapes(small=RoundedCornerShape(10.dp),medium=RoundedCornerShape(16.dp),large=RoundedCornerShape(22.dp))
 MaterialTheme(colorScheme=if(dark)streamDark else streamLight,shapes=appShapes){
  Scaffold(
   topBar={TopAppBar(title={Text("Control de Cuentas Streaming",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,maxLines=1)},actions={IconButton({searchOpen=true}){Text("⌕",style=MaterialTheme.typography.titleLarge)}},colors=TopAppBarDefaults.topAppBarColors(containerColor=MaterialTheme.colorScheme.background))},
   floatingActionButton={if(tab==0)FloatingActionButton({add=true},containerColor=MaterialTheme.colorScheme.primary){Text("＋",style=MaterialTheme.typography.titleLarge)}},
   bottomBar={NavigationBar(containerColor=MaterialTheme.colorScheme.surface){val labels=listOf("Inicio","Renovar","Cuentas","Reportes","Más");val glyphs=listOf("⌂","↻","▣","▤","☰");labels.forEachIndexed{i,x->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(glyphs[i],style=MaterialTheme.typography.titleMedium)},label={Text(x)})}}}
  ){pad->Box(Modifier.padding(pad)){when(tab){
   0->Home(subs,stock,services,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,::contact,{editing=it})
   1->Renewals(subs,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,::contact,{editing=it})
   2->Accounts(subs,stock,services,::persistStock,{sold,item->persist(subs+sold);persistStock(stock.map{if(it.id==item.id)it.copy(status="OCUPADO")else it});log(sold.id,"VENTA / PAGO DESDE STOCK",sold.price,sold.paymentMethod);wa(c,sold,fillTemplate(templates.delivery,sold))},::adjustEnd,{editing=it})
   3->Reports(subs,stock,hist)
   else->More(subs,stock,hist,services,::persistServices,dark,{dark=it},templates,{templates=it;st.saveTemplates(it)},st,{subs=st.subs();hist=st.hist();stock=st.stock();services=st.services()})
  }}}
  if(add)AddDialog(services,{add=false}){x->persist(subs+x);log(x.id,"VENTA / PAGO",x.price,x.paymentMethod);wa(c,x,fillTemplate(templates.delivery,x));add=false}
  editing?.let{current->EditSubDialog(current,{editing=null}){updated->updateSub(updated);editing=null}}
  if(searchOpen)GlobalSearchDialog(subs,stock,templates,{searchOpen=false},{sub->wa(c,sub,fillTemplate(templates.delivery,sub))},{sub->searchOpen=false;editing=sub})
 }
}

val StreamCyan=Color(0xFF27C9E8)
val StreamGreen=Color(0xFF49C878)
val StreamAmber=Color(0xFFFFB547)
val StreamRed=Color(0xFFFF5C68)
val StreamPurple=Color(0xFF9A7CFF)

fun normalizedAccessType(type:String,profile:String=""):String{val u=type.uppercase();return if(u.contains("CUENTA COMPLETA")||(u.contains("CORREO/CONTRASEÑA")&&profile.isBlank()))"CUENTA COMPLETA" else "PERFIL/PANTALLA"}
fun isComplete(s:Sub)=normalizedAccessType(s.type,s.profile)=="CUENTA COMPLETA"
fun isComplete(x:StockItem)=normalizedAccessType(x.type,x.profile)=="CUENTA COMPLETA"

fun days(s:Sub)=ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.end))
fun accountDays(s:Sub)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.accountEnd))}.getOrDefault(999)
fun effectiveStockStatus(x:StockItem):String{val expired=x.accountEnd.isNotBlank()&&runCatching{LocalDate.parse(x.accountEnd).isBefore(LocalDate.now())}.getOrDefault(false);return if(expired)"NO_DISPONIBLE" else x.status}
fun stockAccountDays(x:StockItem)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(x.accountEnd))}.getOrDefault(999)
fun money(v:Long)="$${"%,d".format(v)}"
fun fillTemplate(t:String,s:Sub):String{
 val values=mapOf("{cliente}" to s.client,"{servicio}" to s.service,"{fecha}" to s.end,"{precio}" to money(s.price),"{cuenta}" to s.account,"{perfil}" to s.profile,"{pin}" to s.pin,"{password}" to s.password)
 val optional=setOf("{cuenta}","{password}","{perfil}","{pin}")
 return t.lines()
  .filterNot{line->optional.any{key->line.contains(key)&&values[key].isNullOrBlank()}}
  .map{line->values.entries.fold(line){acc,(k,v)->acc.replace(k,v)}}
  .joinToString("\n")
  .replace(Regex("\n{3,}"),"\n\n")
  .trim()
}
fun messageFor(s:Sub,t:Templates):String=fillTemplate(when{days(s)<0->t.expired;days(s)==0L->t.due0;days(s)==1L->t.due1;else->t.due3},s)
fun wa(c:Context,s:Sub,msg:String){val u="https://wa.me/${s.phone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun ScreenHeader(title:String,subtitle:String){Column(verticalArrangement=Arrangement.spacedBy(3.dp)){Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text(subtitle,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun SectionTitle(title:String,subtitle:String=""){Column(Modifier.padding(top=4.dp,bottom=2.dp)){Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);if(subtitle.isNotBlank())Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun MetricCard(label:String,value:String,accent:Color,modifier:Modifier=Modifier){Card(modifier,colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.62f))){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){Text(value,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=accent);Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
@Composable fun StatusBadge(label:String,color:Color){Surface(shape=RoundedCornerShape(50),color=color.copy(alpha=.15f),contentColor=color){Text(label,Modifier.padding(horizontal=9.dp,vertical=4.dp),style=MaterialTheme.typography.labelSmall,fontWeight=FontWeight.Bold)}}
@Composable fun EmptyState(text:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.35f))){Text(text,Modifier.padding(16.dp),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}

@Composable fun Home(s:List<Sub>,stock:List<StockItem>,services:List<ServiceTemplate>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val active=s.filter{it.status!="CORTADO"}
 val today=active.count{days(it)==0L};val tomorrow=active.count{days(it)==1L};val d3=active.count{days(it) in 2..3};val expired=active.count{days(it)<0}
 val availableFull=stock.count{effectiveStockStatus(it)=="DISPONIBLE"&&isComplete(it)};val availableProfiles=stock.count{effectiveStockStatus(it)=="DISPONIBLE"&&!isComplete(it)}
 val deliveredFull=active.count{isComplete(it)};val occupiedProfiles=active.count{!isComplete(it)}
 val accounts=s.filter{it.account.isNotBlank()}.distinctBy{it.account};val stockAccounts=stock.filter{it.account.isNotBlank()}.distinctBy{it.account};val dueSubs=accounts.filter{accountDays(it) in 0..3};val dueStock=stockAccounts.filter{stockAccountDays(it) in 0..3&&dueSubs.none{s2->s2.account==it.account}};val providerDue=dueSubs.size+dueStock.size
 val promiseDue=active.count{it.status=="ESPERA"&&it.promiseDate.isNotBlank()&&runCatching{!LocalDate.parse(it.promiseDate).isAfter(LocalDate.now())}.getOrDefault(false)}
 val outOfStock=services.count{tpl->stock.none{it.service.equals(tpl.name,true)&&effectiveStockStatus(it)=="DISPONIBLE"}}
 val value=active.filter{days(it)<=3}.sumOf{it.price};val work=active.filter{days(it)<=3||it.status=="ESPERA"}.distinctBy{it.id}.sortedBy{it.end}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Panel de control","Hoy • ${LocalDate.now()}  ·  lo que requiere atención")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){MetricCard("Vencen hoy",today.toString(),if(today>0)StreamRed else StreamGreen,Modifier.weight(1f));MetricCard("Mañana",tomorrow.toString(),if(tomorrow>0)StreamAmber else StreamGreen,Modifier.weight(1f))}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){MetricCard("Vencidos",expired.toString(),if(expired>0)StreamRed else StreamGreen,Modifier.weight(1f));MetricCard("Stock listo",(availableFull+availableProfiles).toString(),StreamGreen,Modifier.weight(1f))}}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
   Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Inventario operativo",fontWeight=FontWeight.Bold);Text("Cuentas completas y perfiles",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(providerDue>0)"$providerDue por renovar" else "Al día",if(providerDue>0)StreamRed else StreamGreen)}
   HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Cuentas completas disponibles");Text(availableFull.toString(),fontWeight=FontWeight.Bold,color=StreamGreen)}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Cuentas completas entregadas");Text(deliveredFull.toString(),fontWeight=FontWeight.Bold)}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Perfiles disponibles");Text(availableProfiles.toString(),fontWeight=FontWeight.Bold,color=StreamGreen)}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Perfiles ocupados");Text(occupiedProfiles.toString(),fontWeight=FontWeight.Bold)}
  }}}
  item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primary.copy(alpha=.10f))){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Cobros próximos",fontWeight=FontWeight.Bold);Text(money(value),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Promesas para hoy",style=MaterialTheme.typography.bodySmall);Text(promiseDue.toString(),fontWeight=FontWeight.Bold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Servicios sin stock",style=MaterialTheme.typography.bodySmall);Text(outOfStock.toString(),fontWeight=FontWeight.Bold)}}}}
  if(providerDue>0){item{SectionTitle("Cuentas por renovar","Vencimiento del proveedor en los próximos 3 días")};items(dueSubs){x->ProviderDueCard(x)};items(dueStock){x->ProviderDueStockCard(x)}}
  item{SectionTitle("Trabajo de hoy","Renovaciones, vencidos y promesas de pago")}
  if(work.isEmpty())item{EmptyState("No tienes acciones pendientes para hoy.")}
  items(work){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}
 }
}

@Composable fun ProviderDueCard(s:Sub){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(s.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("Corte ${s.accountEnd.ifBlank{"sin fecha"}}",StreamRed)};Text(s.account,style=MaterialTheme.typography.bodyMedium);Text("Proveedor · ${s.provider.ifBlank{"Sin asignar"}}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Renovación ${money(s.accountRenewCost)}",fontWeight=FontWeight.SemiBold)}}}

@Composable fun ProviderDueStockCard(x:StockItem){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(x.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("Corte ${x.accountEnd.ifBlank{"sin fecha"}}",StreamRed)};Text(x.account,style=MaterialTheme.typography.bodyMedium);Text("Proveedor · ${x.provider.ifBlank{"Sin asignar"}}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Costo de renovar ${money(x.accountRenewCost)}",fontWeight=FontWeight.SemiBold);StatusBadge(if(effectiveStockStatus(x)=="DISPONIBLE")"STOCK DISPONIBLE" else effectiveStockStatus(x).replace('_',' '),if(effectiveStockStatus(x)=="DISPONIBLE")StreamGreen else StreamRed)}}}

@Composable fun Renewals(s:List<Sub>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val groups=listOf("En 3 días" to s.filter{it.status!="CORTADO"&&days(it) in 2..3},"Mañana" to s.filter{it.status!="CORTADO"&&days(it)==1L},"Hoy" to s.filter{it.status!="CORTADO"&&days(it)==0L},"Vencidos" to s.filter{it.status!="CORTADO"&&days(it)<0&&it.status!="ESPERA"},"En espera" to s.filter{it.status=="ESPERA"})
 val total=groups.sumOf{it.second.size};var quick by remember{mutableStateOf(false)}
 val queue=s.filter{it.status!="CORTADO"&&(days(it)<=3||it.status=="ESPERA")}.sortedBy{it.end}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{ScreenHeader("Renovaciones","Cobros, cortes y promesas de pago")}
  if(queue.isNotEmpty())item{Button({quick=true},Modifier.fillMaxWidth()){Text("Cobranza rápida · ${queue.size} pendientes")}}
  item{LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(groups){g->AssistChip(onClick={},label={Text("${g.first}  ${g.second.size}")})}}}
  if(total==0)item{EmptyState("Todo al día. No hay clientes pendientes de renovación.")}
  groups.filter{it.second.isNotEmpty()}.forEach{(title,list)->item{SectionTitle(title,"${list.size} cliente${if(list.size==1)"" else "s"}")};items(list.sortedBy{it.end}){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}}
 }
 if(quick)QuickCollectionDialog(queue,{quick=false},wa,contact,renew)
}

@Composable fun ActionCard(s:Sub,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 var showAdjust by remember(s.id){mutableStateOf(false)};var showEnd by remember(s.id){mutableStateOf(false)};var showPromise by remember(s.id){mutableStateOf(false)};var more by remember(s.id){mutableStateOf(false)};val ctx=LocalContext.current
 val d=days(s);val status=when{ s.status=="ESPERA"->"EN ESPERA";d<0->"VENCIDO";d==0L->"VENCE HOY";d==1L->"MAÑANA";else->"PRÓXIMO"};val color=when{ s.status=="ESPERA"->StreamPurple;d<0->StreamRed;d<=1->StreamAmber;else->StreamCyan}
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(s.client,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text(s.service,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(status,color)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vence ${s.end}",style=MaterialTheme.typography.bodyMedium);Text(money(s.price),fontWeight=FontWeight.Bold)}
  Text(s.type,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.account.isNotBlank())Text(s.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.profile.isNotBlank())Text("Perfil ${s.profile}${if(s.pin.isNotBlank())"  ·  PIN guardado" else ""}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.contacted)StatusBadge(if(s.lastContact.isNotBlank())"CONTACTADO ${s.lastContact}" else "CONTACTADO",StreamGreen)
  if(s.promiseDate.isNotBlank())Surface(shape=RoundedCornerShape(10.dp),color=StreamPurple.copy(alpha=.10f)){Text("Promesa de pago · ${s.promiseDate}",Modifier.padding(9.dp),style=MaterialTheme.typography.bodySmall,color=StreamPurple)}
  Button({wa(s);contact(s)},modifier=Modifier.fillMaxWidth()){Text("Cobrar por WhatsApp")}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({renew(s)},modifier=Modifier.weight(1f)){Text("Renovar +30")};if(d<=0)OutlinedButton({showPromise=true},modifier=Modifier.weight(1f)){Text("Dar plazo")}}
  if(d<=0)TextButton({showEnd=true},colors=ButtonDefaults.textButtonColors(contentColor=StreamRed),modifier=Modifier.fillMaxWidth()){Text("No renovó / finalizar servicio")}
  TextButton({more=!more},modifier=Modifier.fillMaxWidth()){Text(if(more)"Ocultar opciones" else "Más opciones")}
  if(more){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);OutlinedButton({wa(ctx,s,fillTemplate(Store(ctx).templates().delivery,s))},modifier=Modifier.fillMaxWidth()){Text("Enviar credenciales")};OutlinedButton({edit(s)},modifier=Modifier.fillMaxWidth()){Text("Editar entrega / cuenta")};OutlinedButton({showAdjust=true},modifier=Modifier.fillMaxWidth()){Text("Ajustar vencimiento")}}
 }}
 if(showAdjust)AdjustEndDialog(s,{showAdjust=false}){date,reason->adjust(s,date,reason);showAdjust=false};if(showEnd)EndServiceDialog(s,{showEnd=false}){reason->cut(s,reason);showEnd=false};if(showPromise)PromiseDialog(s,{showPromise=false}){date->promise(s,date);showPromise=false}
}

@Composable fun Accounts(s:List<Sub>,stock:List<StockItem>,services:List<ServiceTemplate>,saveStock:(List<StockItem>)->Unit,sell:(Sub,StockItem)->Unit,adjust:(Sub,String,String)->Unit,edit:(Sub)->Unit){
 val ctx=LocalContext.current;val st=remember{Store(ctx)};var adjusting by remember{mutableStateOf<Sub?>(null)};var section by remember{mutableStateOf("CUENTAS")};var addStock by remember{mutableStateOf(false)};var selling by remember{mutableStateOf<StockItem?>(null)};var editingStock by remember{mutableStateOf<StockItem?>(null)}
 val grouped=s.filter{it.account.isNotBlank()&&it.status!="CORTADO"}.groupBy{it.account};val completeDelivered=s.count{it.status!="CORTADO"&&isComplete(it)};val profileOccupied=s.count{it.status!="CORTADO"&&!isComplete(it)}
 val availableComplete=stock.count{effectiveStockStatus(it)=="DISPONIBLE"&&isComplete(it)};val availableProfiles=stock.count{effectiveStockStatus(it)=="DISPONIBLE"&&!isComplete(it)};val unavailable=stock.count{effectiveStockStatus(it)=="NO_DISPONIBLE"}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Cuentas y stock","Control de cuentas completas y perfiles listos para vender")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=section=="CUENTAS",onClick={section="CUENTAS"},label={Text("Entregadas")},modifier=Modifier.weight(1f));FilterChip(selected=section=="STOCK",onClick={section="STOCK"},label={Text("Stock disponible")},modifier=Modifier.weight(1f))}}
  if(section=="CUENTAS"){
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Cuentas completas",completeDelivered.toString(),StreamCyan,Modifier.weight(1f));MetricCard("Perfiles ocupados",profileOccupied.toString(),StreamPurple,Modifier.weight(1f))}}
   if(grouped.isEmpty())item{EmptyState("Aún no hay cuentas o perfiles entregados.")}
   items(grouped.entries.toList()){e->val base=e.value.first();val cost:Long=e.value.maxOfOrNull{it.accountCost}?:0L;val income=e.value.sumOf{it.price};val profit=income-cost;val complete=e.value.all{isComplete(it)};val active=e.value.size
    Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
     Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(base.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text(e.key,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(complete)"ENTREGADA" else "$active perfil${if(active==1)"" else "es"}",if(complete)StreamCyan else StreamPurple)}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Costo",money(cost),Modifier.weight(1f));MiniStat("Ingreso",money(income),Modifier.weight(1f));MiniStat("Utilidad",money(profit),Modifier.weight(1f),if(profit>=0)StreamGreen else StreamRed)}
     HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Text("Proveedor",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(base.provider.ifBlank{"Sin proveedor asignado"},fontWeight=FontWeight.SemiBold)
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vencimiento de cuenta",style=MaterialTheme.typography.bodySmall);Text(base.accountEnd.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Costo de renovar cuenta",style=MaterialTheme.typography.bodySmall);Text(money(base.accountRenewCost),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
     if(base.providerPhone.isNotBlank())OutlinedButton({waProvider(ctx,base)},Modifier.fillMaxWidth()){Text("Contactar proveedor")}
     SectionTitle(if(complete)"Cuenta entregada" else "Accesos / perfiles");e.value.forEach{x->ProfileRow(x,{wa(ctx,x,fillTemplate(st.templates().delivery,x))},{edit(x)},{adjusting=x})}
    }}
   }
  }else{
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Cuentas disponibles",availableComplete.toString(),StreamGreen,Modifier.weight(1f));MetricCard("Perfiles disponibles",availableProfiles.toString(),StreamGreen,Modifier.weight(1f))}}
   if(unavailable>0)item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=StreamRed.copy(alpha=.08f))){Row(Modifier.padding(12.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("No disponibles");Text(unavailable.toString(),fontWeight=FontWeight.Bold,color=StreamRed)}}}
   item{Button({addStock=true},Modifier.fillMaxWidth()){Text("+ Agregar stock")}}
   val names=(stock.map{it.service}+s.filter{it.status!="CORTADO"}.map{it.service}).filter{it.isNotBlank()}.distinct().sorted()
   if(names.isEmpty())item{EmptyState("Aún no hay stock registrado. Agrega cuentas completas o perfiles disponibles.")}
   names.forEach{name->item{StockServiceCard(name,stock.filter{it.service==name},s.filter{it.service==name&&it.status!="CORTADO"},{item->selling=item},{item->editingStock=item},{item->saveStock(stock.map{if(it.id==item.id)it.copy(status=if(effectiveStockStatus(it)=="NO_DISPONIBLE")"DISPONIBLE" else "NO_DISPONIBLE")else it})})}}
  }
 }
 adjusting?.let{x->AdjustEndDialog(x,{adjusting=null}){d,r->adjust(x,d,r);adjusting=null}}
 if(addStock)AddStockDialog(services,{addStock=false}){item->saveStock(stock+item);addStock=false}
 selling?.let{item->SellStockDialog(item,services,{selling=null}){sub->sell(sub,item);selling=null}}
 editingStock?.let{item->EditStockDialog(item,{editingStock=null}){updated->saveStock(stock.map{if(it.id==updated.id)updated else it});editingStock=null}}
}

@Composable fun StockServiceCard(service:String,items:List<StockItem>,activeSubs:List<Sub>,sell:(StockItem)->Unit,edit:(StockItem)->Unit,toggle:(StockItem)->Unit){
 val available=items.count{effectiveStockStatus(it)=="DISPONIBLE"}
 val occupied=activeSubs.size
 val unavailable=items.count{effectiveStockStatus(it)=="NO_DISPONIBLE"}
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("$available disponibles",if(available>0)StreamGreen else StreamRed)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Disponibles",available.toString(),Modifier.weight(1f),StreamGreen);MiniStat("Ocupados",occupied.toString(),Modifier.weight(1f),StreamCyan);MiniStat("No disp.",unavailable.toString(),Modifier.weight(1f),if(unavailable>0)StreamRed else MaterialTheme.colorScheme.onSurface)}
  if(items.isEmpty())Text("No hay accesos cargados en stock para este servicio.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  items.forEach{x->StockItemRow(x,{sell(x)},{edit(x)},{toggle(x)})}
 }}
}

@Composable fun StockItemRow(x:StockItem,sell:()->Unit,edit:()->Unit,toggle:()->Unit){
 val status=effectiveStockStatus(x)
 val color=when(status){"DISPONIBLE"->StreamGreen;"OCUPADO"->StreamCyan;else->StreamRed}
 Column(verticalArrangement=Arrangement.spacedBy(6.dp)){
  HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(if(x.type.contains("CUENTA",true))"Cuenta completa" else x.profile.ifBlank{"Perfil / pantalla"},fontWeight=FontWeight.SemiBold);if(x.account.isNotBlank())Text(x.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);if(x.accountEnd.isNotBlank())Text("Vence cuenta: ${x.accountEnd}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(status.replace('_',' '),color)}
  if(status=="DISPONIBLE")Button(sell,Modifier.fillMaxWidth()){Text("Vender / asignar")}
  if(x.status=="OCUPADO")Text("Gestiona este acceso desde Cuentas completas.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant) else Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(edit,Modifier.weight(1f)){Text("Editar")};OutlinedButton(toggle,Modifier.weight(1f)){Text(if(status=="NO_DISPONIBLE")"Habilitar" else "No disponible")}}
 }
}

@Composable fun AddStockDialog(services:List<ServiceTemplate>,close:()->Unit,save:(StockItem)->Unit){
 var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var profile by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var type by remember{mutableStateOf("PERFIL/PANTALLA")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var accountEnd by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 fun applyTemplate(t:ServiceTemplate){service=t.name;type=t.type;provider=t.provider;providerPhone=t.providerPhone;cost=t.accountCost.toString();renewCost=t.renewCost.toString();if(type=="CUENTA COMPLETA"){profile="";pin=""}}
 AlertDialog(onDismissRequest=close,title={Text("Agregar stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  if(services.isNotEmpty())item{Column{Text("PLANTILLAS RÁPIDAS",fontWeight=FontWeight.Bold);LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(services){t->AssistChip(onClick={applyTemplate(t)},label={Text(t.name)})}}}}
  item{Text("TIPO DE STOCK",fontWeight=FontWeight.Bold)};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=type=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA"},label={Text("Perfil / pantalla")},modifier=Modifier.weight(1f));FilterChip(selected=type=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA";profile="";pin=""},label={Text("Cuenta completa")},modifier=Modifier.weight(1f))}}
  item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};if(type=="PERFIL/PANTALLA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}}}
  item{Text("PROVEEDOR",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Vence cuenta completa AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=service.isNotBlank()&&account.isNotBlank(),onClick={save(StockItem(service=service,account=account,password=password,profile=if(type=="CUENTA COMPLETA")"" else profile,pin=if(type=="CUENTA COMPLETA")"" else pin,type=type,provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0,status="DISPONIBLE"))}){Text("Guardar stock")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun EditStockDialog(x:StockItem,close:()->Unit,save:(StockItem)->Unit){
 var service by remember(x.id){mutableStateOf(x.service)};var account by remember(x.id){mutableStateOf(x.account)};var password by remember(x.id){mutableStateOf(x.password)};var profile by remember(x.id){mutableStateOf(x.profile)};var pin by remember(x.id){mutableStateOf(x.pin)};var type by remember(x.id){mutableStateOf(x.type)};var provider by remember(x.id){mutableStateOf(x.provider)};var providerPhone by remember(x.id){mutableStateOf(x.providerPhone)};var accountEnd by remember(x.id){mutableStateOf(x.accountEnd)};var cost by remember(x.id){mutableStateOf(x.accountCost.toString())};var renewCost by remember(x.id){mutableStateOf(x.accountRenewCost.toString())}
 AlertDialog(onDismissRequest=close,title={Text("Editar stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=type=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA"},label={Text("Perfil")},modifier=Modifier.weight(1f));FilterChip(selected=type=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA"},label={Text("Cuenta completa")},modifier=Modifier.weight(1f))}}
  item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};if(type=="PERFIL/PANTALLA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave",pin){pin=it}}};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Vence cuenta completa AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=service.isNotBlank()&&account.isNotBlank(),onClick={save(x.copy(service=service,account=account,password=password,profile=if(type=="CUENTA COMPLETA")"" else profile,pin=if(type=="CUENTA COMPLETA")"" else pin,type=type,provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun SellStockDialog(x:StockItem,services:List<ServiceTemplate>,close:()->Unit,save:(Sub)->Unit){
 val tpl=services.firstOrNull{it.name.equals(x.service,true)};var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var price by remember{mutableStateOf((tpl?.defaultPrice?:0).let{if(it>0)it.toString() else ""})};var method by remember{mutableStateOf("Nequi")};var start by remember{mutableStateOf(LocalDate.now().toString())};var duration by remember{mutableStateOf((tpl?.durationDays?:30).toString())}
 AlertDialog(onDismissRequest=close,title={Text("Venta rápida desde stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primary.copy(alpha=.08f))){Column(Modifier.padding(10.dp)){Text(x.service,fontWeight=FontWeight.Bold);Text(if(isComplete(x))"Cuenta completa" else x.profile.ifBlank{"Perfil / pantalla"},style=MaterialTheme.typography.bodySmall);Text(x.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
  item{Text("Solo completa cliente y cobro. Las credenciales y proveedor se toman del stock.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
  item{F("Cliente",client){client=it}};item{F("WhatsApp (57...)",phone){phone=it}};item{F("Precio cobrado",price){price=it}};item{F("Método de pago",method){method=it}};item{F("Inicio AAAA-MM-DD",start){start=it}};item{F("Duración en días",duration){duration=it}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&runCatching{LocalDate.parse(start)}.isSuccess,onClick={val d=LocalDate.parse(start);val n=duration.toLongOrNull()?.coerceAtLeast(1L)?:30L;save(Sub(client=client,phone=phone,service=x.service,account=x.account,profile=x.profile,type=normalizedAccessType(x.type,x.profile),price=price.filter{it.isDigit()}.toLongOrNull()?:0,start=d.toString(),end=d.plusDays(n).toString(),pin=x.pin,accountCost=x.accountCost,paymentMethod=method,password=x.password,provider=x.provider,providerPhone=x.providerPhone,accountEnd=x.accountEnd,accountRenewCost=x.accountRenewCost,stockId=x.id))}){Text("Guardar y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun MiniStat(label:String,value:String,modifier:Modifier=Modifier,valueColor:Color=MaterialTheme.colorScheme.onSurface){Surface(modifier,shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.55f)){Column(Modifier.padding(9.dp)){Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value,style=MaterialTheme.typography.bodyMedium,fontWeight=FontWeight.Bold,color=valueColor)}}}
@Composable fun ProfileRow(s:Sub,credentials:()->Unit,edit:()->Unit,adjust:()->Unit){val free=s.status=="CORTADO";val expired=!free&&days(s)<0;Column(verticalArrangement=Arrangement.spacedBy(7.dp)){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(s.profile.ifBlank{s.type},fontWeight=FontWeight.SemiBold);if(!free)Text("${s.client}  ·  ${s.end}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(free)"LIBRE" else if(expired)"VENCIDO" else "ACTIVO",if(free)StreamGreen else if(expired)StreamRed else StreamCyan)};if(!free){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){TextButton(credentials,Modifier.weight(1f)){Text("Datos")};TextButton(edit,Modifier.weight(1f)){Text("Editar")};TextButton(adjust,Modifier.weight(1f)){Text("Fecha")}}}}}
fun waProvider(c:Context,s:Sub){val msg="Hola ${s.provider}, necesito revisar la cuenta ${s.account} de ${s.service}. Vence ${s.accountEnd}.";val u="https://wa.me/${s.providerPhone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun Reports(s:List<Sub>,stock:List<StockItem>,h:List<Hist>){
 val sales=h.filter{it.action.contains("VENTA")||it.action.contains("RENOVACIÓN")};val income=sales.sumOf{it.amount};val costEntries=(s.filter{it.account.isNotBlank()}.map{it.account to it.accountCost}+stock.filter{it.account.isNotBlank()}.map{it.account to it.accountCost});val costs=costEntries.groupBy{it.first}.values.sumOf{rows->rows.maxOfOrNull{it.second}?:0};val profit=income-costs;val active=s.count{it.status=="ACTIVO"&&days(it)>=0};val expired=s.count{it.status!="CORTADO"&&days(it)<0};val renewals=h.count{it.action.contains("RENOVACIÓN")};val exits=h.count{it.action.contains("BAJA")};val decisions=renewals+exits;val renewalRate=if(decisions>0)(renewals*100/decisions) else 0;val availableStock=stock.count{effectiveStockStatus(it)=="DISPONIBLE"}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Reportes","Dinero, cartera y actividad del negocio")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){MetricCard("Ingresos",money(income),StreamCyan,Modifier.weight(1f));MetricCard("Utilidad",money(profit),if(profit>=0)StreamGreen else StreamRed,Modifier.weight(1f))}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){MetricCard("Activos",active.toString(),StreamGreen,Modifier.weight(1f));MetricCard("Vencidos",expired.toString(),if(expired>0)StreamRed else StreamGreen,Modifier.weight(1f))}}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Resumen financiero",fontWeight=FontWeight.Bold);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Costo de cuentas");Text(money(costs),fontWeight=FontWeight.SemiBold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Renovaciones registradas");Text(renewals.toString(),fontWeight=FontWeight.SemiBold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Tasa de renovación");Text("$renewalRate%",fontWeight=FontWeight.SemiBold,color=if(renewalRate>=70)StreamGreen else StreamAmber)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Bajas registradas");Text(exits.toString(),fontWeight=FontWeight.SemiBold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Stock disponible");Text(availableStock.toString(),fontWeight=FontWeight.SemiBold)}}}}
  item{SectionTitle("Actividad reciente","Ventas, renovaciones, ajustes y cambios")}
  if(h.isEmpty())item{EmptyState("Aún no hay movimientos registrados.")}
  items(h.sortedByDescending{it.id}.take(100)){x->val n=s.find{it.id==x.subId}?.client?:"Cliente";ActivityRow(x,n)}
 }
}
@Composable fun ActivityRow(x:Hist,client:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.42f))){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(client,fontWeight=FontWeight.SemiBold);Text(x.action,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(x.date,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};if(x.amount>0)Text(money(x.amount),fontWeight=FontWeight.Bold,color=StreamGreen)}}}

@Composable fun More(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,services:List<ServiceTemplate>,setServices:(List<ServiceTemplate>)->Unit,dark:Boolean,setDark:(Boolean)->Unit,t:Templates,setT:(Templates)->Unit,st:Store,reload:()->Unit){
 var edit by remember{mutableStateOf(false)};var incident by remember{mutableStateOf(false)};var serviceDialog by remember{mutableStateOf(false)};var filter by remember{mutableStateOf("Todos")};var query by remember{mutableStateOf("")};val c=LocalContext.current;var backupMsg by remember{mutableStateOf("")}
 val createBackup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null)runCatching{c.contentResolver.openOutputStream(u)?.bufferedWriter()?.use{it.write(st.backup())};backupMsg="Respaldo guardado correctamente"}.onFailure{backupMsg="No se pudo guardar el respaldo"}}
 val openBackup=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)runCatching{val txt=c.contentResolver.openInputStream(u)?.bufferedReader()?.use{it.readText()}?:"";if(st.restore(txt)){reload();backupMsg="Respaldo restaurado correctamente"}else backupMsg="Archivo no compatible"}}
 val chooseFolder=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()){u->if(u!=null){backupMsg=if(st.setBackupFolder(u))"Carpeta automática configurada" else "No se pudo configurar la carpeta"}}
 val filtered=h.sortedByDescending{it.id}.filter{x->val client=s.find{it.id==x.subId}?.client?:"Cliente";client.contains(query,true)&&(filter=="Todos"||x.action.contains(filter,true))};val providerNames=(s.map{it.provider}+stock.map{it.provider}).filter{it.isNotBlank()}.distinct().sorted();val clients=s.groupBy{it.client}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Más","Negocio, automatización y configuración")};item{SectionTitle("Negocio")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Plantillas de servicios",fontWeight=FontWeight.Bold);StatusBadge(services.size.toString(),StreamPurple)};Text("Guarda duración, precio y proveedor para registrar stock y ventas más rápido.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton({serviceDialog=true},Modifier.fillMaxWidth()){Text("Administrar plantillas")}
   HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Proveedores",fontWeight=FontWeight.Bold);StatusBadge(providerNames.size.toString(),StreamCyan)};providerNames.take(8).forEach{name->val accountCount=(s.filter{it.provider==name}.map{it.account}+stock.filter{it.provider==name}.map{it.account}).filter{it.isNotBlank()}.distinct().size;Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(name);Text("$accountCount cuenta${if(accountCount==1)"" else "s"}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}};OutlinedButton({incident=true},Modifier.fillMaxWidth()){Text("Registrar incidencia de cuenta")}
   HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Clientes",fontWeight=FontWeight.Bold);StatusBadge(clients.size.toString(),StreamGreen)}
  }}}
  item{SectionTitle("Actividad","Memoria comercial del negocio")};item{OutlinedTextField(query,{query=it},label={Text("Buscar cliente")},singleLine=true,modifier=Modifier.fillMaxWidth())};item{LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Todos","VENTA","RENOVACIÓN","AJUSTE","BAJA")){x->FilterChip(selected=filter==x,onClick={filter=x},label={Text(x.lowercase().replaceFirstChar{it.uppercase()})})}}};if(filtered.isEmpty())item{EmptyState("Sin actividad para este filtro.")};items(filtered.take(30)){x->ActivityRow(x,s.find{it.id==x.subId}?.client?:"Cliente")}
  item{SectionTitle("Aplicación")};item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Modo oscuro",fontWeight=FontWeight.SemiBold);Text("Apariencia de la aplicación",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(dark,setDark)};OutlinedButton({edit=true},Modifier.fillMaxWidth()){Text("Editar mensajes automáticos")};Text("v6.4 • preparada para Google Play (API 36)",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
  item{SectionTitle("Copia de seguridad","Manual y automática en la memoria del teléfono")};item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){Button({createBackup.launch("ControlStreaming_Backup_${LocalDate.now()}.nexo")},Modifier.fillMaxWidth()){Text("Crear respaldo local")};OutlinedButton({openBackup.launch(arrayOf("application/octet-stream","application/json","text/plain","*/*"))},Modifier.fillMaxWidth()){Text("Restaurar respaldo")};OutlinedButton({chooseFolder.launch(null)},Modifier.fillMaxWidth()){Text(if(st.backupFolder().isBlank())"Elegir carpeta para respaldo automático" else "Cambiar carpeta automática")};if(st.backupFolder().isNotBlank())Text("Respaldo automático diario activo • se conservan las últimas 7 copias",style=MaterialTheme.typography.bodySmall,color=StreamGreen);if(backupMsg.isNotBlank())Text(backupMsg,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
 }
 if(edit)TemplateDialog(t,{edit=false}){setT(it);edit=false};if(incident)IncidentDialog(s,st,{incident=false},reload);if(serviceDialog)ServiceTemplatesDialog(services,{serviceDialog=false}){setServices(it);serviceDialog=false}
}

@Composable fun IncidentDialog(s:List<Sub>,st:Store,close:()->Unit,reload:()->Unit){var account by remember{mutableStateOf("")};var type by remember{mutableStateOf("Cuenta caída")};var daysBack by remember{mutableStateOf("0")};AlertDialog(onDismissRequest=close,title={Text("⚠️ Incidencia")},text={Column{F("Cuenta / correo afectado",account){account=it};F("Tipo de incidencia",type){type=it};F("Días a reponer a todos (0 si aún no)",daysBack){daysBack=it};Text("Afectados: ${s.count{it.account==account&&it.status!="CORTADO"}}")}},confirmButton={Button({val n=daysBack.toIntOrNull()?:0;val affected=s.filter{it.account==account&&it.status!="CORTADO"};if(n>0)st.save(s.map{x->if(x.account==account&&x.status!="CORTADO")x.copy(end=LocalDate.parse(x.end).plusDays(n.toLong()).toString())else x});val hh=st.hist().toMutableList();affected.forEach{x->hh.add(Hist(subId=x.id,date=LocalDate.now().toString(),action="INCIDENCIA • $type • ${if(n>0)"REPOSICIÓN +$n DÍAS" else "ABIERTA"}"))};st.saveHist(hh);reload();close()},enabled=account.isNotBlank()){Text("Guardar incidencia")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun TemplateDialog(t:Templates,close:()->Unit,save:(Templates)->Unit){var a by remember{mutableStateOf(t.due3)};var b by remember{mutableStateOf(t.due1)};var c by remember{mutableStateOf(t.due0)};var d by remember{mutableStateOf(t.expired)};var e by remember{mutableStateOf(t.delivery)};AlertDialog(onDismissRequest=close,title={Text("Mensajes configurables")},text={LazyColumn{item{F("Vence en 3 días",a){a=it}};item{F("Vence mañana",b){b=it}};item{F("Vence hoy",c){c=it}};item{F("Vencido",d){d=it}};item{F("Entrega",e){e=it}}}},confirmButton={Button({save(Templates(a,b,c,d,e))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun RestoreDialog(close:()->Unit,restore:(String)->Unit){var text by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Restaurar respaldo")},text={Column{Text("Pega aquí el respaldo JSON exportado desde Nexo.");OutlinedTextField(text,{text=it},modifier=Modifier.fillMaxWidth().height(180.dp))}},confirmButton={Button({restore(text)},enabled=text.isNotBlank()){Text("Restaurar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun AddDialog(services:List<ServiceTemplate>,close:()->Unit,save:(Sub)->Unit){
 var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var profile by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var method by remember{mutableStateOf("Nequi")};var type by remember{mutableStateOf("CUENTA COMPLETA")};var start by remember{mutableStateOf(LocalDate.now().toString())};var duration by remember{mutableStateOf("30")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var accountEnd by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 fun applyTemplate(t:ServiceTemplate){service=t.name;type=t.type;duration=t.durationDays.toString();price=if(t.defaultPrice>0)t.defaultPrice.toString() else "";provider=t.provider;providerPhone=t.providerPhone;cost=t.accountCost.toString();renewCost=t.renewCost.toString()}
 AlertDialog(onDismissRequest=close,title={Text("Nueva entrega de streaming")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){
  if(services.isNotEmpty())item{Column{Text("PLANTILLAS RÁPIDAS",fontWeight=FontWeight.Bold);LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(services){t->AssistChip(onClick={applyTemplate(t)},label={Text(t.name)})}}}}
  item{Text("Para ahorrar más tiempo, usa Cuentas → Stock disponible cuando el acceso ya esté cargado.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{F("Cliente",client){client=it}};item{F("WhatsApp (57...)",phone){phone=it}};item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};if(type!="CUENTA COMPLETA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave",pin){pin=it}}};item{F("Tipo de entrega",type){type=it}};item{F("Precio cobrado",price){price=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Método de pago",method){method=it}};item{F("Duración en días",duration){duration=it}};item{Text("DATOS DEL PROVEEDOR",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Vence cuenta completa AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}};item{F("Inicio cliente AAAA-MM-DD",start){start=it}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&runCatching{LocalDate.parse(start)}.isSuccess,onClick={val d=LocalDate.parse(start);val n=duration.toLongOrNull()?.coerceAtLeast(1L)?:30L;save(Sub(client=client,phone=phone,service=service,account=account,profile=if(type=="CUENTA COMPLETA")"" else profile,pin=if(type=="CUENTA COMPLETA")"" else pin,type=normalizedAccessType(type,profile),password=password,price=price.filter{it.isDigit()}.toLongOrNull()?:0,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,paymentMethod=method,start=d.toString(),end=d.plusDays(n).toString(),provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0))}){Text("Guardar y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun EndServiceDialog(s:Sub,close:()->Unit,confirm:(String)->Unit){
 var reason by remember(s.id){mutableStateOf("No renovó")}
 AlertDialog(onDismissRequest=close,title={Text("Finalizar servicio")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("${s.client} • ${s.service}",fontWeight=FontWeight.Bold);Text("${s.profile} quedará disponible para otro cliente. El cliente, pagos y actividad se conservarán.")
  Text("Motivo",fontWeight=FontWeight.Bold);listOf("No renovó","Cliente canceló","Cambio de servicio","Problema con la cuenta","Otro").forEach{x->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=reason==x,onClick={reason=x});Text(x)}}
 }},confirmButton={Button(onClick={confirm(reason)}){Text("Finalizar servicio")}},dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}

@Composable fun PromiseDialog(s:Sub,close:()->Unit,save:(String)->Unit){var date by remember(s.id){mutableStateOf(LocalDate.now().plusDays(1).toString())};AlertDialog(onDismissRequest=close,title={Text("Dar plazo")},text={Column{Text("Registra cuándo prometió pagar. No modifica el vencimiento real del servicio.");F("Fecha promesa AAAA-MM-DD",date){date=it};Row{listOf(1L,2L,3L).forEach{n->TextButton({date=LocalDate.now().plusDays(n).toString()}){Text("+$n día")}}}}},confirmButton={Button({save(date)},enabled=runCatching{LocalDate.parse(date)}.isSuccess){Text("Guardar plazo")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun AdjustEndDialog(s:Sub,close:()->Unit,save:(String,String)->Unit){
 var date by remember(s.id){mutableStateOf(s.end)}
 var reason by remember(s.id){mutableStateOf("")}
 fun addDays(n:Long){date=runCatching{LocalDate.parse(date).plusDays(n).toString()}.getOrDefault(s.end)}
 AlertDialog(
  onDismissRequest=close,
  title={Text("Ajustar vencimiento")},
  text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text("${s.client} • ${s.service}")
   Text("Vencimiento actual: ${s.end}")
   OutlinedTextField(value=date,onValueChange={date=it},label={Text("Nueva fecha AAAA-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
   Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1L,3L,5L,7L).forEach{n->OutlinedButton(onClick={addDays(n)},contentPadding=PaddingValues(horizontal=8.dp,vertical=6.dp)){Text("+$n")}}}
   OutlinedTextField(value=reason,onValueChange={reason=it},label={Text("Motivo (opcional)")},modifier=Modifier.fillMaxWidth())
   Text("Este ajuste no registra una venta ni una renovación pagada.",style=MaterialTheme.typography.bodySmall)
  }},
  confirmButton={Button(onClick={save(date,reason)},enabled=runCatching{LocalDate.parse(date)}.isSuccess){Text("Guardar")}},
  dismissButton={TextButton(onClick=close){Text("Cancelar")}}
 )
}

@Composable fun EditSubDialog(s:Sub,close:()->Unit,save:(Sub)->Unit){
 var client by remember(s.id){mutableStateOf(s.client)};var phone by remember(s.id){mutableStateOf(s.phone)};var service by remember(s.id){mutableStateOf(s.service)};var account by remember(s.id){mutableStateOf(s.account)};var password by remember(s.id){mutableStateOf(s.password)};var profile by remember(s.id){mutableStateOf(s.profile)};var pin by remember(s.id){mutableStateOf(s.pin)};var type by remember(s.id){mutableStateOf(s.type)};var price by remember(s.id){mutableStateOf(s.price.toString())};var cost by remember(s.id){mutableStateOf(s.accountCost.toString())};var method by remember(s.id){mutableStateOf(s.paymentMethod)};var start by remember(s.id){mutableStateOf(s.start)};var end by remember(s.id){mutableStateOf(s.end)};var provider by remember(s.id){mutableStateOf(s.provider)};var providerPhone by remember(s.id){mutableStateOf(s.providerPhone)};var accountEnd by remember(s.id){mutableStateOf(s.accountEnd)};var renewCost by remember(s.id){mutableStateOf(s.accountRenewCost.toString())}
 AlertDialog(onDismissRequest=close,title={Text("Editar entrega / cuenta")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){
  item{Text("DATOS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{F("Cliente",client){client=it}};item{F("WhatsApp",phone){phone=it}};item{F("Servicio",service){service=it}}
  item{Text("CREDENCIALES",fontWeight=FontWeight.Bold)};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};item{F("Perfil / pantalla (opcional)",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}};item{F("Tipo de entrega",type){type=it}}
  item{Text("FECHAS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{F("Inicio AAAA-MM-DD",start){start=it}};item{F("Vence AAAA-MM-DD",end){end=it}}
  item{Text("VENTA",fontWeight=FontWeight.Bold)};item{F("Precio cobrado",price){price=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Método de pago",method){method=it}}
  item{Text("PROVEEDOR / CUENTA COMPLETA",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Vencimiento de cuenta AAAA-MM-DD",accountEnd){accountEnd=it}};item{F("Costo de renovar cuenta",renewCost){renewCost=it}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&runCatching{LocalDate.parse(start);LocalDate.parse(end)}.isSuccess,onClick={save(s.copy(client=client,phone=phone,service=service,account=account,password=password,profile=profile,pin=pin,type=type,price=price.filter{it.isDigit()}.toLongOrNull()?:0,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,paymentMethod=method,start=start,end=end,provider=provider,providerPhone=providerPhone,accountEnd=accountEnd,accountRenewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0))}){Text("Guardar cambios")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun QuickCollectionDialog(queue:List<Sub>,close:()->Unit,send:(Sub)->Unit,contact:(Sub)->Unit,renew:(Sub)->Unit){
 var index by remember{mutableIntStateOf(0)};if(queue.isEmpty()){close();return};val current=queue[index.coerceAtMost(queue.lastIndex)]
 AlertDialog(onDismissRequest=close,title={Text("Cobranza rápida ${index+1}/${queue.size}")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text(current.client,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text("${current.service} • vence ${current.end}");Text(money(current.price),style=MaterialTheme.typography.titleLarge,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold);if(current.lastContact.isNotBlank())Text("Último contacto: ${current.lastContact}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Button({send(current);contact(current);if(index<queue.lastIndex)index++ else close()},Modifier.fillMaxWidth()){Text("WhatsApp y siguiente")};OutlinedButton({renew(current);if(index<queue.lastIndex)index++ else close()},Modifier.fillMaxWidth()){Text("Renovó +30 y siguiente")}}},confirmButton={if(index<queue.lastIndex)TextButton({index++}){Text("Omitir")}},dismissButton={TextButton(close){Text("Salir")}})
}

@Composable fun GlobalSearchDialog(s:List<Sub>,stock:List<StockItem>,templates:Templates,close:()->Unit,credentials:(Sub)->Unit,edit:(Sub)->Unit){
 var q by remember{mutableStateOf("")};val terms=q.trim();val clients=if(terms.length<2)emptyList() else s.filter{listOf(it.client,it.phone,it.service,it.account,it.profile,it.provider).any{x->x.contains(terms,true)}}.take(12);val items=if(terms.length<2)emptyList() else stock.filter{listOf(it.service,it.account,it.profile,it.provider).any{x->x.contains(terms,true)}}.take(12)
 AlertDialog(onDismissRequest=close,title={Text("Búsqueda global")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){item{OutlinedTextField(q,{q=it},label={Text("Cliente, correo, servicio, teléfono…")},singleLine=true,modifier=Modifier.fillMaxWidth())};if(terms.length<2)item{Text("Escribe al menos 2 caracteres.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};if(clients.isNotEmpty())item{Text("CLIENTES / ENTREGAS",fontWeight=FontWeight.Bold)};items(clients){x->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text(x.client,fontWeight=FontWeight.Bold);Text("${x.service} • ${x.account}",style=MaterialTheme.typography.bodySmall);Row{TextButton({credentials(x)}){Text("Credenciales")};TextButton({edit(x)}){Text("Editar")}}}}};if(items.isNotEmpty())item{Text("STOCK",fontWeight=FontWeight.Bold)};items(items){x->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text(x.service,fontWeight=FontWeight.Bold);Text(x.account,style=MaterialTheme.typography.bodySmall);Text("${if(isComplete(x))"Cuenta completa" else x.profile} • ${effectiveStockStatus(x)}",style=MaterialTheme.typography.labelSmall)}}}}},confirmButton={TextButton(close){Text("Cerrar")}})
}

@Composable fun ServiceTemplatesDialog(initial:List<ServiceTemplate>,close:()->Unit,save:(List<ServiceTemplate>)->Unit){
 var list by remember{mutableStateOf(initial)};var editId by remember{mutableStateOf<Long?>(null)};var name by remember{mutableStateOf("")};var type by remember{mutableStateOf("CUENTA COMPLETA")};var duration by remember{mutableStateOf("30")};var price by remember{mutableStateOf("")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 fun clear(){editId=null;name="";type="CUENTA COMPLETA";duration="30";price="";provider="";providerPhone="";cost="";renewCost=""}
 fun load(t:ServiceTemplate){editId=t.id;name=t.name;type=t.type;duration=t.durationDays.toString();price=t.defaultPrice.toString();provider=t.provider;providerPhone=t.providerPhone;cost=t.accountCost.toString();renewCost=t.renewCost.toString()}
 AlertDialog(onDismissRequest=close,title={Text("Plantillas de servicios")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){item{Text("Una plantilla completa automáticamente duración, precio y proveedor al crear stock o una venta.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{F("Servicio",name){name=it}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(type=="CUENTA COMPLETA",{type="CUENTA COMPLETA"},{Text("Cuenta completa")},modifier=Modifier.weight(1f));FilterChip(type=="PERFIL/PANTALLA",{type="PERFIL/PANTALLA"},{Text("Perfil")},modifier=Modifier.weight(1f))}};item{F("Duración (días)",duration){duration=it}};item{F("Precio habitual",price){price=it}};item{F("Proveedor habitual",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Costo de cuenta",cost){cost=it}};item{F("Costo de renovar",renewCost){renewCost=it}};item{Button({val item=ServiceTemplate(id=editId?:System.currentTimeMillis(),name=name,type=type,durationDays=duration.toIntOrNull()?.coerceAtLeast(1)?:30,defaultPrice=price.filter{it.isDigit()}.toLongOrNull()?:0,provider=provider,providerPhone=providerPhone,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,renewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0);list=if(editId==null)list+item else list.map{if(it.id==item.id)item else it};clear()},enabled=name.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text(if(editId==null)"Agregar plantilla" else "Guardar cambios")}};if(list.isNotEmpty())item{Text("GUARDADAS",fontWeight=FontWeight.Bold)};items(list){t->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(9.dp)){Text(t.name,fontWeight=FontWeight.Bold);Text("${if(t.type=="CUENTA COMPLETA")"Cuenta completa" else "Perfil"} • ${t.durationDays} días • ${money(t.defaultPrice)}",style=MaterialTheme.typography.bodySmall);Row{TextButton({load(t)}){Text("Editar")};TextButton({list=list.filterNot{it.id==t.id}}){Text("Eliminar")}}}}}}},confirmButton={Button({save(list)}){Text("Guardar todo")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun F(l:String,v:String,c:(String)->Unit){OutlinedTextField(v,c,label={Text(l)},singleLine=false,modifier=Modifier.fillMaxWidth())}

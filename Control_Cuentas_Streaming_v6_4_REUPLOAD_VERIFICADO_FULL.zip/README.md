# Control de Cuentas Streaming v6.4

Versión enfocada en operación rápida, control correcto de inventario y preparación para distribución comercial en Google Play.

## Cambios principales

- Separa correctamente **Cuenta completa** y **Perfil/Pantalla**.
- El panel ya no usa “Sin espacio” para cuentas completas entregadas.
- Stock con cuentas completas disponibles y perfiles disponibles por separado.
- Venta rápida desde stock: reutiliza credenciales, proveedor y costos.
- Plantillas de servicios: duración, precio habitual, tipo, proveedor y costos.
- Centro de trabajo diario: vencimientos, promesas de pago, cuentas de proveedor y servicios sin stock.
- Cobranza rápida secuencial desde Renovaciones.
- Búsqueda global por cliente, teléfono, servicio, correo, perfil o proveedor.
- Estados automatizados: al finalizar servicio el acceso vuelve a Stock; si no existía en Stock, se crea el acceso disponible.
- Última fecha de contacto con el cliente.
- Respaldo automático local: el usuario elige una carpeta y la app conserva las últimas 7 copias automáticas diarias.
- Mantiene respaldo manual y restauración.
- Mantiene datos de versiones anteriores mediante campos opcionales/default.

## Google Play

- `versionName = 6.4`
- `versionCode = 18`
- `compileSdk = 36`
- `targetSdk = 36`
- AGP 8.9.1 / Gradle 8.11.1 / Java 17
- Generación de APK y AAB release.
- Soporta la clave permanente mediante los secrets ya creados.
- Consulta `WORKFLOW_GOOGLE_PLAY_DESDE_ZIP.yml` si compilas desde un ZIP en GitHub.
- Consulta `docs/PLAY_CONSOLE_CHECKLIST.md` antes de publicar.

## Monetización

La primera estrategia recomendada es publicar la app como **aplicación de pago** en Google Play. Esto permite cobrar por descargar/usar la app sin introducir un sistema de licencia local fácil de evadir.

Para cobro mensual recurrente, la siguiente fase debe integrar Google Play Billing y un backend seguro para validar compras y derechos.

package com.nexoestore.autoia

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity: Activity() {
    private lateinit var store: RenewalStore
    private lateinit var body: LinearLayout
    private val bg=0xFF07131D.toInt(); private val card=0xFF102536.toInt()
    private val accent=0xFF00A884.toInt(); private val white=0xFFFFFFFF.toInt()
    private val muted=0xFFC6D0D6.toInt(); private val danger=0xFFB3261E.toInt()
    private val df=SimpleDateFormat("dd/MM/yyyy",Locale.getDefault())

    override fun onCreate(b:Bundle?) {
        super.onCreate(b); store=RenewalStore(this); askPermission(); home()
    }
    private fun askPermission(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),10)
    }
    private fun home(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
        root.addView(TextView(this).apply{
            text="Nexo Renovaciones";textSize=25f;setTextColor(white);typeface=Typeface.DEFAULT_BOLD;setPadding(24,28,24,12)
        })
        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(10,0,10,8)}
        nav.addView(btn("INICIO"){dashboard()},LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(btn("NUEVO"){edit(null)},LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(btn("TODOS"){listAll()},LinearLayout.LayoutParams(0,-2,1f))
        root.addView(nav)
        val scroll=ScrollView(this); body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,8,16,30)}
        scroll.addView(body);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root);dashboard()
    }
    private fun dashboard(){
        body.removeAllViews()
        val items=store.all().filter{it.active}.sortedBy{it.expiry}; val now=startToday()
        val expired=items.count{it.expiry<now}; val today=items.count{it.expiry in now until now+86400000}
        val soon=items.count{it.expiry in now until now+6*86400000}
        title("Resumen")
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        stats.addView(stat("Hoy",today),LinearLayout.LayoutParams(0,-2,1f))
        stats.addView(stat("5 días",soon),LinearLayout.LayoutParams(0,-2,1f))
        stats.addView(stat("Vencidos",expired),LinearLayout.LayoutParams(0,-2,1f));body.addView(stats)
        title("Prioridad")
        if(items.isEmpty()) body.addView(cardText("Aún no hay servicios","Pulsa NUEVO para registrar la primera renovación."))
        items.filter{it.expiry<now+6*86400000}.take(20).forEach{body.addView(itemCard(it))}
        body.addView(btn("PROBAR NOTIFICACIÓN"){
            val i=Intent(this,ReminderReceiver::class.java).apply{putExtra("customer","Cliente de prueba");putExtra("service","Netflix");putExtra("days",1);putExtra("id","test")}
            sendBroadcast(i);toast("Notificación enviada")
        })
    }
    private fun listAll(){
        body.removeAllViews();title("Todos los servicios")
        val items=store.all().sortedBy{it.expiry}
        if(items.isEmpty()) body.addView(cardText("Sin registros","Crea tu primer servicio."))
        items.forEach{body.addView(itemCard(it))}
    }
    private fun itemCard(r:Renewal):LinearLayout{
        val days=((r.expiry-startToday())/86400000L).toInt()
        val status=when{days<0->"Vencido hace ${-days} día(s)";days==0->"Vence hoy";else->"Vence en $days día(s)"}
        return LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(20,18,20,18);setBackgroundColor(card)
            val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,12);layoutParams=lp
            addView(TextView(this@MainActivity).apply{text="${r.customer} · ${r.service}";textSize=18f;setTextColor(white);typeface=Typeface.DEFAULT_BOLD})
            addView(TextView(this@MainActivity).apply{text="${df.format(Date(r.expiry))} — $status\n${money(r.price)}";setTextColor(if(days<0) 0xFFFF8A80.toInt() else muted);textSize=15f})
            val row=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL}
            row.addView(btn("RENOVAR"){renew(r)},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(btn("WHATSAPP"){whatsapp(r)},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(btn("EDITAR"){edit(r)},LinearLayout.LayoutParams(0,-2,1f));addView(row)
        }
    }
    private fun edit(existing:Renewal?){
        body.removeAllViews();title(if(existing==null)"Nuevo servicio" else "Editar servicio")
        val customer=input("Nombre del cliente",existing?.customer); val phone=input("Teléfono con indicativo",existing?.phone)
        val service=input("Servicio (Netflix, Disney+, etc.)",existing?.service)
        val price=input("Valor de renovación",existing?.price?.toLong()?.toString(),true)
        val date=input("Fecha de vencimiento DD/MM/AAAA",existing?.let{df.format(Date(it.expiry))})
        val notes=input("Notas",existing?.notes)
        listOf(customer,phone,service,price,date,notes).forEach{body.addView(it)}
        body.addView(btn("GUARDAR"){
            try{
                val d=df.parse(date.text.toString().trim()) ?: error("fecha")
                if(customer.text.isBlank()||service.text.isBlank()) error("datos")
                val r=existing?.copy()?:Renewal(customer=customer.text.toString(),phone=phone.text.toString(),service=service.text.toString(),price=0.0,expiry=d.time)
                r.customer=customer.text.toString().trim();r.phone=phone.text.toString().trim();r.service=service.text.toString().trim()
                r.price=price.text.toString().replace(",",".").toDoubleOrNull()?:0.0;r.expiry=d.time;r.notes=notes.text.toString()
                store.upsert(r);toast("Guardado y alertas programadas");dashboard()
            }catch(e:Exception){toast("Revisa nombre, servicio y fecha")}
        })
        if(existing!=null) body.addView(redBtn("ELIMINAR"){store.delete(existing.id);toast("Eliminado");dashboard()})
    }
    private fun renew(r:Renewal){
        val cal=Calendar.getInstance().apply{timeInMillis=maxOf(r.expiry,System.currentTimeMillis());add(Calendar.MONTH,1)}
        AlertDialog.Builder(this).setTitle("Renovar ${r.service}")
            .setMessage("Nueva fecha sugerida: ${df.format(cal.time)}")
            .setPositiveButton("Confirmar"){_,_->r.expiry=cal.timeInMillis;store.upsert(r);toast("Renovación registrada");dashboard()}
            .setNegativeButton("Cancelar",null).show()
    }
    private fun whatsapp(r:Renewal){
        val msg="Hola ${r.customer} 👋 Te recordamos que tu servicio de ${r.service} vence el ${df.format(Date(r.expiry))}. El valor de renovación es ${money(r.price)}. ¿Deseas renovarlo?"
        val phone=r.phone.filter{it.isDigit()}
        startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/$phone?text=${Uri.encode(msg)}")))
    }
    private fun input(h:String,v:String?=null,number:Boolean=false)=EditText(this).apply{
        hint=h;setText(v?:"");setTextColor(white);setHintTextColor(muted);textSize=16f;setPadding(16,14,16,14)
        if(number) inputType=2 or 8192
    }
    private fun title(t:String){body.addView(TextView(this).apply{text=t;textSize=21f;setTextColor(white);typeface=Typeface.DEFAULT_BOLD;setPadding(4,12,4,14)})}
    private fun stat(t:String,n:Int)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(8,18,8,18);setBackgroundColor(card)
        addView(TextView(this@MainActivity).apply{text=n.toString();textSize=25f;setTextColor(white);typeface=Typeface.DEFAULT_BOLD})
        addView(TextView(this@MainActivity).apply{text=t;setTextColor(muted)})}
    private fun cardText(a:String,b:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,20);setBackgroundColor(card)
        addView(TextView(this@MainActivity).apply{text=a;textSize=18f;setTextColor(white);typeface=Typeface.DEFAULT_BOLD})
        addView(TextView(this@MainActivity).apply{text=b;setTextColor(muted)})}
    private fun btn(t:String,fn:()->Unit)=Button(this).apply{text=t;setTextColor(white);setBackgroundColor(accent);setOnClickListener{fn()}}
    private fun redBtn(t:String,fn:()->Unit)=Button(this).apply{text=t;setTextColor(white);setBackgroundColor(danger);setOnClickListener{fn()}}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun startToday():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
    private fun money(v:Double)=NumberFormat.getCurrencyInstance(Locale("es","CO")).format(v)
}

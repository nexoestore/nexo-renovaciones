# Control de Cuentas Streaming v7.7 — Notificaciones inteligentes y gestión compacta

Actualización sobre el proyecto Android v7.6 entregado por el usuario.

## Qué cambia

- Las alarmas antiguas se cancelan cuando cambian las fechas o los estados, y los **avisos ya visibles** se retiran cuando dejan de ser válidos.
- El receptor vuelve a comprobar los datos actuales antes de publicar, evitando que alarmas antiguas reaviven recordatorios de ciclos pasados.
- Una cuenta de proveedor marcada como «No renovar» deja de generar avisos para ese vencimiento. Esa decisión se incluye en los nuevos respaldos cifrados.
- Inicio y Renovaciones tienen tarjetas compactas que se expanden al tocarlas. La nueva venta está en el encabezado y no tapa las acciones.
- Al tocar el aviso del cliente se abre Renovaciones, con una acción adicional para WhatsApp si se guardó teléfono.
- Se conservan paquete, Room, protección de datos, inventario, reportes y módulos previos.

## Versión e instalación

- `applicationId`: `com.nexo.suscripciones`
- `versionCode`: `38` — `versionName`: `7.7`
- Android mínimo: SDK 26
- Para actualizar una APK ya instalada **es imprescindible compilar con la misma clave de firma que la versión anterior**. No desinstalar la app para forzar una instalación: eso puede borrar la base de datos.
- Hacer y comprobar una copia de seguridad cifrada antes de probar.

## Compilación desde el teléfono (GitHub)

Usar el mismo repositorio y los secretos de firma de la versión anterior. El workflow `.github/workflows/build-apk.yml` está preparado para tomar un ZIP colocado en el repositorio y compilar el proyecto desde él. Consultar `VALIDACION_v7_7.txt` antes de instalar.

**Estado de validación:** las reglas Kotlin puras compilan y pasaron comprobaciones de elegibilidad; la APK y las pruebas Android/Compose deben ejecutarse en GitHub Actions o en un entorno con SDK Android.

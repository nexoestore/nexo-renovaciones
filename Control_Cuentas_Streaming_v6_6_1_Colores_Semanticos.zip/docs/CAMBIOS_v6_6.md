# v6.6 — Modo simple para distribuidores

## Objetivo
Hacer que la aplicación sea más fácil de entender y operar por revendedores con poca experiencia técnica, manteniendo la potencia de la v6.5.3.

## Cambios visuales
- Identidad Nexo Digital en la barra superior.
- Fondo azul/negro y turquesa/cian como color de marca.
- Rojo: clientes vencidos y problemas.
- Amarillo/naranja: vencen hoy y cuentas de proveedor por vencer.
- Azul: accesos disponibles.
- Verde: ganancia, activo o resultado positivo.

## Operación
- Inicio muestra primero lo urgente.
- Renovaciones tiene chips de estado claramente coloreados.
- `No renovó` abre una confirmación sencilla y libera el acceso.
- Stock usa `Para vender` y `Ya entregadas`.
- Botones más claros: `Vender cuenta` y `Asignar perfil`.
- Proveedores muestra conteo único y vencimientos.
- Reportes reduce métricas técnicas y usa términos cotidianos.

## Compatibilidad
- applicationId: com.nexo.suscripciones
- versionCode: 23
- versionName: 6.6
- API 36
- Compatible con los datos y respaldos anteriores.

# v6.5.1 — Pulido visual y textual

- Cabecera más limpia, sin repetir el flujo comercial.
- Flujo del negocio resumido como Compra → Venta → Entrega → Renovación → Corte → Ganancia.
- Corrección singular/plural en Cobranza rápida.
- “Stock disponible” pasa a “Accesos disponibles”.
- “Proveedor por vencer” pasa a “Cuentas por renovar”.
- Stock renombrado como “Stock para vender y cuentas activas”.
- Ayuda de Stock más corta y directa.
- Pestaña inferior “Proveedores” pasa a “Compras”.
- Pantalla “Compras y proveedores” enfocada en costos y rentabilidad.
- Último contacto mostrado como Hoy/Ayer/día mes.
- Reportes remaquetados para evitar textos pegados o URLs largas.
- URLs de proveedor se muestran con un nombre corto (ej. G2G) sin modificar el dato almacenado.
- Sin cambios en la estructura de datos, applicationId o formato de respaldo.

# Borrador de ficha de Google Play

## Nombre
Control de Cuentas Streaming

## Descripción corta
Controla stock, cuentas, perfiles, proveedores, cobros, renovaciones y rentabilidad desde un solo lugar.

## Descripción completa
Control de Cuentas Streaming es una herramienta administrativa para negocios que compran accesos digitales a proveedores y necesitan controlar inventario, entregas, renovaciones, costos y utilidad.

La aplicación organiza la operación con un flujo fácil de entender:

**Proveedor → Stock → Venta → Entrega → Renovación → Corte → Ganancia**

### Funciones principales

- Panel diario con clientes vencidos, vencimientos de hoy, stock y cuentas del proveedor próximas a vencer.
- Separación clara entre **Cuenta completa** y **Perfil/Pantalla**.
- Stock para vender separado de cuentas que ya están activas.
- Venta rápida desde Stock reutilizando credenciales, proveedor y costos registrados.
- Control de clientes, fechas de inicio y vencimiento y último contacto.
- Renovaciones +30, promesas de pago, ajustes de fecha y finalización del servicio.
- Mensajes de WhatsApp preparados y reenvío de credenciales.
- Control de proveedores, fechas de compra, vencimientos y costos de renovación.
- Indicadores de inversión, ingresos y utilidad por proveedor y por cuenta.
- Reportes de ventas, costos, cartera, utilidad, renovaciones y bajas.
- Plantillas de servicios y búsqueda global.
- Incidencias con reposición de días a clientes afectados.
- Respaldo local manual y automático.
- Tema claro/oscuro.

La información se guarda localmente en el dispositivo. Esta versión no incluye publicidad ni servicios de analítica de terceros.

## Aviso de independencia

Control de Cuentas Streaming es una herramienta administrativa independiente. No está afiliada, patrocinada ni respaldada por plataformas o servicios digitales de terceros. Las marcas de terceros pertenecen a sus respectivos titulares. El usuario es responsable de utilizar la aplicación y gestionar sus operaciones conforme a la legislación aplicable y a los términos de los servicios que administre.

# v6.5.2 — Interfaz enfocada en datos útiles

Esta versión elimina bloques explicativos estáticos que ocupaban espacio sin ayudar a tomar decisiones.

## Eliminado
- “Flujo del negocio” en Inicio.
- “¿Qué ves aquí?” en Stock.
- “Rentabilidad por proveedor” en Compras/Proveedores.
- Banner explicativo redundante de Ajustes.

## Mejorado
- Inicio abre directamente con vencimientos, stock, cobros, ventas, costos y utilidad.
- Stock abre directamente con selector Stock/Cuentas activas y métricas reales.
- Compras/Proveedores agrega métricas globales reales: número de proveedores, cuentas próximas a renovar, inversión y utilidad acumulada.
- Cabeceras más cortas y orientadas a la operación.

## Compatibilidad
- applicationId sin cambios: com.nexo.suscripciones
- versionCode 21
- versionName 6.5.2
- Formato de datos y respaldos conservado.

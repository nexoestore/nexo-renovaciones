# Control de Cuentas Streaming v6.6.1

## Ajuste semántico de colores

Esta versión separa visualmente las alertas para que un distribuidor pueda entender el estado sin leer demasiado:

- Rojo: clientes vencidos / situaciones críticas.
- Amarillo: clientes que vencen hoy.
- Azul: accesos disponibles / stock listo para vender.
- Naranja: cuentas próximas a vencer con el proveedor.
- Verde: activo, disponible, renovado o ganancia positiva.
- Morado: clientes en espera / promesa de pago.
- Gris: vence mañana, para no competir visualmente con las alertas principales.

No cambia el modelo de datos ni el applicationId.

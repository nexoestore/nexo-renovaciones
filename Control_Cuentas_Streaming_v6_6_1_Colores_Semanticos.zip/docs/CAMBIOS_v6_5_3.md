# Control de Cuentas Streaming 6.5.3

## Proveedores únicos y conteo correcto

Esta versión corrige el conteo duplicado de proveedores causado por diferencias de escritura.

Ejemplos que ahora se consideran el mismo proveedor:
- `G2G`
- `g2g`
- `g2g.com`
- `https://www.g2g.com`
- espacios o diferencias de mayúsculas/minúsculas

La corrección se aplica sin borrar cuentas, clientes, stock, pagos ni historial.

### Qué se corrigió
- La tarjeta **Proveedores** cuenta proveedores normalizados, no textos crudos.
- Las cuentas del mismo proveedor se agrupan aunque el nombre antiguo tenga variantes.
- La rentabilidad por proveedor usa el mismo agrupamiento.
- Los costos mensuales no se duplican por variantes del nombre del proveedor.
- Renovar una cuenta desde Compras actualiza las variantes antiguas del mismo proveedor.
- Nuevas compras, ediciones, ventas manuales y plantillas guardan el nombre del proveedor de forma limpia.
- Las URL usadas antiguamente como nombre de proveedor se muestran de forma legible, por ejemplo `https://www.g2g.com` → `G2G`.

## Compatibilidad
- applicationId: `com.nexo.suscripciones`
- versionCode: 22
- versionName: 6.5.3
- Compatible con los datos y respaldos de las versiones anteriores.

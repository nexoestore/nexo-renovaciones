# Pruebas recomendadas — v6.5

Antes de usar la versión con datos reales, crea un respaldo local desde la versión instalada.

## 1. Actualización
- Instalar el APK v6.5 encima de la versión firmada anterior.
- Confirmar que clientes, cuentas, fechas, contraseñas, perfiles, pagos y actividad siguen presentes.

## 2. Cuenta completa
1. Stock → Agregar compra / stock.
2. Elegir Cuenta completa.
3. Registrar proveedor, costo, fecha de compra y vencimiento de proveedor.
4. Confirmar que aparece en Stock para vender como Disponible.
5. Vender desde Stock.
6. Confirmar que desaparece del Stock vendible y aparece en Cuentas activas como Entregada.
7. Finalizar el servicio desde Renovar.
8. Confirmar que vuelve a Stock como Disponible si la cuenta del proveedor sigue vigente.

## 3. Cuenta por perfiles
1. Registrar varios perfiles con el mismo correo/cuenta.
2. Vender un perfil.
3. Confirmar que solo ese perfil pasa a Ocupado y los demás siguen Disponibles.
4. Finalizar ese cliente y confirmar que el perfil vuelve a Disponible.

## 4. Proveedores
- Confirmar que cada cuenta aparece agrupada bajo su proveedor.
- Revisar inversión, ingresos y utilidad acumulada.
- Registrar una renovación de proveedor y comprobar que cambia la fecha de vencimiento y queda un costo en Actividad/Reportes.

## 5. Renovaciones
- Probar Vence hoy, Vencido, Dar plazo, Renovó +30 y No renovó/finalizar.
- Confirmar que Dar plazo no cambia la fecha real del servicio.
- Confirmar que +30 sí cambia la fecha y registra ingreso.

## 6. WhatsApp
- Enviar un mensaje de entrega con Perfil/PIN vacíos y confirmar que esas líneas no aparecen.
- Reenviar credenciales desde una cuenta activa.

## 7. Reportes
- Registrar una venta, una renovación de cliente y una renovación de proveedor.
- Confirmar que las ventas/renovaciones de cliente aparecen como ingresos y los pagos al proveedor como costos.

## 8. Respaldo
- Crear respaldo manual.
- Elegir carpeta para respaldo automático.
- Confirmar que se crea archivo `.nexo`.
- Restaurar una copia de prueba y verificar los datos.

## 9. GitHub / Google Play
- El workflow debe producir `ControlStreaming-v6.5-APK` y `ControlStreaming-v6.5-GooglePlay-AAB`.
- APK: instalar/probar en el teléfono.
- AAB: conservar para Play Console después de completar las pruebas.

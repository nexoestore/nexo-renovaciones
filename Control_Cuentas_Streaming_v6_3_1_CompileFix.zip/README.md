# Control de Cuentas Streaming v6.3 — Stock Operativo

Actualización sobre v6.2 sin cambiar el applicationId (`com.nexo.suscripciones`) ni la base `nexo_db`.

## Cambios principales
- Sección **Stock disponible** dentro de Cuentas.
- Terminología **Cuenta completa** en lugar de “Cuenta maestra”.
- Estados de stock: **Disponible**, **Ocupado** y **No disponible**. No se usa “Reservado”.
- Registro de stock para cuentas completas y perfiles/pantallas.
- Venta/asignación directamente desde Stock: cambia automáticamente de Disponible a Ocupado.
- Al finalizar por **No renovó**, un acceso vendido desde stock vuelve automáticamente a Disponible.
- Una cuenta vencida en proveedor se considera No disponible para venta.
- Edición de credenciales, proveedor, costos y fecha de vencimiento del stock.
- Respaldo local v3 incluye también el stock y sigue restaurando respaldos anteriores sin campo stock.
- Se conserva Centro de Control, Renovaciones, Cuentas, Reportes, Actividad, Proveedores, Incidencias, mensajes, WhatsApp y respaldo local.

## Versión
- versionName: 6.3
- versionCode: 16

La compilación Android final debe confirmarse mediante GitHub Actions.

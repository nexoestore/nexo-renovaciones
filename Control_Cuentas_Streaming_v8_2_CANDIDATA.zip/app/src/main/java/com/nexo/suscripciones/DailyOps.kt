package com.nexo.suscripciones

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Cuenta del proveedor que vence (o ya venció) mientras hay clientes que pagaron más allá de esa fecha. */
data class CoverageAlert(
    val provider:String,
    val account:String,
    val service:String,
    val accountEnd:String,
    val daysToAccountEnd:Long,
    val clients:List<Sub>
) {
    val expired:Boolean get()=daysToAccountEnd<0
    fun whenText():String=when{
        daysToAccountEnd<0L->"venció hace ${-daysToAccountEnd} día${if(daysToAccountEnd==-1L)"" else "s"}"
        daysToAccountEnd==0L->"vence hoy"
        daysToAccountEnd==1L->"vence mañana"
        else->"vence en $daysToAccountEnd días"
    }
}

/** Acceso de un cliente ya cortado cuya contraseña (cuenta completa) o PIN (perfil) aún no se ha cambiado. */
data class PendingRevoke(val stockId:Long,val service:String,val account:String,val profile:String,val isComplete:Boolean,val since:String) {
    fun days(today:LocalDate=LocalDate.now()):Long=OperationRules.parseDate(since)?.let{ChronoUnit.DAYS.between(it,today).coerceAtLeast(0L)}?:0L
    val what:String get()=if(isComplete)"contraseña" else "PIN del perfil"
}

data class DailySummary(
    val overdue:Int,val dueToday:Int,val promisesToday:Int,val dueTomorrow:Int,val upcoming:Int,
    val toCollect:Long,val coverageAlerts:Int,val coverageClients:Int,
    val pendingRevokes:Int=0,val oldestRevokeDays:Long=0L
) {
    val actionable:Int get()=overdue+dueToday+promisesToday
    val isEmpty:Boolean get()=actionable+dueTomorrow+upcoming+coverageAlerts+pendingRevokes==0
}

/** Reglas del resumen diario y de la alerta de cobertura. Sin dependencias de Android: se prueban con JUnit puro. */
object DailyOps {
    private fun key(provider:String,account:String)="${provider.trim().lowercase()}|${account.trim().lowercase()}"

    /**
     * Una cuenta genera alerta si vence en [windowDays] días o menos (o ya venció) y tiene clientes activos cuyo
     * vencimiento es POSTERIOR al de la cuenta: pagaron un periodo que el proveedor ya no cubrirá.
     * Funciona también para cuentas «de un solo ciclo», que no generan avisos de renovación al proveedor.
     */
    fun coverageAlerts(subs:List<Sub>,today:LocalDate=LocalDate.now(),windowDays:Long=3):List<CoverageAlert> =
        subs.filter{!it.status.equals("CORTADO",true)&&it.account.isNotBlank()}
            .groupBy{key(it.provider,it.account)}
            .mapNotNull{(_,list)->
                val end=list.mapNotNull{OperationRules.parseDate(it.accountEnd)}.maxOrNull()?:return@mapNotNull null
                val days=ChronoUnit.DAYS.between(today,end)
                if(days>windowDays)return@mapNotNull null
                val exposed=list.filter{c->OperationRules.parseDate(c.end)?.isAfter(end)==true}
                if(exposed.isEmpty())null
                else CoverageAlert(list.first().provider,list.first().account,list.first().service,end.toString(),days,exposed.sortedBy{it.end})
            }.sortedBy{it.daysToAccountEnd}

    /** Accesos de stock con marca de «cambiar contraseña/PIN» pendiente, del más antiguo al más reciente. */
    fun pendingRevokes(stock:List<StockItem>,marks:Map<Long,String>,isComplete:(StockItem)->Boolean):List<PendingRevoke> =
        stock.filter{it.id in marks}.map{PendingRevoke(it.id,it.service,it.account,it.profile,isComplete(it),marks.getValue(it.id))}.sortedBy{it.since}

    fun summary(subs:List<Sub>,today:LocalDate=LocalDate.now(),pending:List<PendingRevoke> = emptyList()):DailySummary {
        var overdue=0;var dueToday=0;var promises=0;var tomorrow=0;var upcoming=0;var toCollect=0L
        subs.forEach{s->
            when(BusinessStateEngine.client(s,today).state){
                ClientOperationState.OVERDUE->{overdue++;toCollect+=s.price}
                ClientOperationState.DUE_TODAY->{dueToday++;toCollect+=s.price}
                ClientOperationState.PROMISE_DUE->{promises++;toCollect+=s.price}
                ClientOperationState.DUE_TOMORROW->tomorrow++
                ClientOperationState.UPCOMING_2_3->upcoming++
                else->Unit
            }
        }
        val alerts=coverageAlerts(subs,today)
        return DailySummary(overdue,dueToday,promises,tomorrow,upcoming,toCollect,alerts.size,alerts.sumOf{it.clients.size},pending.size,pending.maxOfOrNull{it.days(today)}?:0L)
    }

    private fun plural(n:Int,one:String,many:String)="$n ${if(n==1)one else many}"

    /** Título y cuerpo de la notificación, o null si no hay nada que avisar. */
    fun notificationText(s:DailySummary,alerts:List<CoverageAlert>):Pair<String,String>? {
        if(s.isEmpty)return null
        val title=when{
            s.actionable>0->"☀️ Hoy: ${plural(s.actionable,"cobro pendiente","cobros pendientes")} · ${money(s.toCollect)}"
            s.coverageAlerts>0->"⚠️ ${plural(s.coverageAlerts,"cuenta por vencer con clientes","cuentas por vencer con clientes")}"
            s.pendingRevokes>0->"🔐 ${plural(s.pendingRevokes,"acceso sin cambiar contraseña","accesos sin cambiar contraseña")}"
            else->"📅 Próximos vencimientos"
        }
        val lines=mutableListOf<String>()
        val parts=mutableListOf<String>()
        if(s.overdue>0)parts+=plural(s.overdue,"vencido","vencidos")
        if(s.dueToday>0)parts+="${s.dueToday} vence${if(s.dueToday==1)"" else "n"} hoy"
        if(s.promisesToday>0)parts+=plural(s.promisesToday,"promesa de pago","promesas de pago")
        if(s.dueTomorrow>0)parts+="${s.dueTomorrow} mañana"
        if(s.upcoming>0)parts+="${s.upcoming} en 2–3 días"
        if(parts.isNotEmpty())lines+=parts.joinToString(" • ")
        if(s.pendingRevokes>0)lines+="🔐 ${plural(s.pendingRevokes,"acceso cortado","accesos cortados")} con la clave sin cambiar"+(if(s.oldestRevokeDays>0)" (el más antiguo: ${s.oldestRevokeDays} día${if(s.oldestRevokeDays==1L)"" else "s"})" else "")
        if(s.coverageAlerts>0&&s.actionable>0)lines+="⚠️ ${plural(s.coverageAlerts,"cuenta por vencer con clientes","cuentas por vencer con clientes")}"
        alerts.take(3).forEach{a->lines+="• ${a.service} ${a.whenText()}: ${plural(a.clients.size,"cliente expuesto","clientes expuestos")}"}
        return title to lines.joinToString("\n")
    }
}

package com.nexo.suscripciones

data class BackupFile(val name:String,val id:String,val size:Long)

/**
 * Política de retención de copias automáticas: la copia más reciente de cada uno de los últimos [keepDays] días.
 * Los archivos vacíos (size == 0) nunca cuentan como copia válida y siempre se eliminan.
 * Archivos con otros nombres (copias manuales, PreRestore) no se tocan.
 */
object BackupRetention {
    const val AUTO_PREFIX="ControlStreaming_Auto_"

    fun toDelete(files:List<BackupFile>,keepDays:Int=7):List<BackupFile>{
        val auto=files.filter{it.name.startsWith(AUTO_PREFIX)}
        val keep=auto.filter{it.size!=0L}
            .groupBy{it.name.removePrefix(AUTO_PREFIX).take(10)}
            .entries.sortedByDescending{it.key}.take(keepDays)
            .map{e->e.value.maxByOrNull{it.name}!!.id}.toSet()
        return auto.filter{it.id !in keep}
    }
}

package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test

class AuditFixesV79Test {
    private fun sub(price:Long=500,password:String="clave",pin:String="1234") = Sub(
        id=1,client="Ana",phone="3001234567",service="Disney",account="a@b.com",profile="P1",
        type="PERFIL/PANTALLA",price=price,start="2026-10-01",end="2026-11-01",password=password,pin=pin
    )

    // ---- Doble símbolo de moneda ($$) en mensajes al cliente ----
    @Test fun default_templates_do_not_double_the_currency_symbol() {
        val t=Templates()
        val msg=fillTemplate(t.due3,sub(500))
        assertTrue(msg,msg.contains("$500"))
        assertFalse(msg,msg.contains("$$"))
    }

    @Test fun legacy_saved_templates_with_dollar_prefix_are_also_fixed() {
        val legacy="Valor: "+"$"+"{precio}."
        val msg=fillTemplate(legacy,sub(500))
        assertEquals("Valor: $500.",msg)
    }

    // ---- Sustitución en un solo paso ----
    @Test fun placeholder_inside_a_value_is_not_substituted_again() {
        val s=sub(password="{pin}")
        val msg=fillTemplate("Clave: {password}\nPIN: {pin}",s)
        assertTrue(msg,msg.contains("Clave: {pin}"))
        assertTrue(msg,msg.contains("PIN: 1234"))
    }

    @Test fun unreadable_credentials_are_never_sent_to_the_customer() {
        val s=sub(password="enc1:AAAA:BBBB",pin="enc1:CCCC:DDDD")
        val msg=fillTemplate("Cuenta: {cuenta}\nContraseña: {password}\nPIN: {pin}",s)
        assertFalse(msg,msg.contains("enc1"))
        assertFalse(msg,msg.contains("Contraseña"))
        assertTrue(msg,msg.contains("Cuenta: a@b.com"))
    }

    // ---- Retención de copias automáticas ----
    private fun f(date:String,ms:Long,size:Long=100L)=BackupFile("ControlStreaming_Auto_${date}_$ms.nexo","id-$date-$ms",size)

    @Test fun keeps_latest_backup_of_each_of_last_seven_days() {
        // 10 copias el mismo día + una por cada día anterior: antes, las 7 más recientes eran todas de hoy.
        val today=(1..10).map{f("2026-10-30",1000L+it)}
        val previous=(20..29).map{f("2026-10-$it",it.toLong())}
        val delete=BackupRetention.toDelete(today+previous).map{it.id}.toSet()
        val kept=(today+previous).map{it.id}.filter{it !in delete}
        assertEquals(7,kept.size)
        assertTrue(kept.contains("id-2026-10-30-1010"))          // la más reciente de hoy
        assertFalse(kept.contains("id-2026-10-30-1001"))         // las demás de hoy se eliminan
        assertTrue(kept.contains("id-2026-10-29-29"))            // ayer se conserva
        assertTrue(kept.contains("id-2026-10-24-24"))            // 6 días atrás se conserva
        assertFalse(kept.contains("id-2026-10-23-23"))           // más antigua que 7 días
    }

    @Test fun empty_backup_file_is_never_kept_and_never_replaces_a_valid_one() {
        val good=f("2026-10-30",1000L)
        val empty=f("2026-10-30",2000L,size=0L)
        val delete=BackupRetention.toDelete(listOf(good,empty)).map{it.id}
        assertTrue(delete.contains(empty.id))
        assertFalse(delete.contains(good.id))
    }

    @Test fun unrelated_files_are_not_touched() {
        val manual=BackupFile("ControlStreaming_Backup_2026-10-01.nexo","m",100L)
        val pre=BackupFile("ControlStreaming_PreRestore_123.nexo","p",100L)
        assertTrue(BackupRetention.toDelete(listOf(manual,pre)).isEmpty())
    }

    // ---- Ingresos: una compra cuyo proveedor contenga "venta" no es un ingreso ----
    @Test fun purchase_with_venta_in_provider_name_is_not_counted_as_income() {
        val purchase=Hist(id=1,subId=0,date="2026-10-30",action="COMPRA STOCK • VentasTV • Disney • a@b.com",amount=9000)
        val sale=Hist(id=2,subId=1,date="2026-10-30",action="VENTA / PAGO DESDE STOCK",amount=15000)
        val renewal=Hist(id=3,subId=1,date="2026-10-30",action="RENOVACIÓN +30 DÍAS",amount=15000)
        assertFalse(isSaleIncome(purchase))
        assertTrue(isSaleIncome(sale))
        assertTrue(isSaleIncome(renewal))
    }
}

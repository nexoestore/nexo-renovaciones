package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class DailyOpsTest {
    private val today=LocalDate.of(2026,11,3)
    private fun sub(id:Long,end:String,accountEnd:String,account:String="a@b.com",status:String="ACTIVO",price:Long=500,promise:String="") = Sub(
        id=id,client="C$id",phone="300",service="Capcut",account=account,profile="",type="CUENTA COMPLETA",
        price=price,start="2026-10-01",end=end,status=status,provider="G2G",accountEnd=accountEnd,promiseDate=promise)

    @Test fun account_expiring_with_clients_paid_beyond_it_raises_alert() {
        val alerts=DailyOps.coverageAlerts(listOf(sub(1,"2026-11-20","2026-11-05"),sub(2,"2026-11-04","2026-11-05")),today)
        assertEquals(1,alerts.size)
        assertEquals(2L,alerts[0].daysToAccountEnd)
        assertEquals(listOf(1L),alerts[0].clients.map{it.id})   // el cliente 2 vence antes que la cuenta: no está expuesto
    }

    @Test fun already_expired_account_with_exposed_client_still_alerts() {
        val a=DailyOps.coverageAlerts(listOf(sub(1,"2026-11-20","2026-10-30")),today)
        assertEquals(1,a.size); assertTrue(a[0].expired); assertEquals("venció hace 4 días",a[0].whenText())
    }

    @Test fun no_alert_when_account_is_far_or_clients_are_covered() {
        assertTrue(DailyOps.coverageAlerts(listOf(sub(1,"2026-11-20","2026-12-30")),today).isEmpty())          // lejos
        assertTrue(DailyOps.coverageAlerts(listOf(sub(1,"2026-11-05","2026-11-05")),today).isEmpty())          // cubierto
        assertTrue(DailyOps.coverageAlerts(listOf(sub(1,"2026-11-20","2026-11-05",status="CORTADO")),today).isEmpty())
    }

    @Test fun accounts_are_grouped_ignoring_case_and_spaces() {
        val a=DailyOps.coverageAlerts(listOf(sub(1,"2026-11-20","2026-11-05","A@B.com"),sub(2,"2026-11-21","2026-11-05"," a@b.com ")),today)
        assertEquals(1,a.size); assertEquals(2,a[0].clients.size)
    }

    @Test fun summary_counts_states_and_amount_to_collect() {
        val subs=listOf(
            sub(1,"2026-11-01","2027-01-01",price=1000),   // vencido
            sub(2,"2026-11-03","2027-01-01",price=2000),   // hoy
            sub(3,"2026-11-04","2027-01-01"),              // mañana
            sub(4,"2026-11-06","2027-01-01"),              // 2-3 días
            sub(5,"2026-12-30","2027-01-01"),              // vigente
            sub(6,"2026-11-01","2027-01-01",status="CORTADO")
        )
        val s=DailyOps.summary(subs,today)
        assertEquals(1,s.overdue); assertEquals(1,s.dueToday); assertEquals(1,s.dueTomorrow); assertEquals(1,s.upcoming)
        assertEquals(3000L,s.toCollect); assertEquals(2,s.actionable)
    }

    @Test fun notification_is_null_when_nothing_to_report_and_informative_otherwise() {
        assertNull(DailyOps.notificationText(DailyOps.summary(listOf(sub(1,"2026-12-30","2027-01-01")),today),emptyList()))
        val subs=listOf(sub(1,"2026-11-01","2026-11-05",price=1000),sub(2,"2026-11-20","2026-11-05"))
        val s=DailyOps.summary(subs,today)
        val (title,body)=DailyOps.notificationText(s,DailyOps.coverageAlerts(subs,today))!!
        assertTrue(title,title.contains("1 cobro pendiente"))
        assertTrue(title,title.contains("$1,000")||title.contains("$1.000"))
        assertTrue(body,body.contains("Capcut vence en 2 días"))
    }

    @Test fun only_coverage_alert_still_produces_a_notification() {
        val subs=listOf(sub(1,"2026-11-20","2026-11-04"))
        val (title,_)=DailyOps.notificationText(DailyOps.summary(subs,today),DailyOps.coverageAlerts(subs,today))!!
        assertTrue(title,title.contains("cuenta por vencer con clientes"))
    }

    @Test fun money_formats_negative_amounts_with_sign_first() {
        assertEquals("-$500",money(-500))
        assertEquals("$0",money(0))
    }

    // ---- Accesos por revocar (cambiar contraseña/PIN tras cortar) ----
    private fun stockItem(id:Long,type:String)=StockItem(id=id,service="Capcut",account="a$id@b.com",profile=if(type=="CUENTA COMPLETA")"" else "P1",type=type)

    @Test fun pending_revokes_are_listed_oldest_first_and_count_days() {
        val stock=listOf(stockItem(1,"CUENTA COMPLETA"),stockItem(2,"PERFIL/PANTALLA"),stockItem(3,"CUENTA COMPLETA"))
        val marks=mapOf(1L to "2026-11-01",2L to "2026-10-29")   // el 3 no tiene marca
        val list=DailyOps.pendingRevokes(stock,marks){it.type=="CUENTA COMPLETA"}
        assertEquals(listOf(2L,1L),list.map{it.stockId})
        assertEquals(5L,list[0].days(today)); assertEquals(2L,list[1].days(today))
        assertEquals("PIN del perfil",list[0].what); assertEquals("contraseña",list[1].what)
    }

    @Test fun days_never_negative_and_bad_date_is_zero() {
        assertEquals(0L,PendingRevoke(1,"x","a","",true,"2026-11-10").days(today))
        assertEquals(0L,PendingRevoke(1,"x","a","",true,"xx").days(today))
    }

    @Test fun pending_revoke_alone_produces_a_notification_with_oldest_age() {
        val pending=listOf(PendingRevoke(1,"Capcut","a@b.com","",true,"2026-10-29"))
        val s=DailyOps.summary(emptyList(),today,pending)
        assertEquals(1,s.pendingRevokes); assertEquals(5L,s.oldestRevokeDays); assertFalse(s.isEmpty)
        val (title,body)=DailyOps.notificationText(s,emptyList())!!
        assertTrue(title,title.contains("sin cambiar contraseña"))
        assertTrue(body,body.contains("el más antiguo: 5 días"))
    }

    @Test fun summary_without_pending_is_unchanged() {
        assertTrue(DailyOps.summary(emptyList(),today).isEmpty)
    }
}

package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test

/**
 * Pruebas de regresión para el parche mínimo de v8.2 (A1 y A2), con datos ficticios.
 *
 * Qué prueban: las dos condiciones booleanas añadidas en MainActivity.kt, replicadas aquí literalmente
 * para poder ejecutarlas sin un dispositivo Android (deleteErroneousSub() y changeAccess() son closures
 * de un @Composable con acceso a Context, y no se pueden invocar directamente desde JUnit puro).
 *
 * Qué NO prueban: la ejecución real de deleteErroneousSub()/changeAccess() dentro de la app, ni la
 * lectura/escritura real de ReminderScheduler.pendingRevoke()/markRevoke() contra SharedPreferences
 * (ambas requieren un Context de Android real). Eso queda pendiente de una prueba instrumentada en
 * GitHub Actions, igual que la restauración de respaldos de la sesión anterior. No se declara aquí
 * como ejecutado algo que no se ejecutó.
 *
 * No se tocó el sistema de cuentas archivadas (A3) ni se agregó ninguna función nueva en producción:
 * ambas reglas reutilizan ReminderScheduler.pendingRevoke()/markRevoke(), ya existentes desde v8.1.
 */
class RegressionA1A2Test {

    // ---- A1: MainActivity.kt, deleteErroneousSub() ----
    // val stillPending = s.stockId>0 && ReminderScheduler.pendingRevoke(c).containsKey(s.stockId)
    // if (s.stockId>0 && !stillPending) persistStock(... status="DISPONIBLE" ...)
    private fun a1_releasesStock(stockId: Long, pendingRevokeIds: Set<Long>): Boolean {
        val stillPending = stockId > 0 && pendingRevokeIds.contains(stockId)
        return stockId > 0 && !stillPending
    }

    @Test fun a1_does_not_release_a_stock_item_with_a_pending_password_change() {
        // Esto es exactamente el caso reportado: cliente cortado, clave sin cambiar, se borra el registro.
        assertFalse("con 'cambiar clave' pendiente, el A1 no debe liberar la cuenta",
            a1_releasesStock(stockId = 7L, pendingRevokeIds = setOf(7L)))
    }

    @Test fun a1_still_releases_a_stock_item_with_nothing_pending() {
        // Comportamiento normal (sin la marca de "acceso por revocar") no debe cambiar: v8.1 ya lo hacía bien.
        assertTrue(a1_releasesStock(stockId = 7L, pendingRevokeIds = emptySet()))
        assertTrue(a1_releasesStock(stockId = 7L, pendingRevokeIds = setOf(9L, 11L))) // pendiente de OTRA cuenta
    }

    @Test fun a1_ignores_entries_with_no_linked_stock_item() {
        // stockId=0 (entrega sin cuenta de stock vinculada, p. ej. registro de prueba manual): sin cambios.
        assertFalse(a1_releasesStock(stockId = 0L, pendingRevokeIds = setOf(7L)))
        assertFalse(a1_releasesStock(stockId = 0L, pendingRevokeIds = emptySet()))
    }

    @Test fun a1_regression_against_the_v8_1_bug() {
        // Antes del parche, v8.1 liberaba SIEMPRE que stockId>0, sin mirar la marca. Esta prueba falla
        // si alguien revierte el parche: "liberación v8.1" y "liberación v8.2" deben diferir justo aquí.
        val v81Behavior = { stockId: Long, _: Set<Long> -> stockId > 0 }
        val v82Behavior = ::a1_releasesStock
        val stockId = 7L; val pending = setOf(7L)
        assertNotEquals("el parche debe cambiar el resultado exactamente en el caso con clave pendiente",
            v81Behavior(stockId, pending), v82Behavior(stockId, pending))
    }

    // ---- A2: MainActivity.kt, changeAccess() ----
    // if (oldId>0) ReminderScheduler.markRevoke(c, oldId, LocalDate.now().toString())
    private fun a2_marksOldAccountPending(oldId: Long): Boolean = oldId > 0

    @Test fun a2_marks_the_previous_account_as_pending_password_change() {
        // Cliente movido de cuenta (p. ej. CapCut con correo nuevo cada 30 días): la cuenta vieja
        // sigue con la clave que el cliente movido todavía conoce.
        assertTrue(a2_marksOldAccountPending(oldId = 42L))
    }

    @Test fun a2_does_nothing_when_there_was_no_previous_account() {
        // stockId=0 antes del cambio (entrega sin cuenta de stock previa): no hay nada que marcar.
        assertFalse(a2_marksOldAccountPending(oldId = 0L))
    }

    @Test fun a2_uses_the_same_mechanism_as_cutting_a_client() {
        // No se creó una marca nueva: es la misma función (ReminderScheduler.markRevoke) que "No renovó"
        // ya usaba desde v8.1. Esta prueba documenta esa reutilización, no introduce una regla distinta.
        val cutMarksPending = { stockId: Long -> stockId > 0 }
        assertEquals(cutMarksPending(42L), a2_marksOldAccountPending(oldId = 42L))
    }

    // ---- Ambas reglas no deben inventar IDs ni tocar otras cuentas ----
    @Test fun neither_patch_touches_unrelated_stock_ids() {
        val pending = setOf(7L)
        // La cuenta 99 no está en el conjunto de pendientes ni es la que se libera/marca: debe quedar fuera.
        assertTrue(a1_releasesStock(stockId = 99L, pendingRevokeIds = pending))
        assertNotEquals(7L, 99L)
    }
}

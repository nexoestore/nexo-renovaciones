# Control de Cuentas Streaming v6.2

Actualización visual construida sobre la v6.1, sin cambiar las claves de almacenamiento ni el modelo de datos existente.

## Cambios visuales
- Encabezado superior más compacto.
- Barra inferior uniforme y sin emojis de streaming como iconos principales.
- Inicio convertido en panel de control con indicadores compactos de hoy, mañana, vencidos y disponibilidad.
- Tarjetas de cuentas maestras con mejor jerarquía para costo, ingreso, utilidad, proveedor y fecha de corte.
- Tarjetas de renovación simplificadas: acción principal de cobro, renovación y opciones secundarias plegables.
- Estados visuales consistentes: activo, vencido, en espera, libre y próximo.
- Reportes reorganizados en métricas financieras, cartera y actividad reciente.
- Sección Más agrupada en Negocio, Actividad, Aplicación y Copia de seguridad.
- Bordes, espacios, tamaños y colores más consistentes.

## Compatibilidad
- applicationId sin cambios: com.nexo.suscripciones
- SharedPreferences sin cambios: nexo_db
- backupVersion se mantiene en 2.
- Los respaldos anteriores siguen usando las mismas estructuras subs, hist y templates.
- VersionName: 6.2
- VersionCode: 15

## Nota de compilación
La estructura del proyecto y el ZIP fueron verificados localmente. La compilación Android completa debe confirmarse en GitHub Actions.

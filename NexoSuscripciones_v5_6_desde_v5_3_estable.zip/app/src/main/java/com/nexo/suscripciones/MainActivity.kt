package com.nexo.suscripciones

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Sub(val id:Long=System.currentTimeMillis(),val client:String,val phone:String,val service:String,val account:String,val profile:String,val type:String,val price:Long,val start:String,val end:String,val status:String="ACTIVO",val paid:Boolean=true,val pin:String="",val accountCost:Long=0,val paymentMethod:String="Efectivo",val contacted:Boolean=false,val password:String="")
data class Hist(val id:Long=System.currentTimeMillis(),val subId:Long,val date:String,val action:String,val amount:Long=0,val method:String="")
data class Templates(val due3:String="Hola {cliente} 👋 Tu servicio {servicio} vence el {fecha}. Valor de renovación: ${'$'}{precio}.",val due1:String="Hola {cliente} 👋 Te recordamos que tu servicio {servicio} vence mañana ({fecha}). Valor: ${'$'}{precio}.",val due0:String="Hola {cliente} 👋 Tu servicio {servicio} vence hoy ({fecha}). Si deseas continuar, puedes renovar por ${'$'}{precio}.",val expired:String="Hola {cliente} 👋 Tu servicio {servicio} venció el {fecha}. Si deseas reactivarlo, escríbeme para renovar.",val delivery:String="Hola {cliente} 👋 Aquí tienes tus datos de {servicio}:\nCuenta: {cuenta}\nContraseña: {password}\nPerfil: {perfil}\nPIN/clave: {pin}\nVence: {fecha}\nGracias por preferir Nexo.")

class Store(private val c:Context){private val p=c.getSharedPreferences("nexo_db",Context.MODE_PRIVATE)
 fun subs():MutableList<Sub>{val a=JSONArray(p.getString("subs","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Sub(o.getLong("id"),o.getString("client"),o.optString("phone"),o.getString("service"),o.optString("account"),o.optString("profile"),o.optString("type","PERFIL"),o.optLong("price"),o.getString("start"),o.getString("end"),o.optString("status","ACTIVO"),o.optBoolean("paid",true),o.optString("pin"),o.optLong("accountCost"),o.optString("paymentMethod","Efectivo"),o.optBoolean("contacted",false),o.optString("password",""))}}
 fun save(s:List<Sub>){val a=JSONArray();s.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("client",x.client);put("phone",x.phone);put("service",x.service);put("account",x.account);put("profile",x.profile);put("type",x.type);put("price",x.price);put("start",x.start);put("end",x.end);put("status",x.status);put("paid",x.paid);put("pin",x.pin);put("accountCost",x.accountCost);put("paymentMethod",x.paymentMethod);put("contacted",x.contacted);put("password",x.password)})};p.edit().putString("subs",a.toString()).apply();ReminderScheduler.sync(c,s)}
 fun hist():MutableList<Hist>{val a=JSONArray(p.getString("hist","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Hist(o.getLong("id"),o.getLong("subId"),o.getString("date"),o.getString("action"),o.optLong("amount"),o.optString("method"))}}
 fun saveHist(h:List<Hist>){val a=JSONArray();h.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("subId",x.subId);put("date",x.date);put("action",x.action);put("amount",x.amount);put("method",x.method)})};p.edit().putString("hist",a.toString()).apply()}
 fun templates():Templates{val o=runCatching{JSONObject(p.getString("templates","{}")!!)}.getOrDefault(JSONObject());val d=Templates();val oldDelivery=o.optString("delivery",d.delivery);val delivery=if(oldDelivery.contains("{password}"))oldDelivery else oldDelivery.replace("Cuenta: {cuenta}","Cuenta: {cuenta}\nContraseña: {password}");return Templates(o.optString("due3",d.due3),o.optString("due1",d.due1),o.optString("due0",d.due0),o.optString("expired",d.expired),delivery)}
 fun saveTemplates(t:Templates){p.edit().putString("templates",JSONObject().apply{put("due3",t.due3);put("due1",t.due1);put("due0",t.due0);put("expired",t.expired);put("delivery",t.delivery)}.toString()).apply()}
 fun backup():String=JSONObject().apply{put("version",5.3);put("subs",JSONArray(p.getString("subs","[]")));put("hist",JSONArray(p.getString("hist","[]")));put("templates",JSONObject(p.getString("templates","{}")!!))}.toString(2)
 fun restore(text:String):Boolean=runCatching{val o=JSONObject(text);p.edit().putString("subs",o.getJSONArray("subs").toString()).putString("hist",o.optJSONArray("hist")?.toString()?:"[]").putString("templates",o.optJSONObject("templates")?.toString()?:"{}").commit();ReminderScheduler.sync(c,subs());true}.getOrDefault(false)
}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);ReminderScheduler.sync(this,Store(this).subs());if(android.os.Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),1001);setContent{NexoApp()}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun NexoApp(){val c=LocalContext.current;val st=remember{Store(c)};var subs by remember{mutableStateOf(st.subs().toList())};var hist by remember{mutableStateOf(st.hist().toList())};var templates by remember{mutableStateOf(st.templates())};var tab by remember{mutableIntStateOf(0)};var add by remember{mutableStateOf(false)};var dark by remember{mutableStateOf(false)}
 fun persist(s:List<Sub>){subs=s;st.save(s)};fun log(id:Long,a:String,m:Long=0,method:String=""){hist=hist+Hist(subId=id,date=LocalDate.now().toString(),action=a,amount=m,method=method);st.saveHist(hist)}
 fun renew(s:Sub){val old=LocalDate.parse(s.end);val base=if(old.isBefore(LocalDate.now()))LocalDate.now() else old;persist(subs.map{if(it.id==s.id)it.copy(end=base.plusDays(30).toString(),status="ACTIVO",paid=true,contacted=false)else it});log(s.id,"RENOVACIÓN +30 DÍAS",s.price,s.paymentMethod)}
 fun cut(s:Sub){persist(subs.map{if(it.id==s.id)it.copy(status="CORTADO",profile="LIBRE",contacted=true)else it});log(s.id,"CORTE / PERFIL LIBERADO")}
 fun adjustEnd(s:Sub,newEnd:String,reason:String){val old=s.end;persist(subs.map{if(it.id==s.id)it.copy(end=newEnd,status="ACTIVO")else it});log(s.id,"AJUSTE VENCIMIENTO: $old → $newEnd${if(reason.isNotBlank())" • $reason" else ""}")}
 MaterialTheme(colorScheme=if(dark) darkColorScheme() else lightColorScheme()){Scaffold(topBar={TopAppBar(title={Text("Nexo Suscripciones",fontWeight=FontWeight.Bold)})},floatingActionButton={if(tab==0)FloatingActionButton({add=true}){Text("+")}},bottomBar={NavigationBar{listOf("Inicio","Renovar","Cuentas","Reportes","Más").forEachIndexed{i,x->NavigationBarItem(selected = tab==i, onClick = {tab=i}, icon = {Text(listOf("⌂","↻","🔐","▤","☰")[i])}, label = {Text(x)})}}}){pad->Box(Modifier.padding(pad)){when(tab){0->Home(subs,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,{s->persist(subs.map{if(it.id==s.id)it.copy(contacted=true)else it});log(s.id,"CONTACTADO POR WHATSAPP")});1->Renewals(subs,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,{s->persist(subs.map{if(it.id==s.id)it.copy(contacted=true)else it});log(s.id,"CONTACTADO POR WHATSAPP")});2->Accounts(subs,::adjustEnd);3->Reports(subs,hist);else->More(subs,hist,dark,{dark=it},templates,{templates=it;st.saveTemplates(it)},st,{subs=st.subs();hist=st.hist()})}}}
 if(add)AddDialog({add=false}){s->persist(subs+s);log(s.id,"VENTA / PAGO",s.price,s.paymentMethod);wa(c,s,fillTemplate(templates.delivery,s));add=false}}
}
fun days(s:Sub)=ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.end))
fun money(v:Long)="$${"%,d".format(v)}"
fun fillTemplate(t:String,s:Sub)=t.replace("{cliente}",s.client).replace("{servicio}",s.service).replace("{fecha}",s.end).replace("{precio}",money(s.price)).replace("{cuenta}",s.account).replace("{perfil}",s.profile).replace("{pin}",s.pin).replace("{password}",s.password)
fun messageFor(s:Sub,t:Templates):String=fillTemplate(when{days(s)<0->t.expired;days(s)==0L->t.due0;days(s)==1L->t.due1;else->t.due3},s)
fun wa(c:Context,s:Sub,msg:String){val u="https://wa.me/${s.phone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun Home(s:List<Sub>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub)->Unit,adjust:(Sub,String,String)->Unit,contact:(Sub)->Unit){val active=s.count{it.status=="ACTIVO"&&days(it)>=0};val due=s.count{it.status=="ACTIVO"&&days(it) in 0..3};val exp=s.count{it.status!="CORTADO"&&days(it)<0};val value=s.filter{it.status!="CORTADO"&&days(it) in 0..3}.sumOf{it.price};LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("HOY — ${LocalDate.now()}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};item{Card(Modifier.fillMaxWidth()){Text("🟢 $active activos   🟠 $due por vencer\n🔴 $exp vencidos   ✂️ $exp pendientes de corte\n💰 ${money(value)} por renovar",Modifier.padding(14.dp))}};item{Text("Trabajo de hoy",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)};val work=s.filter{it.status!="CORTADO"&&days(it)<=3}.sortedBy{it.end};if(work.isEmpty())item{Text("No tienes renovaciones pendientes.")};items(work){ActionCard(it,wa,renew,cut,adjust,contact)}}}
@Composable fun Renewals(s:List<Sub>,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub)->Unit,adjust:(Sub,String,String)->Unit,contact:(Sub)->Unit){val groups=listOf("EN 3 DÍAS" to s.filter{it.status!="CORTADO"&&days(it) in 2..3},"MAÑANA" to s.filter{it.status!="CORTADO"&&days(it)==1L},"HOY" to s.filter{it.status!="CORTADO"&&days(it)==0L},"VENCIDOS / PENDIENTES" to s.filter{it.status!="CORTADO"&&days(it)<0});LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text("Centro de renovaciones",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};groups.forEach{(title,list)->item{Text("$title (${list.size})",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)};if(list.isEmpty())item{Text("Sin clientes")};items(list.sortedBy{it.end}){ActionCard(it,wa,renew,cut,adjust,contact)}}}}
@Composable fun ActionCard(s:Sub,wa:(Sub)->Unit,renew:(Sub)->Unit,cut:(Sub)->Unit,adjust:(Sub,String,String)->Unit,contact:(Sub)->Unit){
 var showAdjust by remember(s.id){mutableStateOf(false)};val ctx=LocalContext.current
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
  Text("${if(days(s)<0)"🔴" else if(days(s)<=1)"🟠" else "🟡"} ${s.client} • ${s.service}",fontWeight=FontWeight.Bold)
  Text("${s.account} • ${s.profile} • vence ${s.end} • ${money(s.price)}")
  if(s.contacted)Text("✓ Contactado",style=MaterialTheme.typography.labelMedium)
  Button({wa(ctx,s,fillTemplate(Store(ctx).templates().delivery,s))},modifier=Modifier.fillMaxWidth()){Text("📤 Enviar credenciales")}
  OutlinedButton({showAdjust=true},modifier=Modifier.fillMaxWidth()){Text("📅 Ajustar vencimiento")}
  Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){Button({wa(s);contact(s)},contentPadding=PaddingValues(8.dp)){Text("WhatsApp")};OutlinedButton({renew(s)},contentPadding=PaddingValues(8.dp)){Text("+30")};if(days(s)<=0)OutlinedButton({cut(s)},contentPadding=PaddingValues(8.dp)){Text("Cortar")}}
 }}
 if(showAdjust)AdjustEndDialog(s,{showAdjust=false}){date,reason->adjust(s,date,reason);showAdjust=false}
}
@Composable fun Accounts(s:List<Sub>,adjust:(Sub,String,String)->Unit){
 val ctx=LocalContext.current;val st=remember{Store(ctx)};var adjusting by remember{mutableStateOf<Sub?>(null)};val g=s.groupBy{it.account.ifBlank{"Sin cuenta"}}
 LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  item{Text("Cuentas y perfiles",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)}
  items(g.entries.toList()){e->
   val cost=e.value.maxOfOrNull{it.accountCost}?:0;val income=e.value.filter{it.status!="CORTADO"}.sumOf{it.price}
   Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
    Text(e.key,fontWeight=FontWeight.Bold)
    if(e.value.firstOrNull()?.password?.isNotBlank()==true)Text("🔑 Contraseña guardada")
    Text("Costo: ${money(cost)} • Ingreso actual: ${money(income)} • Utilidad: ${money(income-cost)}")
    e.value.forEach{x->
     Column(verticalArrangement=Arrangement.spacedBy(5.dp)){
      Text("${if(x.status=="CORTADO")"⚪" else if(days(x)<0)"🔴" else "🟢"} ${x.profile.ifBlank{x.type}} — ${if(x.status=="CORTADO")"LIBRE" else x.client} ${if(x.status!="CORTADO")"— vence ${x.end}" else ""}")
      if(x.status!="CORTADO"){
       Button(onClick={wa(ctx,x,fillTemplate(st.templates().delivery,x))},modifier=Modifier.fillMaxWidth()){Text("📤 Enviar credenciales")}
       OutlinedButton(onClick={adjusting=x},modifier=Modifier.fillMaxWidth()){Text("📅 Ajustar vencimiento")}
      }
     }
    }
   }}
  }
 }
 adjusting?.let{current->AdjustEndDialog(current,{adjusting=null}){date,reason->adjust(current,date,reason);adjusting=null}}
}
@Composable fun Reports(s:List<Sub>,h:List<Hist>){val sales=h.filter{it.action.contains("VENTA")||it.action.contains("RENOVACIÓN")};val income=sales.sumOf{it.amount};val costs=s.groupBy{it.account}.values.sumOf{it.maxOfOrNull{x->x.accountCost}?:0};LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Reportes y estadísticas",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};item{Card(Modifier.fillMaxWidth()){Text("Ingresos registrados: ${money(income)}\nCostos de cuentas: ${money(costs)}\nUtilidad estimada: ${money(income-costs)}\nClientes activos: ${s.count{it.status=="ACTIVO"&&days(it)>=0}}\nVencidos: ${s.count{it.status!="CORTADO"&&days(it)<0}}\nRenovaciones: ${h.count{it.action.contains("RENOVACIÓN")}}",Modifier.padding(14.dp))}};item{Text("Historial de pagos",fontWeight=FontWeight.Bold)};items(h.sortedByDescending{it.id}){x->val n=s.find{it.id==x.subId}?.client?:"Cliente";Text("${x.date} • $n • ${x.action}${if(x.amount>0)" • ${money(x.amount)} ${x.method}" else ""}")}}}
@Composable fun More(s:List<Sub>,h:List<Hist>,dark:Boolean,setDark:(Boolean)->Unit,t:Templates,setT:(Templates)->Unit,st:Store,reload:()->Unit){var edit by remember{mutableStateOf(false)};var restore by remember{mutableStateOf(false)};val c=LocalContext.current;LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Configuración",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};item{Row(verticalAlignment=Alignment.CenterVertically){Text("🌙 Modo oscuro",Modifier.weight(1f));Switch(dark,setDark)}};item{Button({edit=true},Modifier.fillMaxWidth()){Text("⚙️ Editar mensajes")}};item{OutlinedButton({val send=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,st.backup())};c.startActivity(Intent.createChooser(send,"Exportar respaldo Nexo"))},Modifier.fillMaxWidth()){Text("💾 Exportar respaldo")}};item{OutlinedButton({restore=true},Modifier.fillMaxWidth()){Text("♻️ Restaurar respaldo")}};item{Text("Clientes: ${s.map{it.client}.distinct().size} • Registros: ${h.size}")}};if(edit)TemplateDialog(t,{edit=false}){setT(it);edit=false};if(restore)RestoreDialog({restore=false}){if(st.restore(it)){reload();restore=false}}}
@Composable fun TemplateDialog(t:Templates,close:()->Unit,save:(Templates)->Unit){var a by remember{mutableStateOf(t.due3)};var b by remember{mutableStateOf(t.due1)};var c by remember{mutableStateOf(t.due0)};var d by remember{mutableStateOf(t.expired)};var e by remember{mutableStateOf(t.delivery)};AlertDialog(onDismissRequest=close,title={Text("Mensajes configurables")},text={LazyColumn{item{F("Vence en 3 días",a){a=it}};item{F("Vence mañana",b){b=it}};item{F("Vence hoy",c){c=it}};item{F("Vencido",d){d=it}};item{F("Entrega",e){e=it}}}},confirmButton={Button({save(Templates(a,b,c,d,e))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun RestoreDialog(close:()->Unit,restore:(String)->Unit){var text by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Restaurar respaldo")},text={Column{Text("Pega aquí el respaldo JSON exportado desde Nexo.");OutlinedTextField(text,{text=it},modifier=Modifier.fillMaxWidth().height(180.dp))}},confirmButton={Button({restore(text)},enabled=text.isNotBlank()){Text("Restaurar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun AddDialog(close:()->Unit,save:(Sub)->Unit){var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var profile by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var method by remember{mutableStateOf("Nequi")};var type by remember{mutableStateOf("PERFIL/PANTALLA")};var start by remember{mutableStateOf(LocalDate.now().toString())};AlertDialog(onDismissRequest=close,title={Text("Nueva venta / entrega")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){item{F("Cliente",client){client=it}};item{F("WhatsApp (57...)",phone){phone=it}};item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña del correo / cuenta",password){password=it}};item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave",pin){pin=it}};item{F("Tipo: CUENTA COMPLETA o PERFIL",type){type=it}};item{F("Precio cobrado",price){price=it}};item{F("Costo de la cuenta",cost){cost=it}};item{F("Método de pago",method){method=it}};item{F("Inicio AAAA-MM-DD",start){start=it}};item{Text("Vencimiento: ${runCatching{LocalDate.parse(start).plusDays(30)}.getOrNull()?:"fecha inválida"}")}}},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&runCatching{LocalDate.parse(start)}.isSuccess,onClick={val d=LocalDate.parse(start);save(Sub(client=client,phone=phone,service=service,account=account,profile=profile,pin=pin,type=type,password=password,price=price.filter{it.isDigit()}.toLongOrNull()?:0,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,paymentMethod=method,start=d.toString(),end=d.plusDays(30).toString()))}){Text("Guardar y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun AdjustEndDialog(s:Sub,close:()->Unit,save:(String,String)->Unit){
 var date by remember(s.id){mutableStateOf(s.end)}
 var reason by remember(s.id){mutableStateOf("")}
 fun addDays(n:Long){date=runCatching{LocalDate.parse(date).plusDays(n).toString()}.getOrDefault(s.end)}
 AlertDialog(
  onDismissRequest=close,
  title={Text("Ajustar vencimiento")},
  text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text("${s.client} • ${s.service}")
   Text("Vencimiento actual: ${s.end}")
   OutlinedTextField(value=date,onValueChange={date=it},label={Text("Nueva fecha AAAA-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
   Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1L,3L,5L,7L).forEach{n->OutlinedButton(onClick={addDays(n)},contentPadding=PaddingValues(horizontal=8.dp,vertical=6.dp)){Text("+$n")}}}
   OutlinedTextField(value=reason,onValueChange={reason=it},label={Text("Motivo (opcional)")},modifier=Modifier.fillMaxWidth())
   Text("Este ajuste no registra una venta ni una renovación pagada.",style=MaterialTheme.typography.bodySmall)
  }},
  confirmButton={Button(onClick={save(date,reason)},enabled=runCatching{LocalDate.parse(date)}.isSuccess){Text("Guardar")}},
  dismissButton={TextButton(onClick=close){Text("Cancelar")}}
 )
}

@Composable fun F(l:String,v:String,c:(String)->Unit){OutlinedTextField(v,c,label={Text(l)},singleLine=false,modifier=Modifier.fillMaxWidth())}

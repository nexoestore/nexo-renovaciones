# Nexo Suscripciones v5.3
Actualización incremental sobre v5.2.

- Mantiene las funciones y almacenamiento existentes.
- Añade el botón permanente `📤 Enviar credenciales` dentro de Cuentas y perfiles para cada perfil/suscripción ocupada.
- El botón recupera los datos guardados y abre WhatsApp del cliente con la plantilla de entrega: servicio, cuenta/correo, contraseña, perfil, PIN y vencimiento.
- No elimina las credenciales después de enviarlas.
- versionCode 8 / versionName 5.3.

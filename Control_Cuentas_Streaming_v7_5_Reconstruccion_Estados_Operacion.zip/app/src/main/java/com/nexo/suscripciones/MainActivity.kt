package com.nexo.suscripciones

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class MainActivity:FragmentActivity(){
 private val unlocked=mutableStateOf(true)
 private var backgroundAt=0L
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  val store=Store(this);ReminderScheduler.sync(this,store.subs(),store.stock(),store.templates())
  if(android.os.Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),1001)
  unlocked.value=!AppLockManager(this).isEnabled()
  setContent{
   val lock=remember{AppLockManager(this@MainActivity)}
   if(unlocked.value)NexoApp(onLockNow={unlocked.value=false})
   else AppUnlockScreen(lock,onUnlocked={unlocked.value=true},onBiometric={authenticateBiometric(lock)})
  }
 }
 override fun onStop(){backgroundAt=System.currentTimeMillis();super.onStop()}
 override fun onStart(){
  super.onStart()
  if(backgroundAt>0&&System.currentTimeMillis()-backgroundAt>=60_000L&&AppLockManager(this).isEnabled())unlocked.value=false
 }
 private fun authenticateBiometric(lock:AppLockManager){
  if(!lock.biometricEnabled()||!lock.canUseBiometric())return
  val prompt=BiometricPrompt(this,ContextCompat.getMainExecutor(this),object:BiometricPrompt.AuthenticationCallback(){
   override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){super.onAuthenticationSucceeded(result);unlocked.value=true}
  })
  val info=BiometricPrompt.PromptInfo.Builder().setTitle("Desbloquear Control Streaming").setSubtitle("Usa tu huella o biometría").setNegativeButtonText("Usar PIN").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK).build()
  prompt.authenticate(info)
 }
}

@Composable fun AppUnlockScreen(lock:AppLockManager,onUnlocked:()->Unit,onBiometric:()->Unit){
 var pin by remember{mutableStateOf("")}
 var error by remember{mutableStateOf("")}
 var attemptedBio by remember{mutableStateOf(false)}
 LaunchedEffect(Unit){if(lock.biometricEnabled()&&lock.canUseBiometric()&&!attemptedBio){attemptedBio=true;onBiometric()}}
 MaterialTheme(colorScheme=darkColorScheme(primary=StreamCyan,background=Color(0xFF06111A),surface=Color(0xFF0A1823),onBackground=Color(0xFFF5FAFC),onSurface=Color(0xFFF5FAFC))){
  Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background){Box(Modifier.fillMaxSize().padding(24.dp),contentAlignment=Alignment.Center){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(14.dp)){
   BrandTitle();Text("Protege tus cuentas y credenciales",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text("Ingresa tu PIN para continuar.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
   OutlinedTextField(pin,{if(it.length<=8&&it.all(Char::isDigit)){pin=it;error=""}},label={Text("PIN")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true,modifier=Modifier.fillMaxWidth())
   if(error.isNotBlank())Text(error,color=StreamRed,style=MaterialTheme.typography.bodySmall)
   Button({val wait=lock.remainingLockSeconds();if(wait>0){error="Espera ${wait}s antes de intentar de nuevo"}else if(lock.verifyPin(pin)){pin="";onUnlocked()}else{val left=lock.remainingLockSeconds();error=if(left>0)"Demasiados intentos. Espera ${left}s" else "PIN incorrecto";pin=""}},enabled=pin.length>=4,modifier=Modifier.fillMaxWidth()){Text("Desbloquear")}
   if(lock.biometricEnabled()&&lock.canUseBiometric())OutlinedButton(onBiometric,Modifier.fillMaxWidth()){Text("Usar huella / biometría")}
  }}}}
 }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun NexoApp(onLockNow:()->Unit={}){
 val c=LocalContext.current
 val st=remember{Store(c)}
 var subs by remember{mutableStateOf(st.subs().toList())}
 var hist by remember{mutableStateOf(st.hist().toList())}
 var stock by remember{mutableStateOf(st.stock().toList())}
 var services by remember{mutableStateOf(st.services().toList())}
 var templates by remember{mutableStateOf(st.templates())}
 var tab by remember{mutableIntStateOf(0)}
 var add by remember{mutableStateOf(false)}
 var saleChoice by remember{mutableStateOf(false)}
 var dark by remember{mutableStateOf(st.darkMode())}
 var editing by remember{mutableStateOf<Sub?>(null)}
 var searchOpen by remember{mutableStateOf(false)}
 fun persist(items:List<Sub>){subs=items;st.save(items)}
 fun persistStock(items:List<StockItem>){stock=items;st.saveStock(items)}
 fun persistServices(items:List<ServiceTemplate>){services=items;st.saveServices(items)}
 fun log(id:Long,a:String,m:Long=0,method:String=""){hist=hist+Hist(subId=id,date=LocalDate.now().toString(),action=a,amount=m,method=method);st.saveHist(hist);st.autoBackupIfNeeded(true)}
 fun contact(s:Sub){val date=LocalDate.now().toString();persist(subs.map{if(it.id==s.id)it.copy(contacted=true,lastContact=date)else it});log(s.id,"WHATSAPP ABIERTO") }
 fun renew(s:Sub,newPrice:Long,method:String,durationDays:Int){val days=durationDays.coerceAtLeast(1);val newEnd=OperationRules.renewalEnd(s.end,days);persist(subs.map{if(it.id==s.id)it.copy(end=newEnd,status="ACTIVO",paid=true,contacted=false,promiseDate="",price=newPrice,paymentMethod=method)else it});log(s.id,"RENOVACIÓN +$days DÍAS",newPrice,method)}
 fun cut(s:Sub,reason:String){
  persist(subs.map{if(it.id==s.id)it.copy(status="CORTADO",contacted=true,promiseDate="")else it})
  if(s.stockId>0){persistStock(stock.map{if(it.id==s.stockId)it.copy(status="DISPONIBLE")else it})}
  else if(s.account.isNotBlank()&&stock.none{it.account==s.account&&it.profile==s.profile&&effectiveStockStatus(it)=="DISPONIBLE"}){
   persistStock(stock+StockItem(service=s.service,account=s.account,password=s.password,profile=s.profile,pin=s.pin,type=normalizedAccessType(s.type,s.profile),provider=s.provider,providerPhone=s.providerPhone,accountEnd=s.accountEnd,accountCost=s.accountCost,accountRenewCost=s.accountRenewCost,status="DISPONIBLE",purchaseDate=s.purchaseDate))
  }
  log(s.id,"BAJA • $reason • ${s.service} • ACCESO LIBERADO")
 }
 fun promise(s:Sub,date:String){persist(subs.map{if(it.id==s.id)it.copy(status="ESPERA",promiseDate=date)else it});log(s.id,"PROMESA DE PAGO • $date")}
 fun adjustEnd(s:Sub,newEnd:String,reason:String){val old=s.end;persist(subs.map{if(it.id==s.id)it.copy(end=newEnd,status="ACTIVO")else it});log(s.id,"AJUSTE VENCIMIENTO: $old → $newEnd${if(reason.isNotBlank())" • $reason" else ""}")}
 fun deleteErroneousSub(s:Sub){
  if(s.stockId>0)persistStock(stock.map{if(it.id==s.stockId)it.copy(status="DISPONIBLE")else it})
  val remaining=subs.filterNot{it.id==s.id};subs=remaining;st.save(remaining)
  hist=hist.filterNot{it.subId==s.id};st.saveHist(hist);st.autoBackupIfNeeded(true)
 }
 fun updateSub(updated:Sub){
  val clean=updated.copy(provider=normalizedProviderStorage(updated.provider));val targetStock=stock.firstOrNull{it.id==clean.stockId};val master=targetStock?.masterId.orEmpty();val affectedStockIds=if(master.isNotBlank())stock.filter{it.masterId==master}.map{it.id}.toSet() else setOf(clean.stockId)
  val updatedSubs=subs.map{x->when{
   x.id==clean.id->clean
   clean.stockId>0&&x.stockId in affectedStockIds->x.copy(service=clean.service,account=clean.account,password=clean.password,provider=clean.provider,providerPhone=clean.providerPhone,accountEnd=clean.accountEnd,accountCost=clean.accountCost,accountRenewCost=clean.accountRenewCost,purchaseDate=clean.purchaseDate)
   else->x
  }};persist(updatedSubs)
  if(clean.stockId>0){persistStock(stock.map{x->if(x.id in affectedStockIds)x.copy(service=clean.service,account=clean.account,password=clean.password,provider=clean.provider,providerPhone=clean.providerPhone,accountEnd=clean.accountEnd,accountCost=clean.accountCost,accountRenewCost=clean.accountRenewCost,purchaseDate=clean.purchaseDate,profile=if(x.id==clean.stockId)clean.profile else x.profile,pin=if(x.id==clean.stockId)clean.pin else x.pin,type=if(x.id==clean.stockId)normalizedAccessType(clean.type,clean.profile) else x.type)else x})}
  log(clean.id,"EDICIÓN DE ENTREGA / CUENTA")
 }
 fun addStockItems(items:List<StockItem>){
  if(items.isEmpty())return
  val clean=items.map{it.copy(provider=normalizedProviderStorage(it.provider))}
  persistStock(stock+clean)
  val first=clean.first()
  log(0L,"COMPRA STOCK • ${first.provider.ifBlank{"Sin proveedor"}} • ${first.service} • ${first.account}",first.accountCost,"Proveedor")
 }
 fun renewProvider(a:ProviderAccountSummary,newEnd:String,cost:Long){
  persist(subs.map{if(sameProvider(it.provider,a.provider)&&accountKey(it.account)==accountKey(a.account))it.copy(accountEnd=newEnd,accountRenewCost=cost,provider=normalizedProviderStorage(it.provider))else it})
  persistStock(stock.map{if(sameProvider(it.provider,a.provider)&&accountKey(it.account)==accountKey(a.account))it.copy(accountEnd=newEnd,accountRenewCost=cost,provider=normalizedProviderStorage(it.provider))else it})
  log(0L,"RENOVACIÓN PROVEEDOR • ${normalizedProviderStorage(a.provider)} • ${a.account} • $newEnd",cost,"Proveedor")
 }
 fun syncProfileAccount(groupKey:String,updated:StockItem){
  val ids=stock.filter{!isComplete(it)&&profileStockGroupKey(it)==groupKey}.map{it.id}.toSet();if(ids.isEmpty())return
  val provider=normalizedProviderStorage(updated.provider)
  persistStock(stock.map{x->if(x.id in ids)x.copy(service=updated.service,account=updated.account,password=updated.password,provider=provider,providerPhone=updated.providerPhone,accountEnd=updated.accountEnd,accountCost=updated.accountCost,accountRenewCost=updated.accountRenewCost,purchaseDate=updated.purchaseDate)else x})
  persist(subs.map{x->if(x.stockId in ids)x.copy(service=updated.service,account=updated.account,password=updated.password,provider=provider,providerPhone=updated.providerPhone,accountEnd=updated.accountEnd,accountCost=updated.accountCost,accountRenewCost=updated.accountRenewCost,purchaseDate=updated.purchaseDate)else x})
  log(0L,"CUENTA PRINCIPAL ACTUALIZADA • ${updated.service} • ${updated.account}")
 }
 val streamDark=darkColorScheme(primary=StreamCyan,secondary=StreamBlue,tertiary=StreamAmber,background=Color(0xFF06111A),surface=Color(0xFF0A1823),surfaceVariant=Color(0xFF102536),outline=Color(0xFF3D6074),outlineVariant=Color(0xFF183447),onBackground=Color(0xFFF5FAFC),onSurface=Color(0xFFF5FAFC),onSurfaceVariant=Color(0xFFB8C7D1))
 val streamLight=lightColorScheme(primary=Color(0xFF007F8F),secondary=Color(0xFF1769E0),tertiary=Color(0xFF9B5D00),surfaceVariant=Color(0xFFE8F1F7))
 val appShapes=Shapes(small=RoundedCornerShape(12.dp),medium=RoundedCornerShape(18.dp),large=RoundedCornerShape(24.dp))
 MaterialTheme(colorScheme=if(dark)streamDark else streamLight,shapes=appShapes){
  Scaffold(
   containerColor=MaterialTheme.colorScheme.background,
   topBar={TopAppBar(title={BrandTitle()},actions={IconButton({searchOpen=true}){Icon(Icons.Default.Search,contentDescription="Buscar")};IconButton({tab=5}){Icon(Icons.Default.Settings,contentDescription="Ajustes")}},colors=TopAppBarDefaults.topAppBarColors(containerColor=MaterialTheme.colorScheme.background))},
   floatingActionButton={if(tab==0)ExtendedFloatingActionButton(onClick={saleChoice=true},containerColor=StreamCyan,contentColor=Color(0xFF001317),icon={Icon(Icons.Default.Inventory2,contentDescription=null)},text={Text("Nueva venta",fontWeight=FontWeight.Bold)})},
   bottomBar={NavigationBar(containerColor=MaterialTheme.colorScheme.surface){val labels=listOf("Inicio","Renovar","Stock","Proveedores","Reportes");val navIcons=listOf(Icons.Default.Home,Icons.Default.Refresh,Icons.Default.Inventory2,Icons.Default.Groups,Icons.Default.BarChart);labels.forEachIndexed{i,x->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(navIcons[i],contentDescription=x)},label={Text(x,fontSize=10.sp,maxLines=1)},colors=NavigationBarItemDefaults.colors(selectedIconColor=StreamCyan,selectedTextColor=StreamCyan,indicatorColor=StreamPurple.copy(alpha=.22f)))}}}
  ){pad->Box(Modifier.padding(pad)){when(tab){
   0->Home(subs,stock,hist,services,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,::contact,{editing=it})
   1->Renewals(subs,{wa(c,it,messageFor(it,templates))},::renew,::cut,::adjustEnd,::promise,::contact,{editing=it})
   2->Accounts(subs,stock,hist,services,::persistStock,::addStockItems,{sold,item->val clean=sold.copy(provider=normalizedProviderStorage(sold.provider));persist(subs+clean);persistStock(stock.map{if(it.id==item.id)it.copy(status=if(isComplete(item))"ENTREGADA" else "OCUPADO")else it});log(clean.id,"VENTA / PAGO DESDE STOCK",clean.price,clean.paymentMethod);wa(c,clean,fillTemplate(templates.delivery,clean))},::renew,::cut,::contact,::syncProfileAccount,::adjustEnd,{editing=it})
   3->Providers(subs,stock,hist,::renewProvider)
   4->Reports(subs,stock,hist)
   else->More(subs,stock,hist,services,::persistServices,dark,{dark=it;st.setDarkMode(it)},templates,{templates=it;st.saveTemplates(it)},st,{subs=st.subs();hist=st.hist();stock=st.stock();services=st.services()},onLockNow)
  }}}
  if(saleChoice)SaleStartDialog(stock,{saleChoice=false},{saleChoice=false;tab=2},{saleChoice=false;add=true})
  if(add)AddDialog(services,st.clients(),{add=false}){x->val clean=x.copy(provider=normalizedProviderStorage(x.provider));persist(subs+clean);log(clean.id,"VENTA / PAGO",clean.price,clean.paymentMethod);wa(c,clean,fillTemplate(templates.delivery,clean));add=false}
  editing?.let{current->EditSubDialog(current,{editing=null},{updated->updateSub(updated);editing=null},{deleteErroneousSub(current);editing=null})}
  if(searchOpen)GlobalSearchDialog(subs,stock,templates,{searchOpen=false},{sub->wa(c,sub,fillTemplate(templates.delivery,sub))},{sub->searchOpen=false;editing=sub})
 }
}

val StreamCyan=Color(0xFF19E6E6)
val StreamBlue=Color(0xFF1E88FF)
val StreamGreen=Color(0xFF25D97B)
val StreamYellow=Color(0xFFFFD43B)
val StreamAmber=Color(0xFFFFA31A)
val StreamRed=Color(0xFFFF4052)
val StreamPurple=Color(0xFF9A63FF)

@Composable fun BrandTitle(){
 Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(9.dp)){
  Surface(shape=RoundedCornerShape(12.dp),color=StreamCyan.copy(alpha=.10f),border=BorderStroke(1.dp,StreamCyan.copy(alpha=.65f))){
   Box(Modifier.size(38.dp),contentAlignment=Alignment.Center){Text("N",color=StreamCyan,fontWeight=FontWeight.Black,style=MaterialTheme.typography.titleLarge)}
  }
  Column(verticalArrangement=Arrangement.spacedBy(1.dp)){
   Text("NEXO DIGITAL",style=MaterialTheme.typography.titleSmall,fontWeight=FontWeight.Black,maxLines=1)
   Text("Control Streaming",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
  }
 }
}

@Composable fun RenewalChip(label:String,count:Int,color:Color){
 Surface(shape=RoundedCornerShape(14.dp),color=color.copy(alpha=.12f),border=BorderStroke(1.dp,color.copy(alpha=.65f))){
  Column(Modifier.padding(horizontal=13.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){
   Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
   Text(count.toString(),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,color=color)
  }
 }
}

fun normalizedAccessType(type:String,profile:String=""):String{val u=type.uppercase();return if(u.contains("CUENTA COMPLETA")||(u.contains("CORREO/CONTRASEÑA")&&profile.isBlank()))"CUENTA COMPLETA" else "PERFIL/PANTALLA"}
fun isComplete(s:Sub)=normalizedAccessType(s.type,s.profile)=="CUENTA COMPLETA"
fun isComplete(x:StockItem)=normalizedAccessType(x.type,x.profile)=="CUENTA COMPLETA"

fun days(s:Sub)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.end))}.getOrDefault(9999L)
fun accountDays(s:Sub)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(s.accountEnd))}.getOrDefault(999)
fun effectiveStockStatus(x:StockItem):String{val expired=x.accountEnd.isNotBlank()&&runCatching{LocalDate.parse(x.accountEnd).isBefore(LocalDate.now())}.getOrDefault(false);return if(expired)"NO_DISPONIBLE" else x.status}
fun stockAccountDays(x:StockItem)=runCatching{ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(x.accountEnd))}.getOrDefault(999)
fun money(v:Long)="$${"%,d".format(v)}"
fun providerDisplayName(raw:String):String{
 val t=raw.trim();if(t.isBlank())return "Sin datos"
 val looksDomain=!t.contains(" ")&&t.contains(".")
 val uriText=if(t.startsWith("http://",true)||t.startsWith("https://",true))t else if(looksDomain)"https://$t" else ""
 if(uriText.isNotBlank()){val host=runCatching{java.net.URI(uriText).host?.removePrefix("www.")}.getOrNull().orEmpty();if(host.isNotBlank()){val base=host.substringBefore(".");return if(base.length<=5)base.uppercase() else base.replace("-"," ").split(" ").filter{it.isNotBlank()}.joinToString(" "){it.replaceFirstChar{c->c.uppercase()}}}}
 return t.trim().replace(Regex("\\s+")," ")
}
fun providerKey(raw:String):String{
 val display=providerDisplayName(raw).trim().lowercase()
 return display.replace(Regex("[^a-z0-9áéíóúüñ]"),"")
}
fun sameProvider(a:String,b:String):Boolean{val ka=providerKey(a);val kb=providerKey(b);return ka.isNotBlank()&&ka==kb}
fun accountKey(raw:String)=raw.trim().lowercase()
fun normalizedProviderStorage(raw:String):String{val d=providerDisplayName(raw);return if(d=="Sin datos")"" else d}
fun contactLabel(last:String):String{if(last.isBlank())return "WHATSAPP ABIERTO";val d=runCatching{LocalDate.parse(last)}.getOrNull()?:return "WHATSAPP ABIERTO";val today=LocalDate.now();if(d==today)return "WHATSAPP ABIERTO HOY";if(d==today.minusDays(1))return "WHATSAPP ABIERTO AYER";val m=listOf("ENE","FEB","MAR","ABR","MAY","JUN","JUL","AGO","SEP","OCT","NOV","DIC");return "WHATSAPP ABIERTO ${d.dayOfMonth} ${m[d.monthValue-1]}"}
fun monthPrefix():String=LocalDate.now().toString().take(7)
fun isSaleIncome(x:Hist)=x.action.contains("VENTA")||x.action.startsWith("RENOVACIÓN +")
fun activityOwner(x:Hist,s:List<Sub>):String{if(x.subId!=0L)return s.find{it.id==x.subId}?.client?:"Cliente";val parts=x.action.split(" • ");return when{x.action.contains("PROVEEDOR")->providerDisplayName(parts.getOrNull(1)?:"Proveedor");x.action.contains("COMPRA STOCK")->providerDisplayName(parts.getOrNull(1)?:"Stock");else->"Operación"}}
fun providerAccounts(s:List<Sub>,stock:List<StockItem>,h:List<Hist>):List<ProviderAccountSummary>{
 val keys=(s.filter{it.provider.isNotBlank()&&it.account.isNotBlank()}.map{providerKey(it.provider) to accountKey(it.account)}+stock.filter{it.provider.isNotBlank()&&it.account.isNotBlank()}.map{providerKey(it.provider) to accountKey(it.account)}).filter{it.first.isNotBlank()&&it.second.isNotBlank()}.distinct()
 return keys.map{(pk,ak)->
  val ss=s.filter{providerKey(it.provider)==pk&&accountKey(it.account)==ak};val xs=stock.filter{providerKey(it.provider)==pk&&accountKey(it.account)==ak};val sub=ss.firstOrNull();val item=xs.firstOrNull()
  val rawProviders=(ss.map{it.provider}+xs.map{it.provider}).filter{it.isNotBlank()};val provider=rawProviders.minByOrNull{if(it.startsWith("http",true)||it.contains("."))1 else 0}?.let{normalizedProviderStorage(it)}?:pk
  val account=(ss.map{it.account}+xs.map{it.account}).firstOrNull{it.isNotBlank()}?:ak
  val subIds=ss.map{it.id};val income=h.filter{it.subId in subIds&&isSaleIncome(it)}.sumOf{it.amount}
  val renewSpent=h.filter{ev->if(!ev.action.contains("RENOVACIÓN PROVEEDOR"))false else{val parts=ev.action.split(" • ");parts.size>=3&&providerKey(parts[1])==pk&&accountKey(parts[2])==ak}}.sumOf{it.amount}
  val end=(ss.map{it.accountEnd}+xs.map{it.accountEnd}).firstOrNull{it.isNotBlank()}?:"";val purchase=(xs.map{it.purchaseDate}+ss.map{it.purchaseDate}+ss.map{it.start}).firstOrNull{it.isNotBlank()}?:""
  val cost=(ss.map{it.accountCost}+xs.map{it.accountCost}).maxOrNull()?:0L;val renewCost=(ss.map{it.accountRenewCost}+xs.map{it.accountRenewCost}).maxOrNull()?:0L
  val active=ss.any{it.status!="CORTADO"};val available=xs.any{effectiveStockStatus(it)=="DISPONIBLE"};val expired=end.isNotBlank()&&runCatching{LocalDate.parse(end).isBefore(LocalDate.now())}.getOrDefault(false);val status=when{expired->"VENCIDA";active->"ACTIVA";available->"STOCK";else->"NO DISPONIBLE"}
  ProviderAccountSummary(provider,item?.providerPhone?:sub?.providerPhone?:"",item?.service?:sub?.service?:"Servicio",account,item?.type?:sub?.type?:"CUENTA COMPLETA",cost,renewCost,purchase,end,status,income,renewSpent,subIds)
 }
}
fun monthlyAccountCosts(s:List<Sub>,stock:List<StockItem>):Long{
 val month=monthPrefix()
 val stockGroups=stock.filter{it.account.isNotBlank()}.groupBy{it.masterId.ifBlank{"legacy|${providerKey(it.provider)}|${accountKey(it.account)}"}}
 val stockCost=stockGroups.values.sumOf{xs->val d=xs.map{it.purchaseDate}.firstOrNull{it.isNotBlank()}?:"";if(d.startsWith(month))xs.maxOfOrNull{it.accountCost}?:0L else 0L}
 val stockAccounts=stock.map{providerKey(it.provider) to accountKey(it.account)}.toSet()
 val legacyGroups=s.filter{it.account.isNotBlank()&&(providerKey(it.provider) to accountKey(it.account)) !in stockAccounts}.groupBy{providerKey(it.provider) to accountKey(it.account)}
 val legacyCost=legacyGroups.values.sumOf{ss->val d=(ss.map{it.purchaseDate}+ss.map{it.start}).firstOrNull{it.isNotBlank()}?:"";if(d.startsWith(month))ss.maxOfOrNull{it.accountCost}?:0L else 0L}
 return stockCost+legacyCost
}
fun fillTemplate(t:String,s:Sub):String{
 val values=mapOf("{cliente}" to s.client,"{servicio}" to s.service,"{fecha}" to s.end,"{precio}" to money(s.price),"{cuenta}" to s.account,"{perfil}" to s.profile,"{pin}" to s.pin,"{password}" to s.password)
 val optional=setOf("{cuenta}","{password}","{perfil}","{pin}")
 return t.lines()
  .filterNot{line->optional.any{key->line.contains(key)&&values[key].isNullOrBlank()}}
  .map{line->values.entries.fold(line){acc,(k,v)->acc.replace(k,v)}}
  .joinToString("\n")
  .replace(Regex("\n{3,}"),"\n\n")
  .trim()
}
fun messageFor(s:Sub,t:Templates):String{
 val state=BusinessStateEngine.client(s)
 val template=when(state.state){
  ClientOperationState.OVERDUE->t.expired
  ClientOperationState.DUE_TODAY->t.due0
  ClientOperationState.DUE_TOMORROW->t.due1
  ClientOperationState.PROMISE_DUE,ClientOperationState.WAITING->t.promise
  else->t.due3
 }
 return fillTemplate(template,s)
}
fun wa(c:Context,s:Sub,msg:String){val u="https://wa.me/${s.phone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun ScreenHeader(title:String,subtitle:String){Column(verticalArrangement=Arrangement.spacedBy(4.dp)){Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black);Text(subtitle,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun SectionTitle(title:String,subtitle:String=""){Column(Modifier.padding(top=4.dp,bottom=2.dp)){Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);if(subtitle.isNotBlank())Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun MetricCard(label:String,value:String,accent:Color,modifier:Modifier=Modifier,icon:ImageVector?=null){
 val shape=RoundedCornerShape(18.dp)
 Card(modifier.border(1.dp,accent.copy(alpha=.45f),shape),shape=shape,colors=CardDefaults.cardColors(containerColor=accent.copy(alpha=.10f))){
  Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
   if(icon!=null)Surface(shape=RoundedCornerShape(50),color=accent.copy(alpha=.18f)){Box(Modifier.size(38.dp),contentAlignment=Alignment.Center){Icon(icon,contentDescription=null,tint=accent,modifier=Modifier.size(22.dp))}}
   Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(value,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Black,color=accent,maxLines=1);Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurface,maxLines=2)}
  }
 }
}
@Composable fun InfoBanner(title:String,body:String,accent:Color=StreamCyan){Surface(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),color=accent.copy(alpha=.09f)){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){Text(title,fontWeight=FontWeight.Bold,color=accent);Text(body,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
@Composable fun StatusBadge(label:String,color:Color){Surface(shape=RoundedCornerShape(50),color=color.copy(alpha=.16f),contentColor=color,border=BorderStroke(1.dp,color.copy(alpha=.40f))){Text(label,Modifier.padding(horizontal=9.dp,vertical=4.dp),style=MaterialTheme.typography.labelSmall,fontWeight=FontWeight.Bold)}}
@Composable fun EmptyState(text:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.35f))){Text(text,Modifier.padding(16.dp),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun InsightRow(label:String,value:String,accent:Color=MaterialTheme.colorScheme.onSurface,detail:String=""){Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(3.dp)){Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,color=accent,maxLines=2);if(detail.isNotBlank())Text(detail,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}

@Composable fun Home(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,services:List<ServiceTemplate>,wa:(Sub)->Unit,renew:(Sub,Long,String,Int)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val active=s.filter{it.status!="CORTADO"}
 val states=active.associateWith{BusinessStateEngine.client(it)}
 val expired=states.values.count{it.state==ClientOperationState.OVERDUE}
 val today=states.values.count{it.state==ClientOperationState.DUE_TODAY}
 val tomorrow=states.values.count{it.state==ClientOperationState.DUE_TOMORROW}
 val upcoming=states.values.count{it.state==ClientOperationState.UPCOMING_2_3}
 val promiseDue=states.values.count{it.state==ClientOperationState.PROMISE_DUE}
 val available=stock.count{effectiveStockStatus(it)=="DISPONIBLE"}
 val accounts=providerAccounts(s,stock,h)
 val providerDueAccounts=accounts.filter{BusinessStateEngine.providerNeedsImmediateAction(BusinessStateEngine.provider(it.end))}
 val providerDue=providerDueAccounts.size
 val month=monthPrefix()
 val salesMonth=h.filter{it.date.startsWith(month)&&isSaleIncome(it)}.sumOf{it.amount}
 val providerRenewMonth=h.filter{it.date.startsWith(month)&&it.action.contains("RENOVACIÓN PROVEEDOR")}.sumOf{it.amount}
 val investedMonth=monthlyAccountCosts(s,stock)+providerRenewMonth
 val cashBalance=salesMonth-investedMonth
 val work=active.filter{BusinessStateEngine.requiresAction(states.getValue(it))}.distinctBy{it.id}.sortedWith(compareBy<Sub>{BusinessStateEngine.priority(states.getValue(it))}.thenBy{states.getValue(it).daysToPromise?:states.getValue(it).daysToEnd?:9999})
 val toCollect=work.sumOf{it.price}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Operación de hoy","Todo lo que requiere atención usa una sola regla de estados")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){MetricCard("Clientes vencidos",expired.toString(),StreamRed,Modifier.weight(1f),Icons.Default.Warning);MetricCard("Vencen hoy",today.toString(),StreamYellow,Modifier.weight(1f),Icons.Default.Event)}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){MetricCard("Mañana",tomorrow.toString(),Color(0xFF91A6B8),Modifier.weight(1f),Icons.Default.Schedule);MetricCard("Próximos 2–3 días",upcoming.toString(),StreamCyan,Modifier.weight(1f),Icons.Default.Event)}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){MetricCard("Accesos disponibles",available.toString(),StreamBlue,Modifier.weight(1f),Icons.Default.Inventory2);MetricCard("Proveedor por renovar",providerDue.toString(),StreamAmber,Modifier.weight(1f),Icons.Default.Event)}}
  item{SectionTitle("Dinero","Caja del mes, sin confundir inversión con pérdida")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){MetricCard("Por cobrar",money(toCollect),StreamCyan,Modifier.weight(1f),Icons.Default.AccountBalanceWallet);MetricCard("Cobrado este mes",money(salesMonth),StreamBlue,Modifier.weight(1f),Icons.Default.TrendingUp)}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){MetricCard("Invertido este mes",money(investedMonth),StreamRed,Modifier.weight(1f),Icons.Default.Payments);MetricCard("Balance de caja",money(cashBalance),if(cashBalance>=0)StreamGreen else StreamRed,Modifier.weight(1f),Icons.Default.TrendingUp)}}
  if(providerDue>0){item{SectionTitle("Atención proveedor","Incluye cuentas próximas y cuentas ya vencidas")};items(providerDueAccounts.sortedBy{BusinessStateEngine.provider(it.end).daysToEnd?:9999}.take(5)){a->ProviderAccountAlert(a)}}
  if(promiseDue>0)item{InfoBanner("Promesas de pago","$promiseDue cliente${if(promiseDue==1)"" else "s"} tienen una promesa vencida o para hoy.",StreamPurple)}
  item{SectionTitle("Clientes por gestionar · ${work.size}","Solo aparecen los que requieren una acción ahora")}
  if(work.isEmpty())item{EmptyState("Todo al día. No tienes clientes que requieran gestión ahora.")}
  items(work.take(20)){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}
 }
}
@Composable fun ProviderAccountAlert(a:ProviderAccountSummary){
 val snapshot=BusinessStateEngine.provider(a.end);val overdue=snapshot.state==ProviderOperationState.OVERDUE;val accent=if(overdue)StreamRed else StreamAmber
 Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=accent.copy(alpha=.08f))){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(a.service,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge(BusinessStateEngine.providerLabel(snapshot),accent)};Text(a.account,style=MaterialTheme.typography.bodySmall);Text("${providerDisplayName(a.provider)} • ${if(overdue)"venció" else "vence"} ${a.end} • renovar ${money(a.renewCost)}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
}

@Composable fun ProviderDueCard(s:Sub){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(s.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("Corte ${s.accountEnd.ifBlank{"sin fecha"}}",StreamRed)};Text(s.account,style=MaterialTheme.typography.bodyMedium);Text("Proveedor · ${providerDisplayName(s.provider.ifBlank{"Sin asignar"})}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Renovación ${money(s.accountRenewCost)}",fontWeight=FontWeight.SemiBold)}}}

@Composable fun ProviderDueStockCard(x:StockItem){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(x.service,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));StatusBadge("Corte ${x.accountEnd.ifBlank{"sin fecha"}}",StreamRed)};Text(x.account,style=MaterialTheme.typography.bodyMedium);Text("Proveedor · ${providerDisplayName(x.provider.ifBlank{"Sin asignar"})}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Costo de renovar ${money(x.accountRenewCost)}",fontWeight=FontWeight.SemiBold);StatusBadge(if(effectiveStockStatus(x)=="DISPONIBLE")"STOCK DISPONIBLE" else effectiveStockStatus(x).replace('_',' '),if(effectiveStockStatus(x)=="DISPONIBLE")StreamBlue else StreamRed)}}}

@Composable fun Renewals(s:List<Sub>,wa:(Sub)->Unit,renew:(Sub,Long,String,Int)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 val visible=s.filter{it.status!="CORTADO"}
 val states=visible.associateWith{BusinessStateEngine.client(it)}
 val expired=visible.filter{states.getValue(it).state==ClientOperationState.OVERDUE}
 val dueToday=visible.filter{states.getValue(it).state==ClientOperationState.DUE_TODAY}
 val dueTomorrow=visible.filter{states.getValue(it).state==ClientOperationState.DUE_TOMORROW}
 val upcoming=visible.filter{states.getValue(it).state==ClientOperationState.UPCOMING_2_3}
 val promiseDue=visible.filter{states.getValue(it).state==ClientOperationState.PROMISE_DUE}
 val waiting=visible.filter{states.getValue(it).state==ClientOperationState.WAITING}
 val groups=listOf("Vencidos" to expired,"Promesas hoy" to promiseDue,"Hoy" to dueToday,"Mañana" to dueTomorrow,"Próximos 2–3 días" to upcoming,"En espera" to waiting)
 val total=groups.sumOf{it.second.size};var quick by remember{mutableStateOf(false)}
 val queue=visible.filter{BusinessStateEngine.requiresAction(states.getValue(it))}.sortedWith(compareBy<Sub>{BusinessStateEngine.priority(states.getValue(it))}.thenBy{states.getValue(it).daysToPromise?:states.getValue(it).daysToEnd?:9999})
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{ScreenHeader("Renovaciones","Los mismos estados de Inicio, recordatorios y reportes")}
  if(queue.isNotEmpty())item{Button({quick=true},Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=StreamCyan,contentColor=Color(0xFF001317))){Icon(Icons.Default.Chat,contentDescription=null);Spacer(Modifier.width(8.dp));Text("Cobranza rápida · ${queue.size} ${if(queue.size==1)"pendiente" else "pendientes"}",fontWeight=FontWeight.Bold)}}
  item{LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){
   item{RenewalChip("Vencidos",expired.size,StreamRed)}
   item{RenewalChip("Promesas",promiseDue.size,StreamPurple)}
   item{RenewalChip("Hoy",dueToday.size,StreamYellow)}
   item{RenewalChip("Mañana",dueTomorrow.size,Color(0xFF91A6B8))}
   item{RenewalChip("2–3 días",upcoming.size,StreamCyan)}
   item{RenewalChip("En espera",waiting.size,StreamPurple)}
  }}
  if(total==0)item{EmptyState("Todo al día. No hay clientes pendientes de renovación.")}
  groups.filter{it.second.isNotEmpty()}.forEach{(title,list)->item{SectionTitle(title,"${list.size} cliente${if(list.size==1)"" else "s"}")};items(list.sortedWith(compareBy<Sub>{BusinessStateEngine.priority(states.getValue(it))}.thenBy{states.getValue(it).daysToPromise?:states.getValue(it).daysToEnd?:9999})){ActionCard(it,wa,renew,cut,adjust,promise,contact,edit)}}
 }
 if(quick)QuickCollectionDialog(queue,{quick=false},wa,contact,renew)
}

@Composable fun ActionCard(s:Sub,wa:(Sub)->Unit,renew:(Sub,Long,String,Int)->Unit,cut:(Sub,String)->Unit,adjust:(Sub,String,String)->Unit,promise:(Sub,String)->Unit,contact:(Sub)->Unit,edit:(Sub)->Unit){
 var showAdjust by remember(s.id){mutableStateOf(false)};var showEnd by remember(s.id){mutableStateOf(false)};var showPromise by remember(s.id){mutableStateOf(false)};var showRenew by remember(s.id){mutableStateOf(false)};var more by remember(s.id){mutableStateOf(false)};val ctx=LocalContext.current
 val snapshot=BusinessStateEngine.client(s)
 val status=BusinessStateEngine.clientLabel(snapshot)
 val color=when(snapshot.state){
  ClientOperationState.OVERDUE->StreamRed
  ClientOperationState.DUE_TODAY->StreamYellow
  ClientOperationState.DUE_TOMORROW->Color(0xFF91A6B8)
  ClientOperationState.UPCOMING_2_3->StreamCyan
  ClientOperationState.PROMISE_DUE,ClientOperationState.WAITING->StreamPurple
  ClientOperationState.INVALID_DATE->StreamAmber
  else->StreamGreen
 }
 val canGivePromise=snapshot.state in setOf(ClientOperationState.OVERDUE,ClientOperationState.DUE_TODAY,ClientOperationState.PROMISE_DUE)
 val canFinalize=canGivePromise
 Card(Modifier.fillMaxWidth().border(1.dp,color.copy(alpha=.28f),RoundedCornerShape(18.dp)),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(s.client,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text(s.service,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(status,color)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vence ${s.end}",style=MaterialTheme.typography.bodyMedium);Text(money(s.price),fontWeight=FontWeight.Bold)}
  Text(s.type,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.account.isNotBlank())Text(s.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.profile.isNotBlank())Text("Perfil ${s.profile}${if(s.pin.isNotBlank())"  ·  PIN guardado" else ""}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  if(s.contacted)StatusBadge(contactLabel(s.lastContact),StreamGreen)
  if(snapshot.state==ClientOperationState.WAITING&&s.promiseDate.isNotBlank())Surface(shape=RoundedCornerShape(10.dp),color=StreamPurple.copy(alpha=.10f)){Text("En espera hasta ${s.promiseDate}. No vuelve a Trabajo de hoy antes de esa fecha.",Modifier.padding(9.dp),style=MaterialTheme.typography.bodySmall,color=StreamPurple)}
  else if(s.promiseDate.isNotBlank())Surface(shape=RoundedCornerShape(10.dp),color=StreamPurple.copy(alpha=.10f)){Text("Promesa de pago · ${s.promiseDate}",Modifier.padding(9.dp),style=MaterialTheme.typography.bodySmall,color=StreamPurple)}
  Button({wa(s);contact(s)},modifier=Modifier.fillMaxWidth()){Text("Abrir WhatsApp")}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({showRenew=true},modifier=Modifier.weight(1f)){Text("Renovar")};if(canGivePromise)OutlinedButton({showPromise=true},modifier=Modifier.weight(1f)){Text("Dar plazo")}}
  if(canFinalize)TextButton({showEnd=true},colors=ButtonDefaults.textButtonColors(contentColor=StreamRed),modifier=Modifier.fillMaxWidth()){Text("No renovó",fontWeight=FontWeight.Bold)}
  TextButton({more=!more},modifier=Modifier.fillMaxWidth()){Text(if(more)"Ocultar" else "Editar / credenciales")}
  if(more){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);OutlinedButton({wa(ctx,s,fillTemplate(Store(ctx).templates().delivery,s))},modifier=Modifier.fillMaxWidth()){Text("Enviar credenciales")};OutlinedButton({edit(s)},modifier=Modifier.fillMaxWidth()){Text("Editar entrega / cuenta")};OutlinedButton({showAdjust=true},modifier=Modifier.fillMaxWidth()){Text("Ajustar vencimiento")}}
 }}
 if(showAdjust)AdjustEndDialog(s,{showAdjust=false}){date,reason->adjust(s,date,reason);showAdjust=false};if(showEnd)EndServiceDialog(s,{showEnd=false}){reason->cut(s,reason);showEnd=false};if(showPromise)PromiseDialog(s,{showPromise=false}){date->promise(s,date);showPromise=false};if(showRenew)RenewClientDialog(s,{showRenew=false}){price,method,duration->renew(s,price,method,duration);showRenew=false}
}

@Composable fun Accounts(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,services:List<ServiceTemplate>,saveStock:(List<StockItem>)->Unit,addStockItems:(List<StockItem>)->Unit,sell:(Sub,StockItem)->Unit,renew:(Sub,Long,String,Int)->Unit,cut:(Sub,String)->Unit,contact:(Sub)->Unit,syncAccount:(String,StockItem)->Unit,adjust:(Sub,String,String)->Unit,edit:(Sub)->Unit){
 val ctx=LocalContext.current;val st=remember{Store(ctx)};var section by remember{mutableStateOf("STOCK")};var addStock by remember{mutableStateOf(false)};var selling by remember{mutableStateOf<StockItem?>(null)};var editingStock by remember{mutableStateOf<StockItem?>(null)};var editingProfileAccountKey by remember{mutableStateOf<String?>(null)}
 var occupiedProfile by remember{mutableStateOf<Pair<StockItem,Sub>?>(null)};var blockedProfile by remember{mutableStateOf<StockItem?>(null)};var endingProfileSub by remember{mutableStateOf<Sub?>(null)}
 var query by remember{mutableStateOf("")};var stockFilter by remember{mutableStateOf("Todos")};var activeFilter by remember{mutableStateOf("Todos")};var expandedStockId by remember{mutableStateOf<Long?>(null)};var expandedProfileKey by remember{mutableStateOf<String?>(null)};var expandedActiveKey by remember{mutableStateOf<String?>(null)}
 val active=s.filter{it.status!="CORTADO"};val grouped=active.filter{it.account.isNotBlank()}.groupBy{"${providerKey(it.provider)}|${it.service.trim().lowercase()}|${accountKey(it.account)}"};val completeDelivered=active.count{isComplete(it)};val profileOccupied=active.count{!isComplete(it)}
 val completeStockAll=stock.filter{isComplete(it)&&it.status!="ENTREGADA"&&it.status!="OCUPADO"}
 val profileStockAll=stock.filter{!isComplete(it)}
 val profileGroups=profileStockAll.groupBy{profileStockGroupKey(it)}
 val availableComplete=completeStockAll.count{effectiveStockStatus(it)=="DISPONIBLE"};val availableProfiles=profileStockAll.count{effectiveStockStatus(it)=="DISPONIBLE"};val unavailable=stock.count{effectiveStockStatus(it)=="NO_DISPONIBLE"}
 val q=query.trim()
 val filteredComplete=completeStockAll.filter{x->
  val matches=q.isBlank()||listOf(x.service,x.account,x.provider).any{it.contains(q,true)}
  val statusOk=when(stockFilter){"Disponibles"->effectiveStockStatus(x)=="DISPONIBLE";"Sin libres"->effectiveStockStatus(x)!="DISPONIBLE";else->true}
  matches&&statusOk
 }.sortedWith(compareBy<StockItem>{it.service.lowercase()}.thenBy{it.account.lowercase()})
 val filteredProfileGroups=profileGroups.entries.filter{e->
  val base=e.value.first();val relatedSubs=e.value.mapNotNull{x->active.firstOrNull{it.stockId==x.id}}
  val matches=q.isBlank()||listOf(base.service,base.account,base.provider).any{it.contains(q,true)}||e.value.any{it.profile.contains(q,true)}||relatedSubs.any{it.client.contains(q,true)}
  val hasFree=e.value.any{effectiveStockStatus(it)=="DISPONIBLE"}
  val statusOk=when(stockFilter){"Disponibles"->hasFree;"Sin libres"->!hasFree;else->true}
  matches&&statusOk
 }.sortedWith(compareBy<Map.Entry<String,List<StockItem>>>{it.value.first().service.lowercase()}.thenBy{it.value.first().account.lowercase()})
 val activeEntries=grouped.entries.filter{e->
  val base=e.value.first();val matches=q.isBlank()||listOf(base.service,base.account,base.provider).any{it.contains(q,true)}||e.value.any{it.client.contains(q,true)||it.profile.contains(q,true)}
  val anyExpired=e.value.any{days(it)<0};val anyCurrent=e.value.any{days(it)>=0}
  val statusOk=when(activeFilter){"Activas"->anyCurrent;"Vencidas"->anyExpired;else->true}
  matches&&statusOk
 }.sortedWith(compareBy<Map.Entry<String,List<Sub>>>{it.value.first().service.lowercase()}.thenBy{it.value.first().account.lowercase()})
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{ScreenHeader("Stock","Cuentas y perfiles organizados para vender más rápido")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=section=="STOCK",onClick={section="STOCK"},label={Text("Para vender")},modifier=Modifier.weight(1f));FilterChip(selected=section=="ACTIVAS",onClick={section="ACTIVAS"},label={Text("Ya entregadas")},modifier=Modifier.weight(1f))}}
  item{OutlinedTextField(query,{query=it},label={Text("Buscar servicio, correo o cliente")},leadingIcon={Icon(Icons.Default.Search,contentDescription=null)},singleLine=true,modifier=Modifier.fillMaxWidth())}
  if(section=="STOCK"){
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Cuentas",availableComplete.toString(),Modifier.weight(1f),StreamBlue);MiniStat("Perfiles libres",availableProfiles.toString(),Modifier.weight(1f),StreamBlue);MiniStat("No disp.",unavailable.toString(),Modifier.weight(1f),if(unavailable>0)StreamRed else MaterialTheme.colorScheme.onSurfaceVariant)}}
   item{LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Todos","Disponibles","Sin libres")){x->FilterChip(selected=stockFilter==x,onClick={stockFilter=x},label={Text(x)})}}}
   item{Button({addStock=true},Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=StreamCyan,contentColor=Color(0xFF001317))){Text("＋  Agregar cuenta / stock",fontWeight=FontWeight.Bold)}}
   if(filteredComplete.isNotEmpty())item{Text("CUENTAS COMPLETAS",style=MaterialTheme.typography.labelLarge,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurfaceVariant)}
   items(filteredComplete,key={it.id}){x->
    val salePrice=services.firstOrNull{it.name.equals(x.service,true)}?.defaultPrice?:0L
    CompactStockRow(x,salePrice,expandedStockId==x.id,{expandedStockId=if(expandedStockId==x.id)null else x.id},{selling=x},{editingStock=x},{saveStock(stock.map{if(it.id==x.id)it.copy(status=if(effectiveStockStatus(it)=="NO_DISPONIBLE")"DISPONIBLE" else "NO_DISPONIBLE")else it})})
   }
   if(filteredProfileGroups.isNotEmpty())item{Text("CUENTAS POR PERFILES",style=MaterialTheme.typography.labelLarge,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurfaceVariant)}
   items(filteredProfileGroups,key={it.key}){e->
    ProfileAccountStockCard(
     key=e.key,
     items=e.value,
     activeSubs=active,
     expanded=expandedProfileKey==e.key,
     toggleExpand={expandedProfileKey=if(expandedProfileKey==e.key)null else e.key},
     assign={selling=it},
     openOccupied={item,sub->occupiedProfile=item to sub},
     openBlocked={blockedProfile=it},
     editAccount={editingProfileAccountKey=e.key}
    )
   }
   if(filteredComplete.isEmpty()&&filteredProfileGroups.isEmpty())item{EmptyState(if(q.isBlank())"No hay accesos con este filtro." else "No encontramos '$q' en el stock.")}
  }else{
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Cuentas entregadas",completeDelivered.toString(),Modifier.weight(1f),StreamBlue);MiniStat("Perfiles ocupados",profileOccupied.toString(),Modifier.weight(1f),StreamPurple);MiniStat("Perfiles libres",availableProfiles.toString(),Modifier.weight(1f),StreamCyan)}}
   item{LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Todos","Activas","Vencidas")){x->FilterChip(selected=activeFilter==x,onClick={activeFilter=x},label={Text(x)})}}}
   if(activeEntries.isEmpty())item{EmptyState(if(q.isBlank())"No hay cuentas entregadas con este filtro." else "No encontramos '$q' entre las cuentas entregadas.")}
   items(activeEntries,key={it.key}){e->
    val firstSlot=e.value.asSequence().mapNotNull{sub->stock.firstOrNull{it.id==sub.stockId}}.firstOrNull()
    val profileSlots=if(e.value.all{isComplete(it)}) emptyList() else when{
     firstSlot?.masterId?.isNotBlank()==true->stock.filter{!isComplete(it)&&it.masterId==firstSlot.masterId}
     firstSlot!=null->stock.filter{!isComplete(it)&&sameProvider(it.provider,firstSlot.provider)&&it.service.equals(firstSlot.service,true)&&accountKey(it.account)==accountKey(firstSlot.account)}
     else->stock.filter{!isComplete(it)&&sameProvider(it.provider,e.value.first().provider)&&it.service.equals(e.value.first().service,true)&&accountKey(it.account)==accountKey(e.value.first().account)}
    }
    CompactActiveAccountCard(
     key=e.key,
     members=e.value,
     profileSlots=profileSlots,
     activeSubs=active,
     expanded=expandedActiveKey==e.key,
     toggleExpand={expandedActiveKey=if(expandedActiveKey==e.key)null else e.key},
     credentials={x->wa(ctx,x,fillTemplate(st.templates().delivery,x))},
     edit={x->edit(x)},
     assign={selling=it},
     openOccupied={item,sub->occupiedProfile=item to sub},
     openBlocked={blockedProfile=it}
    )
   }
  }
 }
 if(addStock)AddStockDialog(services,{addStock=false}){items->addStockItems(items);addStock=false}
 selling?.let{item->SellStockDialog(item,services,st.clients(),{selling=null}){sub->sell(sub,item);selling=null}}
 editingStock?.let{item->EditStockDialog(item,{editingStock=null}){updated->saveStock(stock.map{if(it.id==updated.id)updated else it});editingStock=null}}
 editingProfileAccountKey?.let{groupKey->
  val group=stock.filter{!isComplete(it)&&profileStockGroupKey(it)==groupKey}
  val base=group.firstOrNull()
  if(base!=null)EditProfileAccountDialog(base,{editingProfileAccountKey=null}){updated->
   syncAccount(groupKey,updated)
   editingProfileAccountKey=null
  } else editingProfileAccountKey=null
 }
 occupiedProfile?.let{pair->val item=pair.first;val sub=pair.second;OccupiedProfileDialog(item,sub,{occupiedProfile=null},{wa(ctx,sub,fillTemplate(st.templates().delivery,sub))},{wa(ctx,sub,messageFor(sub,st.templates()));contact(sub)},renew,{occupiedProfile=null;edit(sub)},{occupiedProfile=null;endingProfileSub=sub})}
 blockedProfile?.let{item->BlockedProfileDialog(item,{blockedProfile=null},{saveStock(stock.map{if(it.id==item.id)it.copy(status="DISPONIBLE")else it});blockedProfile=null},{blockedProfile=null;editingProfileAccountKey=profileStockGroupKey(item)})}
 endingProfileSub?.let{sub->EndServiceDialog(sub,{endingProfileSub=null}){reason->cut(sub,reason);endingProfileSub=null}}
}

fun profileStockGroupKey(x:StockItem)=x.masterId.ifBlank{"${providerKey(x.provider)}|${x.service.trim().lowercase()}|${accountKey(x.account)}"}

@Composable fun ProfileAccountStockCard(key:String,items:List<StockItem>,activeSubs:List<Sub>,expanded:Boolean,toggleExpand:()->Unit,assign:(StockItem)->Unit,openOccupied:(StockItem,Sub)->Unit,openBlocked:(StockItem)->Unit,editAccount:()->Unit){
 val base=items.first();val ordered=items.sortedBy{it.profile.lowercase()};val free=ordered.count{effectiveStockStatus(it)=="DISPONIBLE"};val occupied=ordered.count{it.status=="OCUPADO"};val blocked=ordered.count{effectiveStockStatus(it)=="NO_DISPONIBLE"};val dueDays=stockAccountDays(base);val dueColor=when{dueDays<0->StreamRed;dueDays<=7->StreamAmber;else->StreamGreen}
 Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.46f))){
  Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
   Row(Modifier.fillMaxWidth().clickable{toggleExpand()},verticalAlignment=Alignment.CenterVertically){
    Column(Modifier.weight(1f)){Text(base.service,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium,maxLines=1);Text(base.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)}
    StatusBadge(if(free>0)"$free LIBRE${if(free==1)"" else "S"}" else "SIN LIBRES",if(free>0)StreamBlue else StreamRed)
   }
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
    Column(Modifier.weight(1f)){Text("Credenciales",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Clave: ${base.password.ifBlank{"Sin clave"}}",style=MaterialTheme.typography.bodySmall,maxLines=1)}
    Column(horizontalAlignment=Alignment.End){Text("Vence proveedor",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(base.accountEnd.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.Bold,color=dueColor)}
   }
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Perfiles",ordered.size.toString(),Modifier.weight(1f),StreamBlue);MiniStat("Libres",free.toString(),Modifier.weight(1f),StreamBlue);MiniStat("Ocupados",occupied.toString(),Modifier.weight(1f),StreamPurple)}
   Text("${ordered.size} perfil${if(ordered.size==1)"" else "es"} · $free libre${if(free==1)"" else "s"} · $occupied ocupado${if(occupied==1)"" else "s"}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
   if(free>0)Text("Toca un perfil libre para asignarlo.",style=MaterialTheme.typography.labelSmall,color=StreamCyan)
   ProfileTilesGrid(ordered,activeSubs,assign,openOccupied,openBlocked)
   if(expanded){
    HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Proveedor",style=MaterialTheme.typography.bodySmall);Text(providerDisplayName(base.provider.ifBlank{"Sin proveedor"}),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Compra",style=MaterialTheme.typography.bodySmall);Text(base.purchaseDate.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Costo cuenta",style=MaterialTheme.typography.bodySmall);Text(money(base.accountCost),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.Bold)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Renovar proveedor",style=MaterialTheme.typography.bodySmall);Text(money(base.accountRenewCost),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.Bold)}
    if(blocked>0)Text("$blocked perfil${if(blocked==1)"" else "es"} no disponible${if(blocked==1)"" else "s"}",style=MaterialTheme.typography.bodySmall,color=StreamRed)
    OutlinedButton(editAccount,Modifier.fillMaxWidth()){Text("Editar cuenta")}
   }
  }
 }
}

@Composable fun ProfileTilesGrid(items:List<StockItem>,activeSubs:List<Sub>,assign:(StockItem)->Unit,openOccupied:(StockItem,Sub)->Unit,openBlocked:(StockItem)->Unit){
 val ordered=items.sortedBy{it.profile.lowercase()}
 ordered.chunked(3).forEach{rowItems->
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
   rowItems.forEach{p->
    val sub=activeSubs.firstOrNull{it.stockId==p.id&&it.status!="CORTADO"}
    ProfileAccessTile(p,sub,Modifier.weight(1f)){
     when{
      sub!=null->openOccupied(p,sub)
      p.status=="OCUPADO"->openBlocked(p)
      effectiveStockStatus(p)=="NO_DISPONIBLE"->openBlocked(p)
      else->assign(p)
     }
    }
   }
   repeat(3-rowItems.size){Spacer(Modifier.weight(1f))}
  }
  Spacer(Modifier.height(7.dp))
 }
}

@Composable fun ProfileAccessTile(x:StockItem,sub:Sub?,modifier:Modifier=Modifier,onClick:()->Unit){
 val status=effectiveStockStatus(x);val occupied=x.status=="OCUPADO"||sub!=null;val providerProblem=status=="NO_DISPONIBLE";val color=when{providerProblem->StreamRed;occupied->StreamPurple;else->StreamCyan};val label=when{occupied->"OCUPADO";providerProblem->"NO DISP.";else->"LIBRE"}
 Surface(
  modifier=modifier.clickable{onClick()},
  shape=RoundedCornerShape(13.dp),
  color=color.copy(alpha=.10f),
  border=BorderStroke(1.dp,color.copy(alpha=.58f))
 ){
  Column(Modifier.fillMaxWidth().padding(horizontal=7.dp,vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(3.dp)){
   Icon(Icons.Default.Person,contentDescription=null,tint=color,modifier=Modifier.size(24.dp))
   Text(x.profile.ifBlank{"Perfil"},style=MaterialTheme.typography.labelMedium,fontWeight=FontWeight.Bold,maxLines=1)
   Text(label,style=MaterialTheme.typography.labelSmall,color=color,fontWeight=FontWeight.Bold,maxLines=1)
   if(sub!=null){
    Text(sub.client,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
    Text("Vence ${shortDate(sub.end)}",style=MaterialTheme.typography.labelSmall,color=if(days(sub)<0)StreamRed else MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
   }
  }
 }
}

fun shortDate(value:String):String=runCatching{
 val d=LocalDate.parse(value)
 val months=listOf("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic")
 "${d.dayOfMonth} ${months[d.monthValue-1]}"
}.getOrDefault(value)

@Composable fun OccupiedProfileDialog(item:StockItem,sub:Sub,close:()->Unit,sendData:()->Unit,charge:()->Unit,renew:(Sub,Long,String,Int)->Unit,edit:()->Unit,finish:()->Unit){
 val phoneOk=sub.phone.filter{it.isDigit()}.isNotBlank();val expired=days(sub)<0;var showPin by remember(item.id){mutableStateOf(false)};var showRenew by remember(item.id){mutableStateOf(false)}
 AlertDialog(
  onDismissRequest=close,
  title={Text("Perfil ocupado")},
  text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){
   Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(item.service,fontWeight=FontWeight.Bold);Text(item.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(expired)"VENCIDO" else "ACTIVO",if(expired)StreamRed else StreamGreen)}
   Surface(shape=RoundedCornerShape(12.dp),color=StreamPurple.copy(alpha=.08f)){Column(Modifier.fillMaxWidth().padding(10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){Text("Cliente",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(sub.client,fontWeight=FontWeight.Bold);Text("${item.profile.ifBlank{sub.profile.ifBlank{"Perfil"}}}${if(item.pin.isNotBlank())"  ·  PIN ${if(showPin)item.pin else "••••"}" else ""}",style=MaterialTheme.typography.bodyMedium);if(item.pin.isNotBlank())TextButton({showPin=!showPin},contentPadding=PaddingValues(0.dp)){Text(if(showPin)"Ocultar PIN" else "Ver PIN")};Text("Vence cliente: ${sub.end}",style=MaterialTheme.typography.bodySmall);Text("Precio: ${money(sub.price)}",style=MaterialTheme.typography.bodySmall);if(sub.phone.isNotBlank())Text("WhatsApp: ${sub.phone}",style=MaterialTheme.typography.bodySmall)}}
   OutlinedButton(sendData,Modifier.fillMaxWidth(),enabled=phoneOk){Text("Enviar datos")}
   Button(charge,Modifier.fillMaxWidth(),enabled=phoneOk){Text("Cobrar por WhatsApp")}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({showRenew=true},Modifier.weight(1f)){Text("Renovar")};OutlinedButton(edit,Modifier.weight(1f)){Text("Editar")}}
   TextButton(finish,Modifier.fillMaxWidth(),colors=ButtonDefaults.textButtonColors(contentColor=StreamRed)){Text("No renovó / finalizar",fontWeight=FontWeight.Bold)}
  }},
  confirmButton={},
  dismissButton={TextButton(close){Text("Cerrar")}}
 )
 if(showRenew)RenewClientDialog(sub,{showRenew=false}){price,method,duration->renew(sub,price,method,duration);showRenew=false;close()}
}

@Composable fun BlockedProfileDialog(item:StockItem,close:()->Unit,enable:()->Unit,editAccount:()->Unit){
 val providerExpired=item.accountEnd.isNotBlank()&&runCatching{LocalDate.parse(item.accountEnd).isBefore(LocalDate.now())}.getOrDefault(false)
 AlertDialog(onDismissRequest=close,title={Text("Perfil no disponible")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text(item.service,fontWeight=FontWeight.Bold);Text("${item.profile.ifBlank{"Perfil"}} · ${item.account}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);if(providerExpired)Text("La cuenta del proveedor venció el ${item.accountEnd}. Primero actualiza o renueva la cuenta principal.",color=StreamRed,style=MaterialTheme.typography.bodySmall)else Text("Este perfil está marcado como no disponible. Puedes habilitarlo cuando vuelva a estar listo para vender.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);if(!providerExpired)Button(enable,Modifier.fillMaxWidth()){Text("Habilitar perfil")};OutlinedButton(editAccount,Modifier.fillMaxWidth()){Text(if(providerExpired)"Revisar cuenta principal" else "Editar cuenta")}}},confirmButton={},dismissButton={TextButton(close){Text("Cerrar")}})
}

@Composable fun CompactStockRow(x:StockItem,salePrice:Long,expanded:Boolean,toggleExpand:()->Unit,sell:()->Unit,edit:()->Unit,toggleStatus:()->Unit){
 val status=effectiveStockStatus(x);val color=if(status=="DISPONIBLE")StreamBlue else StreamRed;val expectedProfit=if(salePrice>0)salePrice-x.accountCost else 0L
 Card(Modifier.fillMaxWidth().clickable{toggleExpand()},shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.48f))){Column(Modifier.padding(horizontal=12.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(x.service,fontWeight=FontWeight.Bold,maxLines=1);Text(x.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)};StatusBadge(status.replace('_',' '),color)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(if(isComplete(x))"Cuenta completa" else "Perfil ${x.profile.ifBlank{"sin nombre"}}",style=MaterialTheme.typography.labelMedium);Text(providerDisplayName(x.provider.ifBlank{"Sin proveedor"}),style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Text("Costo ${money(x.accountCost)}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);if(salePrice>0)Text("Venta ${money(salePrice)}",style=MaterialTheme.typography.labelSmall,color=StreamBlue);if(salePrice>0)Text("Gana ${money(expectedProfit)}",style=MaterialTheme.typography.labelSmall,color=if(expectedProfit>=0)StreamGreen else StreamRed)}
  if(status=="DISPONIBLE")Button(sell,Modifier.fillMaxWidth().heightIn(min=40.dp),colors=ButtonDefaults.buttonColors(containerColor=StreamCyan,contentColor=Color(0xFF001317))){Text(if(isComplete(x))"Vender" else "Asignar perfil",fontWeight=FontWeight.Bold)}
  if(expanded){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Text("Compra ${x.purchaseDate.ifBlank{"Sin fecha"}}  ·  Vence proveedor ${x.accountEnd.ifBlank{"Sin fecha"}}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("Renovar cuenta ${money(x.accountRenewCost)}${if(x.password.isNotBlank())"  ·  Contraseña guardada" else ""}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(edit,Modifier.weight(1f)){Text("Editar")};OutlinedButton(toggleStatus,Modifier.weight(1f)){Text(if(status=="NO_DISPONIBLE")"Habilitar" else "No disponible")}}}
 }}
}

@Composable fun CompactActiveAccountCard(
 key:String,
 members:List<Sub>,
 profileSlots:List<StockItem>,
 activeSubs:List<Sub>,
 expanded:Boolean,
 toggleExpand:()->Unit,
 credentials:(Sub)->Unit,
 edit:(Sub)->Unit,
 assign:(StockItem)->Unit,
 openOccupied:(StockItem,Sub)->Unit,
 openBlocked:(StockItem)->Unit
){
 val ctx=LocalContext.current
 val base=members.first()
 val complete=members.all{isComplete(it)}
 val cost=members.maxOfOrNull{it.accountCost}?:0L
 val income=members.sumOf{it.price}
 val profit=income-cost
 val expired=members.count{days(it)<0}
 val nearest=members.minByOrNull{runCatching{LocalDate.parse(it.end)}.getOrDefault(LocalDate.MAX)}?.end.orEmpty()

 if(!complete&&profileSlots.isNotEmpty()){
  val ordered=profileSlots.sortedBy{it.profile.lowercase()}
  val free=ordered.count{effectiveStockStatus(it)=="DISPONIBLE"}
  val occupied=ordered.count{slot->activeSubs.any{it.stockId==slot.id&&it.status!="CORTADO"}||slot.status=="OCUPADO"}
  val blocked=ordered.count{effectiveStockStatus(it)=="NO_DISPONIBLE"&&!activeSubs.any{s->s.stockId==it.id&&s.status!="CORTADO"}}
  val dueDays=stockAccountDays(ordered.first())
  val dueColor=when{dueDays<0->StreamRed;dueDays<=7->StreamAmber;else->StreamGreen}
  Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){
   Column(Modifier.padding(horizontal=12.dp,vertical=11.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
    Row(Modifier.fillMaxWidth().clickable{toggleExpand()},verticalAlignment=Alignment.CenterVertically){
     Column(Modifier.weight(1f)){
      Text(base.service,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium,maxLines=1)
      Text(base.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
     }
     StatusBadge(if(free>0)"$free LIBRE${if(free==1)"" else "S"}" else "SIN LIBRES",if(free>0)StreamCyan else StreamPurple)
    }
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
     Text("${ordered.size} perfiles · $free libres · $occupied ocupados",style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)
     Text("Proveedor ${base.accountEnd.ifBlank{"sin fecha"}}",style=MaterialTheme.typography.labelSmall,color=dueColor)
    }
    if(free>0)Text("Toca un perfil libre para asignarlo; toca uno ocupado para administrarlo.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    ProfileTilesGrid(ordered,activeSubs,assign,openOccupied,openBlocked)
    if(expanded){
     HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
      MiniStat("Costo",money(cost),Modifier.weight(1f))
      MiniStat("Ingreso",money(income),Modifier.weight(1f),StreamBlue)
      MiniStat("Ganancia",money(profit),Modifier.weight(1f),if(profit>=0)StreamGreen else StreamRed)
     }
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Proveedor",style=MaterialTheme.typography.bodySmall);Text(providerDisplayName(base.provider.ifBlank{"Sin asignar"}),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vence proveedor",style=MaterialTheme.typography.bodySmall);Text(base.accountEnd.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold,color=dueColor)}
     if(blocked>0)Text("$blocked perfil${if(blocked==1)"" else "es"} no disponible${if(blocked==1)"" else "s"}",style=MaterialTheme.typography.bodySmall,color=StreamRed)
     if(base.providerPhone.isNotBlank())OutlinedButton({waProvider(ctx,base.provider,base.providerPhone,base.account,base.service,base.accountEnd)},Modifier.fillMaxWidth()){Text("Contactar proveedor")}
    }
   }
  }
 }else{
  val statusLabel=when{expired>0->"VENCIDA";else->"ENTREGADA"}
  val statusColor=if(expired>0)StreamRed else StreamCyan
  Card(Modifier.fillMaxWidth().clickable{toggleExpand()},shape=RoundedCornerShape(15.dp)){
   Column(Modifier.padding(horizontal=12.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
     Column(Modifier.weight(1f)){Text(base.service,fontWeight=FontWeight.Bold,maxLines=1);Text(base.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)}
     StatusBadge(statusLabel,statusColor)
    }
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(base.client,style=MaterialTheme.typography.bodyMedium,fontWeight=FontWeight.SemiBold);Text("Vence ${shortDate(base.end)}",style=MaterialTheme.typography.bodySmall,color=if(days(base)<0)StreamRed else MaterialTheme.colorScheme.onSurfaceVariant)}
    if(expanded){
     HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Costo",money(cost),Modifier.weight(1f));MiniStat("Ingreso",money(income),Modifier.weight(1f),StreamBlue);MiniStat("Ganancia",money(profit),Modifier.weight(1f),if(profit>=0)StreamGreen else StreamRed)}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Proveedor",style=MaterialTheme.typography.bodySmall);Text(providerDisplayName(base.provider.ifBlank{"Sin asignar"}),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vence proveedor",style=MaterialTheme.typography.bodySmall);Text(base.accountEnd.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
     if(base.providerPhone.isNotBlank())OutlinedButton({waProvider(ctx,base.provider,base.providerPhone,base.account,base.service,base.accountEnd)},Modifier.fillMaxWidth()){Text("Contactar proveedor")}
     Text("Cliente",fontWeight=FontWeight.Bold)
     members.sortedBy{it.end}.forEach{x->ProfileRow(x,{credentials(x)},{edit(x)})}
    }
   }
  }
 }
}

@Composable fun AddStockDialog(services:List<ServiceTemplate>,close:()->Unit,save:(List<StockItem>)->Unit){
 var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var type by remember{mutableStateOf("PERFIL/PANTALLA")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var purchaseDate by remember{mutableStateOf(LocalDate.now().toString())};var accountEnd by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 var profiles by remember{mutableStateOf(listOf(ProfileDraft(name="Perfil 1",pin="")))}
 fun ensureProfiles(){if(profiles.isEmpty())profiles=listOf(ProfileDraft(name="Perfil 1",pin=""))}
 fun applyTemplate(t:ServiceTemplate){service=t.name;type=t.type;provider=t.provider;providerPhone=t.providerPhone;cost=t.accountCost.toString();renewCost=t.renewCost.toString();if(type=="PERFIL/PANTALLA")ensureProfiles()}
 val validProfiles=profiles.filter{it.name.isNotBlank()};val profilesUnique=OperationRules.uniqueProfileNames(validProfiles.map{it.name});val datesOk=OperationRules.optionalDateRangeValid(purchaseDate,accountEnd);val phoneOk=OperationRules.phoneValidOrBlank(providerPhone)
 AlertDialog(onDismissRequest=close,title={Text("Agregar cuenta / stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
  if(services.isNotEmpty())item{Column{Text("PLANTILLAS RÁPIDAS",fontWeight=FontWeight.Bold);LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(services){t->AssistChip(onClick={applyTemplate(t)},label={Text(t.name)})}}}}
  item{Text("¿CÓMO LA VENDES?",fontWeight=FontWeight.Bold)}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=type=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA";ensureProfiles()},label={Text("Por perfiles")},modifier=Modifier.weight(1f));FilterChip(selected=type=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA"},label={Text("Cuenta completa")},modifier=Modifier.weight(1f))}}
  item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}}
  if(type=="PERFIL/PANTALLA"){
   item{Text("PERFILES DE LA CUENTA",fontWeight=FontWeight.Bold)}
   items(profiles,key={it.id}){draft->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.45f))){Column(Modifier.padding(9.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("Perfil ${profiles.indexOfFirst{it.id==draft.id}+1}",fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f));if(profiles.size>1)TextButton({profiles=profiles.filterNot{it.id==draft.id}},colors=ButtonDefaults.textButtonColors(contentColor=StreamRed)){Text("Quitar")}};F("Nombre del perfil",draft.name){v->profiles=profiles.map{if(it.id==draft.id)it.copy(name=v)else it}};F("PIN / clave (opcional)",draft.pin){v->profiles=profiles.map{if(it.id==draft.id)it.copy(pin=v)else it}}}}}
   item{OutlinedButton({profiles=profiles+ProfileDraft(name="Perfil ${profiles.size+1}",pin="")},Modifier.fillMaxWidth()){Text("＋ Agregar perfil")}}
   if(!profilesUnique)item{Text("Cada perfil debe tener un nombre diferente.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}
  }
  item{Text("COMPRA / PROVEEDOR",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{DateField("Fecha de compra",purchaseDate,{purchaseDate=it},allowBlank=true)};item{DateField("Vence cuenta con proveedor",accountEnd,{accountEnd=it},allowBlank=true)};item{NumericField("Costo de compra",cost){cost=it}};item{NumericField("Costo de renovar cuenta",renewCost){renewCost=it}}
  if(!datesOk)item{Text("El vencimiento del proveedor no puede ser anterior a la fecha de compra.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}
  if(!phoneOk)item{Text("Revisa el WhatsApp del proveedor.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}
 }},confirmButton={Button(enabled=service.isNotBlank()&&account.isNotBlank()&&datesOk&&phoneOk&&profilesUnique&&(type=="CUENTA COMPLETA"||validProfiles.isNotEmpty()),onClick={
   val cleanProvider=normalizedProviderStorage(provider);val cst=OperationRules.amount(cost);val ren=OperationRules.amount(renewCost);val baseId=System.currentTimeMillis();val masterId="master-$baseId"
   val items=if(type=="CUENTA COMPLETA")listOf(StockItem(id=baseId,service=service.trim(),account=account.trim(),password=password,type="CUENTA COMPLETA",provider=cleanProvider,providerPhone=providerPhone.trim(),accountEnd=accountEnd,accountCost=cst,accountRenewCost=ren,status="DISPONIBLE",purchaseDate=purchaseDate,masterId=masterId)) else validProfiles.mapIndexed{idx,p->StockItem(id=baseId+idx,service=service.trim(),account=account.trim(),password=password,profile=p.name.trim(),pin=p.pin,type="PERFIL/PANTALLA",provider=cleanProvider,providerPhone=providerPhone.trim(),accountEnd=accountEnd,accountCost=cst,accountRenewCost=ren,status="DISPONIBLE",purchaseDate=purchaseDate,masterId=masterId)}
   save(items)
  }){Text(if(type=="CUENTA COMPLETA")"Guardar cuenta" else "Guardar ${validProfiles.size} perfil${if(validProfiles.size==1)"" else "es"}")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun EditProfileAccountDialog(x:StockItem,close:()->Unit,save:(StockItem)->Unit){
 var service by remember(x.id){mutableStateOf(x.service)};var account by remember(x.id){mutableStateOf(x.account)};var password by remember(x.id){mutableStateOf(x.password)};var provider by remember(x.id){mutableStateOf(x.provider)};var providerPhone by remember(x.id){mutableStateOf(x.providerPhone)};var purchaseDate by remember(x.id){mutableStateOf(x.purchaseDate)};var accountEnd by remember(x.id){mutableStateOf(x.accountEnd)};var cost by remember(x.id){mutableStateOf(x.accountCost.toString())};var renewCost by remember(x.id){mutableStateOf(x.accountRenewCost.toString())}
 val datesOk=OperationRules.optionalDateRangeValid(purchaseDate,accountEnd);val phoneOk=OperationRules.phoneValidOrBlank(providerPhone)
 AlertDialog(onDismissRequest=close,title={Text("Editar cuenta por perfiles")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){
  item{Text("Estos cambios se aplicarán a todos los perfiles de esta cuenta.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{DateField("Fecha de compra",purchaseDate,{purchaseDate=it},allowBlank=true)};item{DateField("Vence cuenta con proveedor",accountEnd,{accountEnd=it},allowBlank=true)};item{NumericField("Costo de compra",cost){cost=it}};item{NumericField("Costo de renovar cuenta",renewCost){renewCost=it}};if(!datesOk)item{Text("Revisa las fechas del proveedor.",color=StreamRed,style=MaterialTheme.typography.bodySmall)};if(!phoneOk)item{Text("Revisa el WhatsApp del proveedor.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}
 }},confirmButton={Button(enabled=service.isNotBlank()&&account.isNotBlank()&&datesOk&&phoneOk,onClick={save(x.copy(service=service.trim(),account=account.trim(),password=password,provider=normalizedProviderStorage(provider),providerPhone=providerPhone.trim(),accountEnd=accountEnd,accountCost=OperationRules.amount(cost),accountRenewCost=OperationRules.amount(renewCost),purchaseDate=purchaseDate))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun EditStockDialog(x:StockItem,close:()->Unit,save:(StockItem)->Unit){
 var service by remember(x.id){mutableStateOf(x.service)};var account by remember(x.id){mutableStateOf(x.account)};var password by remember(x.id){mutableStateOf(x.password)};var profile by remember(x.id){mutableStateOf(x.profile)};var pin by remember(x.id){mutableStateOf(x.pin)};var type by remember(x.id){mutableStateOf(x.type)};var provider by remember(x.id){mutableStateOf(x.provider)};var providerPhone by remember(x.id){mutableStateOf(x.providerPhone)};var purchaseDate by remember(x.id){mutableStateOf(x.purchaseDate)};var accountEnd by remember(x.id){mutableStateOf(x.accountEnd)};var cost by remember(x.id){mutableStateOf(x.accountCost.toString())};var renewCost by remember(x.id){mutableStateOf(x.accountRenewCost.toString())}
 val datesOk=OperationRules.optionalDateRangeValid(purchaseDate,accountEnd);val phoneOk=OperationRules.phoneValidOrBlank(providerPhone)
 AlertDialog(onDismissRequest=close,title={Text("Editar stock")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=type=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA"},label={Text("Perfil")},modifier=Modifier.weight(1f));FilterChip(selected=type=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA"},label={Text("Cuenta completa")},modifier=Modifier.weight(1f))}};item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};if(type=="PERFIL/PANTALLA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave",pin){pin=it}}};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{DateField("Fecha de compra",purchaseDate,{purchaseDate=it},allowBlank=true)};item{DateField("Vence cuenta con proveedor",accountEnd,{accountEnd=it},allowBlank=true)};item{NumericField("Costo de compra",cost){cost=it}};item{NumericField("Costo de renovar cuenta",renewCost){renewCost=it}};if(!datesOk)item{Text("Revisa las fechas del proveedor.",color=StreamRed,style=MaterialTheme.typography.bodySmall)};if(!phoneOk)item{Text("Revisa el WhatsApp del proveedor.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}
 }},confirmButton={Button(enabled=service.isNotBlank()&&account.isNotBlank()&&datesOk&&phoneOk,onClick={save(x.copy(service=service.trim(),account=account.trim(),password=password,profile=if(type=="CUENTA COMPLETA")"" else profile.trim(),pin=if(type=="CUENTA COMPLETA")"" else pin,type=type,provider=normalizedProviderStorage(provider),providerPhone=providerPhone.trim(),accountEnd=accountEnd,accountCost=OperationRules.amount(cost),accountRenewCost=OperationRules.amount(renewCost),purchaseDate=purchaseDate))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun SellStockDialog(x:StockItem,services:List<ServiceTemplate>,existingClients:List<ClientRecord>,close:()->Unit,save:(Sub)->Unit){
 val tpl=services.firstOrNull{it.name.equals(x.service,true)};val profileMode=!isComplete(x);var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var price by remember{mutableStateOf((tpl?.defaultPrice?:0).let{if(it>0)it.toString() else ""})};var method by remember{mutableStateOf("Nequi")};var start by remember{mutableStateOf(LocalDate.now().toString())};var duration by remember{mutableStateOf((tpl?.durationDays?:30).toString())}
 val phoneOk=phone.filter(Char::isDigit).length>=7;val durationOk=(duration.toIntOrNull()?:0)>0;val dateOk=OperationRules.parseDate(start)!=null
 AlertDialog(onDismissRequest=close,title={Text(if(profileMode)"Asignar perfil" else "Vender cuenta")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){
  item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primary.copy(alpha=.08f))){Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){Text(x.service,fontWeight=FontWeight.Bold);Text(x.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);if(profileMode){Text("Perfil: ${x.profile}",style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold);if(x.pin.isNotBlank())Text("PIN guardado",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}};item{Text(if(profileMode)"El perfil y su PIN ya están guardados. Solo asigna cliente y registra el cobro." else "Las credenciales y el proveedor ya están guardados. Solo registra cliente y cobro.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{ClientFields(existingClients,client,phone,{client=it},{phone=it})};item{NumericField("Precio cobrado",price){price=it}};item{PaymentMethodField(method){method=it}};item{DateField("Fecha de inicio",start,{start=it})};item{NumericField("Duración en días",duration){duration=it}};if(phone.isNotBlank()&&!phoneOk)item{Text("El WhatsApp parece incompleto.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}
 }},confirmButton={Button(enabled=client.isNotBlank()&&phoneOk&&dateOk&&durationOk&&method.isNotBlank(),onClick={val d=OperationRules.parseDate(start)!!;val n=duration.toLong().coerceAtLeast(1L);save(Sub(client=client.trim(),phone=phone.trim(),service=x.service,account=x.account,profile=x.profile,type=normalizedAccessType(x.type,x.profile),price=OperationRules.amount(price),start=d.toString(),end=d.plusDays(n).toString(),pin=x.pin,accountCost=x.accountCost,paymentMethod=method.trim(),password=x.password,provider=x.provider,providerPhone=x.providerPhone,accountEnd=x.accountEnd,accountRenewCost=x.accountRenewCost,stockId=x.id,purchaseDate=x.purchaseDate))}){Text(if(profileMode)"Asignar y entregar" else "Vender y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun MiniStat(label:String,value:String,modifier:Modifier=Modifier,valueColor:Color=MaterialTheme.colorScheme.onSurface){Surface(modifier,shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.55f)){Column(Modifier.padding(9.dp)){Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value,style=MaterialTheme.typography.bodyMedium,fontWeight=FontWeight.Bold,color=valueColor)}}}
@Composable fun ProfileRow(s:Sub,credentials:()->Unit,edit:()->Unit){
 val expired=days(s)<0;Column(verticalArrangement=Arrangement.spacedBy(6.dp)){HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(if(isComplete(s))s.client else s.profile.ifBlank{s.client},fontWeight=FontWeight.SemiBold,maxLines=1);Text("${s.client}${if(!isComplete(s)&&s.profile.isNotBlank())" · ${s.profile}" else ""} · vence ${s.end}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)};StatusBadge(if(expired)"VENCIDO" else "ACTIVO",if(expired)StreamRed else StreamGreen)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(credentials,Modifier.weight(1f)){Text("Enviar datos")};TextButton(edit,Modifier.weight(1f)){Text("Editar")}}}
}
fun waProvider(c:Context,provider:String,phone:String,account:String,service:String,end:String){val msg="Hola $provider, necesito revisar${if(account.isNotBlank())" la cuenta $account" else ""}${if(service.isNotBlank())" de $service" else ""}.${if(end.isNotBlank())" Vence $end." else ""}";val u="https://wa.me/${phone.filter{it.isDigit()}}?text=${Uri.encode(msg)}";c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}

@Composable fun Providers(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,renewProvider:(ProviderAccountSummary,String,Long)->Unit){
 val ctx=LocalContext.current;val accounts=providerAccounts(s,stock,h);val groups=accounts.groupBy{providerKey(it.provider)}.toSortedMap();var renewing by remember{mutableStateOf<ProviderAccountSummary?>(null)}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Proveedores","A quién compras y qué cuentas debes renovar")}
  if(groups.isNotEmpty()){
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Proveedores",groups.size.toString(),StreamBlue,Modifier.weight(1f),Icons.Default.Groups);MetricCard("Cuentas por atender",accounts.count{BusinessStateEngine.providerNeedsAttentionWithinWeek(BusinessStateEngine.provider(it.end))}.toString(),StreamAmber,Modifier.weight(1f),Icons.Default.Event)}}
   item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Invertido",money(accounts.sumOf{it.cost}),StreamRed,Modifier.weight(1f),Icons.Default.Payments);MetricCard("Ganancia acumulada",money(accounts.sumOf{it.income-it.cost-it.renewSpent}),if(accounts.sumOf{it.income-it.cost-it.renewSpent}>=0)StreamGreen else StreamRed,Modifier.weight(1f),Icons.Default.TrendingUp)}}
  }
  if(groups.isEmpty())item{EmptyState("Aún no hay proveedores. Registra una compra en Stock y aparecerá aquí automáticamente.")}
  groups.forEach{(_,list)->
   val name=list.firstOrNull()?.provider.orEmpty()
   val invested=list.sumOf{it.cost};val income=list.sumOf{it.income};val renews=list.sumOf{it.renewSpent};val profit=income-invested-renews;val due=list.count{BusinessStateEngine.providerNeedsAttentionWithinWeek(BusinessStateEngine.provider(it.end))}
   item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(providerDisplayName(name),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("${list.size} cuenta${if(list.size==1)"" else "s"} registrada${if(list.size==1)"" else "s"}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(due>0)"$due por atender" else "AL DÍA",if(due>0)StreamAmber else StreamGreen)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Invertido",money(invested),Modifier.weight(1f));MiniStat("Ingresos",money(income),Modifier.weight(1f),StreamCyan);MiniStat("Ganancia",money(profit),Modifier.weight(1f),if(profit>=0)StreamGreen else StreamRed)}
    val phone=list.firstOrNull{it.phone.isNotBlank()}?.phone?:"";if(phone.isNotBlank())OutlinedButton({waProvider(ctx,name,phone,"","","")},Modifier.fillMaxWidth()){Text("Contactar proveedor")}
   }}}
   items(list.sortedWith(compareBy<ProviderAccountSummary>{it.end.ifBlank{"9999"}}.thenBy{it.service})){a->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.45f))){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(a.service,fontWeight=FontWeight.Bold);Text(a.account,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(a.status,when(a.status){"VENCIDA"->StreamRed;"ACTIVA"->StreamCyan;"STOCK"->StreamGreen;else->StreamAmber})}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){MiniStat("Costo",money(a.cost),Modifier.weight(1f));MiniStat("Ingreso acum.",money(a.income),Modifier.weight(1f),StreamCyan);MiniStat("Ganancia acum.",money(a.income-a.cost-a.renewSpent),Modifier.weight(1f),if(a.income-a.cost-a.renewSpent>=0)StreamGreen else StreamRed)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Compra",style=MaterialTheme.typography.bodySmall);Text(a.purchaseDate.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Vence proveedor",style=MaterialTheme.typography.bodySmall);Text(a.end.ifBlank{"Sin fecha"},style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Renovar",style=MaterialTheme.typography.bodySmall);Text(money(a.renewCost),style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){if(a.phone.isNotBlank())OutlinedButton({waProvider(ctx,a.provider,a.phone,a.account,a.service,a.end)},Modifier.weight(1f)){Text("WhatsApp")};Button({renewing=a},Modifier.weight(1f)){Text("Renovar cuenta")}}
   }}}
  }
 }
 renewing?.let{a->ProviderRenewDialog(a,{renewing=null}){end,cost->renewProvider(a,end,cost);renewing=null}}
}
@Composable fun ProviderRenewDialog(a:ProviderAccountSummary,close:()->Unit,save:(String,Long)->Unit){
 var end by remember(a.account){mutableStateOf(runCatching{val old=if(a.end.isNotBlank())LocalDate.parse(a.end) else LocalDate.now();val base=if(old.isBefore(LocalDate.now()))LocalDate.now() else old;base.plusDays(30).toString()}.getOrDefault(LocalDate.now().plusDays(30).toString()))};var cost by remember(a.account){mutableStateOf(a.renewCost.toString())}
 val dateOk=OperationRules.parseDate(end)!=null
 AlertDialog(onDismissRequest=close,title={Text("Renovar con proveedor")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("${a.service} • ${a.account}",fontWeight=FontWeight.Bold);Text("Proveedor: ${providerDisplayName(a.provider)}");DateField("Nuevo vencimiento",end,{end=it});Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf(30L,60L,90L).forEach{n->OutlinedButton({val old=OperationRules.parseDate(a.end)?:LocalDate.now();val base=if(old.isBefore(LocalDate.now()))LocalDate.now() else old;end=base.plusDays(n).toString()},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=4.dp,vertical=7.dp)){Text("+$n")}}};NumericField("Costo pagado",cost){cost=it};Text("Este movimiento queda registrado como costo y actualiza la fecha de la cuenta.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}},confirmButton={Button({save(end,OperationRules.amount(cost))},enabled=dateOk){Text("Registrar renovación")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun Reports(s:List<Sub>,stock:List<StockItem>,h:List<Hist>){
 val month=monthPrefix();val monthHist=h.filter{it.date.startsWith(month)};val salesMonth=monthHist.filter{isSaleIncome(it)}.sumOf{it.amount};val renewProvider=monthHist.filter{it.action.contains("RENOVACIÓN PROVEEDOR")}.sumOf{it.amount};val investedMonth=monthlyAccountCosts(s,stock)+renewProvider;val cashBalance=salesMonth-investedMonth
 val visible=s.filter{it.status!="CORTADO"};val states=visible.associateWith{BusinessStateEngine.client(it)};val active=visible.count{(states.getValue(it).daysToEnd?:Long.MIN_VALUE)>=0};val newSales=monthHist.count{it.action.contains("VENTA")};val renewals=monthHist.count{it.action.startsWith("RENOVACIÓN +")}
 val actionable=visible.filter{BusinessStateEngine.requiresAction(states.getValue(it))};val toCollect=actionable.sumOf{it.price};val occupiedProfiles=s.count{it.status!="CORTADO"&&!isComplete(it)};val totalProfiles=occupiedProfiles+stock.count{effectiveStockStatus(it)=="DISPONIBLE"&&!isComplete(it)};val occupancy=if(totalProfiles>0)occupiedProfiles*100/totalProfiles else 0
 val providers=providerAccounts(s,stock,h);val providerDue=providers.count{BusinessStateEngine.providerNeedsAttentionWithinWeek(BusinessStateEngine.provider(it.end))};val providerGroups=providers.groupBy{providerKey(it.provider)};val bestProvider=providerGroups.entries.maxByOrNull{e->e.value.sumOf{it.income-it.cost-it.renewSpent}};val accountBest=providers.maxByOrNull{it.income-it.cost-it.renewSpent};val serviceBest=s.filter{it.status!="CORTADO"}.groupBy{it.service}.maxByOrNull{it.value.size}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Reportes","Cobros, inversión y balance real de caja")}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Cobrado este mes",money(salesMonth),StreamBlue,Modifier.weight(1f),Icons.Default.TrendingUp);MetricCard("Invertido este mes",money(investedMonth),StreamRed,Modifier.weight(1f),Icons.Default.Payments)}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MetricCard("Balance de caja",money(cashBalance),if(cashBalance>=0)StreamGreen else StreamRed,Modifier.weight(1f),Icons.Default.TrendingUp);MetricCard("Por cobrar ahora",money(toCollect),StreamCyan,Modifier.weight(1f),Icons.Default.AccountBalanceWallet)}}
  item{InfoBanner("Cómo leer el balance","Balance de caja = cobrado − inversión del mes. Un balance negativo no significa necesariamente pérdida si todavía tienes stock disponible para vender.",if(cashBalance>=0)StreamGreen else StreamAmber)}
  item{SectionTitle("Indicadores","Todos usan el mismo motor de estados de Inicio y Renovaciones")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Clientes activos ahora",active.toString(),Modifier.weight(1f),StreamBlue);MiniStat("Por gestionar ahora",actionable.size.toString(),Modifier.weight(1f),StreamCyan)}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Ventas nuevas este mes",newSales.toString(),Modifier.weight(1f),StreamCyan);MiniStat("Renovaciones este mes",renewals.toString(),Modifier.weight(1f),StreamGreen)}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){MiniStat("Ocupación perfiles", "$occupancy%",Modifier.weight(1f),StreamPurple);MiniStat("Proveedor por atender",providerDue.toString(),Modifier.weight(1f),StreamAmber)}
  }}}
  item{SectionTitle("Lo que más te conviene","Identifica rápido qué producto y proveedor dejan más margen acumulado")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){InsightRow("Servicio con más clientes",serviceBest?.key?:"Sin datos",StreamPurple);HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);InsightRow("Proveedor que más margen deja",bestProvider?.value?.firstOrNull()?.provider?.let{providerDisplayName(it)}?:"Sin datos",StreamGreen,bestProvider?.let{"${money(it.value.sumOf{x->x.income-x.cost-x.renewSpent})} acumulado"}?:"");HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);InsightRow("Cuenta que más margen deja",accountBest?.service?:"Sin datos",StreamCyan,accountBest?.let{"${it.account} • ${money(it.income-it.cost-it.renewSpent)}"}?:"")}}}
  item{SectionTitle("Actividad reciente","Últimos movimientos del negocio")}
  if(h.isEmpty())item{EmptyState("Aún no hay movimientos registrados.")}
  items(h.sortedByDescending{it.id}.take(100)){x->ActivityRow(x,activityOwner(x,s))}
 }
}
@Composable fun ActivityRow(x:Hist,client:String){val isCost=x.action.contains("COMPRA STOCK")||x.action.contains("RENOVACIÓN PROVEEDOR");val amountColor=if(isCost)StreamRed else StreamGreen;Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.42f))){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(client,fontWeight=FontWeight.SemiBold);Text(x.action,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(x.date,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};if(x.amount>0)Text((if(isCost)"− " else "+ ")+money(x.amount),fontWeight=FontWeight.Bold,color=amountColor)}}}

@Composable fun More(s:List<Sub>,stock:List<StockItem>,h:List<Hist>,services:List<ServiceTemplate>,setServices:(List<ServiceTemplate>)->Unit,dark:Boolean,setDark:(Boolean)->Unit,t:Templates,setT:(Templates)->Unit,st:Store,reload:()->Unit,onLockNow:()->Unit){
 var edit by remember{mutableStateOf(false)};var incident by remember{mutableStateOf(false)};var serviceDialog by remember{mutableStateOf(false)};var filter by remember{mutableStateOf("Todos")};var query by remember{mutableStateOf("")};val c=LocalContext.current;var backupMsg by remember{mutableStateOf("")};var backupPassDialog by remember{mutableStateOf(false)};var restorePassDialog by remember{mutableStateOf(false)};var pendingRestore by remember{mutableStateOf("")}
 val appLock=remember{AppLockManager(c)};var pinSetupDialog by remember{mutableStateOf(false)};var pinDisableDialog by remember{mutableStateOf(false)};var securityMsg by remember{mutableStateOf("")};var securityTick by remember{mutableIntStateOf(0)}
 val pinEnabled=remember(securityTick){appLock.isEnabled()};val biometricAvailable=remember(securityTick){appLock.canUseBiometric()};val biometricEnabled=remember(securityTick){appLock.biometricEnabled()}
 var diagnosticOpen by remember{mutableStateOf(false)};var privacyOpen by remember{mutableStateOf(false)};var quickHelpOpen by remember{mutableStateOf(false)}
 val notificationsEnabled=NotificationManagerCompat.from(c).areNotificationsEnabled()
 val commercialReport=CommercialReadiness.evaluate(s,stock,pinEnabled,st.hasBackupPassword(),st.backupFolder().isNotBlank(),notificationsEnabled)
 val diagnosticClientCount=s.filter{it.client.isNotBlank()}.map{it.phone.filter(Char::isDigit).ifBlank{it.client.trim().lowercase()}}.distinct().size
 val diagnosticProviderCount=(s.map{it.provider}+stock.map{it.provider}).map{it.trim().lowercase()}.filter{it.isNotBlank()}.distinct().size
 val diagnosticText=CommercialReadiness.plainText(commercialReport,BuildConfig.VERSION_NAME,s.size,stock.size,diagnosticClientCount,diagnosticProviderCount)
 val exportDiagnostic=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")){u->if(u!=null)runCatching{c.contentResolver.openOutputStream(u)?.bufferedWriter()?.use{it.write(diagnosticText)};backupMsg="Diagnóstico exportado sin credenciales"}.onFailure{backupMsg="No se pudo exportar el diagnóstico"}}
 val createBackup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null)runCatching{c.contentResolver.openOutputStream(u)?.bufferedWriter()?.use{it.write(st.backup())};backupMsg="Respaldo cifrado guardado correctamente"}.onFailure{backupMsg="No se pudo guardar el respaldo"}}
 val openBackup=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)runCatching{val txt=c.contentResolver.openInputStream(u)?.bufferedReader()?.use{it.readText()}?:"";if(BackupCrypto.isEncrypted(txt)){val local=st.backupPassword();if(local.isNotBlank()&&st.restore(txt,local)){reload();backupMsg="Respaldo restaurado correctamente"}else{pendingRestore=txt;restorePassDialog=true}}else{backupMsg=if(st.restore(txt,"")){reload();"Respaldo antiguo restaurado correctamente"}else "Archivo no compatible"}}.onFailure{backupMsg="No se pudo leer el respaldo"}}
 val chooseFolder=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()){u->if(u!=null){backupMsg=if(st.setBackupFolder(u))"Carpeta automática configurada" else "No se pudo configurar la carpeta"}}
 val filtered=h.sortedByDescending{it.id}.filter{x->val owner=activityOwner(x,s);(owner.contains(query,true)||x.action.contains(query,true))&&(filter=="Todos"||x.action.contains(filter,true))}
 LazyColumn(Modifier.padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{ScreenHeader("Ajustes","Plantillas, incidencias, actividad y respaldo")}
  item{SectionTitle("Operación")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Plantillas de servicios",fontWeight=FontWeight.Bold);StatusBadge(services.size.toString(),StreamPurple)};Text("Duración, precio, tipo, proveedor y costos para registrar compras y ventas más rápido.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton({serviceDialog=true},Modifier.fillMaxWidth()){Text("Administrar plantillas")};HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant);Text("Incidencias de cuenta",fontWeight=FontWeight.Bold);Text("Registra caídas y repone días a todos los clientes afectados.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton({incident=true},Modifier.fillMaxWidth()){Text("Registrar incidencia")}}}}
  item{SectionTitle("Actividad","Auditoría de ventas, renovaciones, ajustes y bajas")}
  item{OutlinedTextField(query,{query=it},label={Text("Buscar cliente, proveedor o movimiento")},singleLine=true,modifier=Modifier.fillMaxWidth())}
  item{LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(listOf("Todos","VENTA","RENOVACIÓN","AJUSTE","BAJA","PROVEEDOR")){x->FilterChip(selected=filter==x,onClick={filter=x},label={Text(x.lowercase().replaceFirstChar{it.uppercase()})})}}}
  if(filtered.isEmpty())item{EmptyState("Sin actividad para este filtro.")}
  items(filtered.take(40)){x->ActivityRow(x,activityOwner(x,s))}
  item{SectionTitle("Aplicación")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Modo oscuro",fontWeight=FontWeight.SemiBold);Text("Identidad Nexo Digital",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(dark,setDark)};OutlinedButton({edit=true},Modifier.fillMaxWidth()){Text("Editar mensajes automáticos")};Text("v${BuildConfig.VERSION_NAME} • base profesional • API 36",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
  item{SectionTitle("Preparación comercial","Revisa la salud de la app antes de publicar o actualizar")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Diagnóstico ${commercialReport.score}/100",fontWeight=FontWeight.Bold);Text(commercialReport.label,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(commercialReport.issues.none{it.severity=="CRITICO"})"LISTA" else "REVISAR",if(commercialReport.issues.none{it.severity=="CRITICO"})StreamGreen else StreamAmber)};Button({diagnosticOpen=true},Modifier.fillMaxWidth()){Text("Revisar diagnóstico")};OutlinedButton({exportDiagnostic.launch("ControlStreaming_Diagnostico_${LocalDate.now()}.txt")},Modifier.fillMaxWidth()){Text("Exportar diagnóstico seguro")};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({quickHelpOpen=true},Modifier.weight(1f)){Text("Guía rápida")};OutlinedButton({privacyOpen=true},Modifier.weight(1f)){Text("Privacidad")}}}}}
  item{SectionTitle("Seguridad","Protege cuentas, contraseñas y datos de clientes")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("PIN de acceso",fontWeight=FontWeight.Bold);Text(if(pinEnabled)"La aplicación se bloquea al volver después de 1 minuto" else "Actívalo para impedir que otras personas abran la app",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};StatusBadge(if(pinEnabled)"PROTEGIDO" else "DESACTIVADO",if(pinEnabled)StreamGreen else StreamAmber)}
   Button({pinSetupDialog=true},Modifier.fillMaxWidth()){Text(if(pinEnabled)"Cambiar PIN" else "Crear PIN de acceso")}
   if(pinEnabled&&biometricAvailable)Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Huella / biometría",fontWeight=FontWeight.SemiBold);Text("Desbloqueo rápido sin mostrar las credenciales",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(biometricEnabled,{appLock.setBiometricEnabled(it);securityTick++})}
   if(pinEnabled)OutlinedButton(onLockNow,Modifier.fillMaxWidth()){Text("Bloquear ahora")}
   if(pinEnabled)TextButton({pinDisableDialog=true},Modifier.fillMaxWidth()){Text("Desactivar PIN",color=StreamRed)}
   if(securityMsg.isNotBlank())Text(securityMsg,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  }}}
  item{SectionTitle("Copia de seguridad","Protege los datos antes de cada actualización")}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Contraseña de respaldos",fontWeight=FontWeight.Bold);Text(if(st.hasBackupPassword())"Protección activa" else "Configúrala antes de crear copias",style=MaterialTheme.typography.bodySmall,color=if(st.hasBackupPassword())StreamGreen else StreamAmber)};StatusBadge(if(st.hasBackupPassword())"PROTEGIDO" else "PENDIENTE",if(st.hasBackupPassword())StreamGreen else StreamAmber)};OutlinedButton({backupPassDialog=true},Modifier.fillMaxWidth()){Text(if(st.hasBackupPassword())"Cambiar contraseña de respaldo" else "Crear contraseña de respaldo")};Button({createBackup.launch("ControlStreaming_Backup_${LocalDate.now()}.nexo")},Modifier.fillMaxWidth(),enabled=st.hasBackupPassword()){Text("Crear respaldo local cifrado")};OutlinedButton({openBackup.launch(arrayOf("application/octet-stream","application/json","text/plain","*/*"))},Modifier.fillMaxWidth()){Text("Restaurar respaldo")};OutlinedButton({chooseFolder.launch(null)},Modifier.fillMaxWidth(),enabled=st.hasBackupPassword()){Text(if(st.backupFolder().isBlank())"Elegir carpeta para respaldo automático" else "Cambiar carpeta automática")};if(st.backupFolder().isNotBlank()&&st.hasBackupPassword())Text("Respaldo automático cifrado activo • se conservan las últimas 7 copias",style=MaterialTheme.typography.bodySmall,color=StreamGreen);if(backupMsg.isNotBlank())Text(backupMsg,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
 }
 if(edit)TemplateDialog(t,{edit=false}){setT(it);edit=false};if(incident)IncidentDialog(s,st,{incident=false},reload);if(serviceDialog)ServiceTemplatesDialog(services,{serviceDialog=false}){setServices(it);serviceDialog=false};if(backupPassDialog)BackupPasswordDialog({backupPassDialog=false}){pass->if(st.setBackupPassword(pass)){backupMsg="Contraseña de respaldos guardada";backupPassDialog=false}else backupMsg="Usa al menos 6 caracteres"};if(restorePassDialog)RestorePasswordDialog({restorePassDialog=false;pendingRestore=""}){pass->if(st.restore(pendingRestore,pass)){reload();backupMsg="Respaldo restaurado correctamente";restorePassDialog=false;pendingRestore=""}else backupMsg="Contraseña incorrecta o respaldo dañado"}
 if(pinSetupDialog)AppPinSetupDialog(pinEnabled,{pinSetupDialog=false}){pin->if(appLock.setPin(pin)){securityMsg=if(pinEnabled)"PIN actualizado" else "PIN de acceso activado";securityTick++;pinSetupDialog=false}else securityMsg="El PIN debe tener entre 4 y 8 números"}
 if(pinDisableDialog)AppPinDisableDialog({pinDisableDialog=false}){pin->if(appLock.disablePin(pin)){securityMsg="PIN desactivado";securityTick++;pinDisableDialog=false}else securityMsg="PIN incorrecto"}
 if(diagnosticOpen)AlertDialog(onDismissRequest={diagnosticOpen=false},title={Text("Diagnóstico comercial ${commercialReport.score}/100")},text={LazyColumn(Modifier.heightIn(max=420.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){if(commercialReport.issues.isEmpty())item{Text("No se encontraron problemas operativos críticos. La app está bien preparada para pruebas.",color=StreamGreen)}else items(commercialReport.issues){x->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=(if(x.severity=="CRITICO")StreamRed else StreamAmber).copy(alpha=.10f))){Column(Modifier.padding(10.dp)){Text(x.title,fontWeight=FontWeight.Bold,color=if(x.severity=="CRITICO")StreamRed else StreamAmber);Text(x.detail,style=MaterialTheme.typography.bodySmall)}}}}},confirmButton={Button({diagnosticOpen=false}){Text("Entendido")}})
 if(privacyOpen)AlertDialog(onDismissRequest={privacyOpen=false},title={Text("Privacidad y datos")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Tus clientes, cuentas, perfiles y movimientos se guardan localmente en el dispositivo.");Text("Contraseñas y PIN se cifran con Android Keystore. Los respaldos nuevos requieren contraseña y se cifran antes de guardarse.");Text("La app no integra publicidad ni analítica de terceros. WhatsApp solo se abre cuando tú decides enviar un mensaje.");Text("Antes de publicar en Google Play debes alojar la política de privacidad incluida en el ZIP en una URL pública.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}},confirmButton={Button({privacyOpen=false}){Text("Cerrar")}})
 if(quickHelpOpen)AlertDialog(onDismissRequest={quickHelpOpen=false},title={Text("Guía rápida")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Text("1. Carga una cuenta o perfiles en Stock.",fontWeight=FontWeight.SemiBold);Text("2. Vende desde Stock para que el acceso se marque automáticamente.");Text("3. Usa Renovar para cobrar, dar plazo o finalizar el servicio.");Text("4. Revisa Proveedores para renovar tus cuentas antes de que venzan.");Text("5. Mira Reportes para controlar cobros, costos y ganancia.")}},confirmButton={Button({quickHelpOpen=false}){Text("Listo")}})
}

@Composable fun IncidentDialog(s:List<Sub>,st:Store,close:()->Unit,reload:()->Unit){var account by remember{mutableStateOf("")};var type by remember{mutableStateOf("Cuenta caída")};var daysBack by remember{mutableStateOf("0")};AlertDialog(onDismissRequest=close,title={Text("⚠️ Incidencia")},text={Column{F("Cuenta / correo afectado",account){account=it};F("Tipo de incidencia",type){type=it};F("Días a reponer a todos (0 si aún no)",daysBack){daysBack=it};Text("Afectados: ${s.count{it.account==account&&it.status!="CORTADO"}}")}},confirmButton={Button({val n=daysBack.toIntOrNull()?:0;val affected=s.filter{it.account==account&&it.status!="CORTADO"};if(n>0)st.save(s.map{x->if(x.account==account&&x.status!="CORTADO")x.copy(end=runCatching{LocalDate.parse(x.end).plusDays(n.toLong()).toString()}.getOrDefault(x.end))else x});val hh=st.hist().toMutableList();affected.forEach{x->hh.add(Hist(subId=x.id,date=LocalDate.now().toString(),action="INCIDENCIA • $type • ${if(n>0)"REPOSICIÓN +$n DÍAS" else "ABIERTA"}"))};st.saveHist(hh);reload();close()},enabled=account.isNotBlank()){Text("Guardar incidencia")}},dismissButton={TextButton(close){Text("Cancelar")}})}

@Composable fun TemplateDialog(t:Templates,close:()->Unit,save:(Templates)->Unit){
 var a by remember{mutableStateOf(t.due3)};var b by remember{mutableStateOf(t.due1)};var c by remember{mutableStateOf(t.due0)};var d by remember{mutableStateOf(t.expired)};var e by remember{mutableStateOf(t.delivery)};var promise by remember{mutableStateOf(t.promise)};var p3 by remember{mutableStateOf(t.provider3)};var p1 by remember{mutableStateOf(t.provider1)};var p0 by remember{mutableStateOf(t.provider0)}
 AlertDialog(onDismissRequest=close,title={Text("Mensajes automáticos")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){
  item{Text("CLIENTES",fontWeight=FontWeight.Bold)};item{F("Vence en 3 días",a){a=it}};item{F("Vence mañana",b){b=it}};item{F("Vence hoy",c){c=it}};item{F("Vencido / pendiente de corte",d){d=it}};item{F("Promesa de pago",promise){promise=it}};item{F("Entrega",e){e=it}}
  item{Text("PROVEEDORES",fontWeight=FontWeight.Bold)};item{Text("Variables: {proveedor}, {servicio}, {cuenta}, {fecha}, {costo}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{F("Cuenta vence en 3 días",p3){p3=it}};item{F("Cuenta vence mañana",p1){p1=it}};item{F("Cuenta vence hoy",p0){p0=it}}
 }},confirmButton={Button({save(Templates(due3=a,due1=b,due0=c,expired=d,delivery=e,promise=promise,provider3=p3,provider1=p1,provider0=p0))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}
@Composable fun RestoreDialog(close:()->Unit,restore:(String)->Unit){var text by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Restaurar respaldo")},text={Column{Text("Pega aquí el respaldo JSON exportado desde Nexo.");OutlinedTextField(text,{text=it},modifier=Modifier.fillMaxWidth().height(180.dp))}},confirmButton={Button({restore(text)},enabled=text.isNotBlank()){Text("Restaurar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
@Composable fun AddDialog(services:List<ServiceTemplate>,existingClients:List<ClientRecord>,close:()->Unit,save:(Sub)->Unit){
 var client by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var service by remember{mutableStateOf("")};var account by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var profile by remember{mutableStateOf("")};var pin by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var method by remember{mutableStateOf("Nequi")};var type by remember{mutableStateOf("CUENTA COMPLETA")};var start by remember{mutableStateOf(LocalDate.now().toString())};var duration by remember{mutableStateOf("30")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var purchaseDate by remember{mutableStateOf(LocalDate.now().toString())};var accountEnd by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 fun applyTemplate(t:ServiceTemplate){service=t.name;type=t.type;duration=t.durationDays.toString();price=if(t.defaultPrice>0)t.defaultPrice.toString() else "";provider=t.provider;providerPhone=t.providerPhone;cost=t.accountCost.toString();renewCost=t.renewCost.toString()}
 val phoneOk=phone.filter(Char::isDigit).length>=7;val providerPhoneOk=OperationRules.phoneValidOrBlank(providerPhone);val startOk=OperationRules.parseDate(start)!=null;val durationOk=(duration.toIntOrNull()?:0)>0;val providerDatesOk=OperationRules.optionalDateRangeValid(purchaseDate,accountEnd)
 AlertDialog(onDismissRequest=close,title={Text("Venta manual (avanzada)")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  if(services.isNotEmpty())item{Column{Text("PLANTILLAS RÁPIDAS",fontWeight=FontWeight.Bold);LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(services){t->AssistChip(onClick={applyTemplate(t)},label={Text(t.name)})}}}}
  item{Text("Usa esta opción solo si el acceso todavía no está registrado en Stock.",style=MaterialTheme.typography.bodySmall,color=StreamAmber)};item{ClientFields(existingClients,client,phone,{client=it},{phone=it})};item{F("Servicio",service){service=it}};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=type=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA"},label={Text("Cuenta completa")},modifier=Modifier.weight(1f));FilterChip(selected=type=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA"},label={Text("Perfil")},modifier=Modifier.weight(1f))}}
  if(type!="CUENTA COMPLETA"){item{F("Perfil / pantalla",profile){profile=it}};item{F("PIN / clave",pin){pin=it}}}
  item{NumericField("Precio cobrado",price){price=it}};item{NumericField("Costo de la cuenta",cost){cost=it}};item{PaymentMethodField(method){method=it}};item{NumericField("Duración en días",duration){duration=it}};item{Text("DATOS DEL PROVEEDOR",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{DateField("Fecha de compra",purchaseDate,{purchaseDate=it},allowBlank=true)};item{DateField("Vence cuenta con proveedor",accountEnd,{accountEnd=it},allowBlank=true)};item{NumericField("Costo de renovar cuenta",renewCost){renewCost=it}};item{DateField("Inicio del cliente",start,{start=it})}
  if(phone.isNotBlank()&&!phoneOk)item{Text("El WhatsApp del cliente parece incompleto.",color=StreamRed,style=MaterialTheme.typography.bodySmall)};if(!providerPhoneOk)item{Text("Revisa el WhatsApp del proveedor.",color=StreamRed,style=MaterialTheme.typography.bodySmall)};if(!providerDatesOk)item{Text("El vencimiento del proveedor no puede ser anterior a la compra.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}
 }},confirmButton={Button(enabled=client.isNotBlank()&&phoneOk&&service.isNotBlank()&&account.isNotBlank()&&startOk&&durationOk&&providerPhoneOk&&providerDatesOk&&method.isNotBlank(),onClick={val d=OperationRules.parseDate(start)!!;val n=duration.toLong().coerceAtLeast(1L);save(Sub(client=client.trim(),phone=phone.trim(),service=service.trim(),account=account.trim(),profile=if(type=="CUENTA COMPLETA")"" else profile.trim(),pin=if(type=="CUENTA COMPLETA")"" else pin,type=normalizedAccessType(type,profile),password=password,price=OperationRules.amount(price),accountCost=OperationRules.amount(cost),paymentMethod=method.trim(),start=d.toString(),end=d.plusDays(n).toString(),provider=normalizedProviderStorage(provider),providerPhone=providerPhone.trim(),accountEnd=accountEnd,accountRenewCost=OperationRules.amount(renewCost),purchaseDate=purchaseDate))}){Text("Guardar y entregar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun DateField(label:String,value:String,onValueChange:(String)->Unit,allowBlank:Boolean=false){
 var open by remember{mutableStateOf(false)}
 Column(verticalArrangement=Arrangement.spacedBy(2.dp)){
  OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(horizontal=12.dp,vertical=10.dp)){
   Icon(Icons.Default.Event,contentDescription=null);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f),horizontalAlignment=Alignment.Start){Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value.ifBlank{"Seleccionar fecha"},fontWeight=FontWeight.SemiBold)}
  }
  if(allowBlank&&value.isNotBlank())TextButton({onValueChange("")},contentPadding=PaddingValues(horizontal=4.dp,vertical=0.dp)){Text("Quitar fecha",style=MaterialTheme.typography.labelSmall)}
 }
 if(open){
  val initial=OperationRules.parseDate(value)?:LocalDate.now()
  val state=rememberDatePickerState(initialSelectedDateMillis=initial.atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli())
  DatePickerDialog(onDismissRequest={open=false},confirmButton={TextButton({state.selectedDateMillis?.let{ms->onValueChange(java.time.Instant.ofEpochMilli(ms).atZone(java.time.ZoneOffset.UTC).toLocalDate().toString())};open=false}){Text("Aceptar")}},dismissButton={TextButton({open=false}){Text("Cancelar")}}){DatePicker(state=state)}
 }
}

@Composable fun NumericField(label:String,value:String,onChange:(String)->Unit){
 OutlinedTextField(value,{onChange(it.filter(Char::isDigit))},label={Text(label)},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true,modifier=Modifier.fillMaxWidth())
}

@Composable fun PaymentMethodField(method:String,onChange:(String)->Unit){
 val presets=listOf("Nequi","Daviplata","Efectivo","Transferencia")
 val custom=method !in presets
 Column(verticalArrangement=Arrangement.spacedBy(5.dp)){
  Text("Método de pago",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
  LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(presets){m->FilterChip(selected=method==m,onClick={onChange(m)},label={Text(m)})};item{FilterChip(selected=custom,onClick={if(!custom)onChange("")},label={Text("Otro")})}}
  if(custom)F("Escribe el método",method,onChange)
 }
}

@Composable fun RenewClientDialog(s:Sub,close:()->Unit,save:(Long,String,Int)->Unit){
 var price by remember(s.id){mutableStateOf(s.price.toString())};var method by remember(s.id){mutableStateOf(s.paymentMethod.ifBlank{"Nequi"})};var duration by remember(s.id){mutableStateOf("30")}
 val days=duration.toIntOrNull()?.coerceAtLeast(1)?:30;val preview=OperationRules.renewalEnd(s.end,days);val amount=OperationRules.amount(price)
 AlertDialog(onDismissRequest=close,title={Text("Registrar renovación")},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){
  Text("${s.client} • ${s.service}",fontWeight=FontWeight.Bold);Text("Vence actualmente: ${s.end}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
  OutlinedTextField(price,{price=it.filter(Char::isDigit)},label={Text("Valor cobrado")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true,modifier=Modifier.fillMaxWidth())
  PaymentMethodField(method){method=it}
  Text("Duración",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf(30,60,90).forEach{n->FilterChip(selected=days==n,onClick={duration=n.toString()},label={Text("$n días")},modifier=Modifier.weight(1f))}}
  OutlinedTextField(duration,{duration=it.filter(Char::isDigit)},label={Text("Días")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true,modifier=Modifier.fillMaxWidth())
  Surface(shape=RoundedCornerShape(12.dp),color=StreamGreen.copy(alpha=.09f)){Column(Modifier.fillMaxWidth().padding(10.dp)){Text("Nuevo vencimiento",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(preview,fontWeight=FontWeight.Bold,color=StreamGreen);Text("Se registrarán ${money(amount)} por ${method.ifBlank{"Sin método"}}.",style=MaterialTheme.typography.bodySmall)}}
 }},confirmButton={Button({save(amount,method.trim(),days)},enabled=duration.toIntOrNull()?.let{it>0}==true&&method.isNotBlank()){Text("Confirmar renovación")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun EndServiceDialog(s:Sub,close:()->Unit,confirm:(String)->Unit){
 var reason by remember(s.id){mutableStateOf("No renovó")}
 AlertDialog(onDismissRequest=close,title={Text("Cliente no renovó")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("${s.client} • ${s.service}",fontWeight=FontWeight.Bold);Text("El acceso quedará disponible para vender nuevamente. Los datos del cliente y sus pagos se conservarán.")
  Text("Motivo",fontWeight=FontWeight.Bold);listOf("No renovó","Cliente canceló","Cambio de servicio","Problema con la cuenta","Otro").forEach{x->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=reason==x,onClick={reason=x});Text(x)}}
 }},confirmButton={Button(onClick={confirm(reason)}){Text("Confirmar no renovación")}},dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}

@Composable fun PromiseDialog(s:Sub,close:()->Unit,save:(String)->Unit){
 var date by remember(s.id){mutableStateOf(LocalDate.now().plusDays(1).toString())};val valid=OperationRules.parseDate(date)?.let{!it.isBefore(LocalDate.now())}==true
 AlertDialog(onDismissRequest=close,title={Text("Dar plazo")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Registra cuándo prometió pagar. No modifica el vencimiento real del servicio.");DateField("Fecha prometida",date,{date=it});Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf(1L,2L,3L).forEach{n->OutlinedButton({date=LocalDate.now().plusDays(n).toString()},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=4.dp,vertical=7.dp)){Text("+$n día")}}};if(!valid)Text("La promesa debe ser para hoy o una fecha futura.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}},confirmButton={Button({save(date)},enabled=valid){Text("Guardar plazo")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun AdjustEndDialog(s:Sub,close:()->Unit,save:(String,String)->Unit){
 var date by remember(s.id){mutableStateOf(s.end)};var reason by remember(s.id){mutableStateOf("")}
 fun addDays(n:Long){date=(OperationRules.parseDate(date)?:OperationRules.parseDate(s.end)?:LocalDate.now()).plusDays(n).toString()}
 val valid=OperationRules.parseDate(date)?.let{newDate->OperationRules.parseDate(s.start)?.let{!newDate.isBefore(it)}?:true}==true
 AlertDialog(onDismissRequest=close,title={Text("Ajustar vencimiento")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("${s.client} • ${s.service}");Text("Vencimiento actual: ${s.end}");DateField("Nueva fecha",date,{date=it});Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1L,3L,5L,7L).forEach{n->OutlinedButton(onClick={addDays(n)},contentPadding=PaddingValues(horizontal=8.dp,vertical=6.dp)){Text("+$n")}}};OutlinedTextField(value=reason,onValueChange={reason=it},label={Text("Motivo (opcional)")},modifier=Modifier.fillMaxWidth());Text("Este ajuste no registra una venta ni una renovación pagada.",style=MaterialTheme.typography.bodySmall);if(!valid)Text("La nueva fecha no puede quedar antes del inicio del servicio.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}},confirmButton={Button(onClick={save(date,reason.trim())},enabled=valid){Text("Guardar")}},dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}

@Composable fun EditSubDialog(s:Sub,close:()->Unit,save:(Sub)->Unit,delete:()->Unit){
 var client by remember(s.id){mutableStateOf(s.client)};var phone by remember(s.id){mutableStateOf(s.phone)};var service by remember(s.id){mutableStateOf(s.service)};var account by remember(s.id){mutableStateOf(s.account)};var password by remember(s.id){mutableStateOf(s.password)};var profile by remember(s.id){mutableStateOf(s.profile)};var pin by remember(s.id){mutableStateOf(s.pin)};var type by remember(s.id){mutableStateOf(s.type)};var price by remember(s.id){mutableStateOf(s.price.toString())};var cost by remember(s.id){mutableStateOf(s.accountCost.toString())};var method by remember(s.id){mutableStateOf(s.paymentMethod)};var start by remember(s.id){mutableStateOf(s.start)};var end by remember(s.id){mutableStateOf(s.end)};var provider by remember(s.id){mutableStateOf(s.provider)};var providerPhone by remember(s.id){mutableStateOf(s.providerPhone)};var purchaseDate by remember(s.id){mutableStateOf(s.purchaseDate.ifBlank{s.start})};var accountEnd by remember(s.id){mutableStateOf(s.accountEnd)};var renewCost by remember(s.id){mutableStateOf(s.accountRenewCost.toString())};var confirmDelete by remember(s.id){mutableStateOf(false)}
 val clientDatesOk=OperationRules.dateRangeValid(start,end);val providerDatesOk=OperationRules.optionalDateRangeValid(purchaseDate,accountEnd);val phoneOk=OperationRules.phoneValidOrBlank(phone);val providerPhoneOk=OperationRules.phoneValidOrBlank(providerPhone)
 AlertDialog(onDismissRequest=close,title={Text("Editar entrega / cuenta")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){
  item{Text("DATOS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{F("Cliente",client){client=it}};item{F("WhatsApp",phone){phone=it}};item{F("Servicio",service){service=it}}
  item{Text("CREDENCIALES",fontWeight=FontWeight.Bold)};item{F("Correo / cuenta",account){account=it}};item{F("Contraseña",password){password=it}};item{F("Perfil / pantalla (opcional)",profile){profile=it}};item{F("PIN / clave (opcional)",pin){pin=it}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=normalizedAccessType(type,profile)=="CUENTA COMPLETA",onClick={type="CUENTA COMPLETA";profile="";pin=""},label={Text("Cuenta completa")},modifier=Modifier.weight(1f));FilterChip(selected=normalizedAccessType(type,profile)=="PERFIL/PANTALLA",onClick={type="PERFIL/PANTALLA"},label={Text("Perfil")},modifier=Modifier.weight(1f))}}
  item{Text("FECHAS DEL CLIENTE",fontWeight=FontWeight.Bold)};item{DateField("Fecha de inicio",start,{start=it})};item{DateField("Vencimiento del cliente",end,{end=it})}
  item{Text("VENTA",fontWeight=FontWeight.Bold)};item{NumericField("Precio cobrado",price){price=it}};item{NumericField("Costo de la cuenta",cost){cost=it}};item{PaymentMethodField(method){method=it}}
  item{Text("PROVEEDOR / CUENTA COMPLETA",fontWeight=FontWeight.Bold)};item{F("Proveedor",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{DateField("Fecha de compra",purchaseDate,{purchaseDate=it},allowBlank=true)};item{DateField("Vencimiento de cuenta",accountEnd,{accountEnd=it},allowBlank=true)};item{NumericField("Costo de renovar cuenta",renewCost){renewCost=it}}
  if(!clientDatesOk)item{Text("El vencimiento del cliente no puede ser anterior al inicio.",color=StreamRed,style=MaterialTheme.typography.bodySmall)};if(!providerDatesOk)item{Text("Revisa las fechas del proveedor.",color=StreamRed,style=MaterialTheme.typography.bodySmall)};if(!phoneOk)item{Text("Revisa el WhatsApp del cliente.",color=StreamRed,style=MaterialTheme.typography.bodySmall)};if(!providerPhoneOk)item{Text("Revisa el WhatsApp del proveedor.",color=StreamRed,style=MaterialTheme.typography.bodySmall)}
  item{HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)};item{Text("CORRECCIÓN DE DATOS",fontWeight=FontWeight.Bold,color=StreamRed)};item{Text("Si este registro fue una prueba o se creó por error, puedes eliminarlo. Se libera el acceso asociado y se borran sus movimientos para no alterar los reportes.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{TextButton({confirmDelete=true},Modifier.fillMaxWidth(),colors=ButtonDefaults.textButtonColors(contentColor=StreamRed)){Text("Eliminar registro de prueba / error")}}
 }},confirmButton={Button(enabled=client.isNotBlank()&&service.isNotBlank()&&clientDatesOk&&providerDatesOk&&phoneOk&&providerPhoneOk&&method.isNotBlank(),onClick={save(s.copy(client=client.trim(),phone=phone.trim(),service=service.trim(),account=account.trim(),password=password,profile=profile.trim(),pin=pin,type=normalizedAccessType(type,profile),price=OperationRules.amount(price),accountCost=OperationRules.amount(cost),paymentMethod=method.trim(),start=start,end=end,provider=normalizedProviderStorage(provider),providerPhone=providerPhone.trim(),accountEnd=accountEnd,accountRenewCost=OperationRules.amount(renewCost),purchaseDate=purchaseDate))}){Text("Guardar cambios")}},dismissButton={TextButton(close){Text("Cancelar")}})
 if(confirmDelete)AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Eliminar registro")},text={Text("Esta acción es solo para registros creados por error o pruebas. El cliente se elimina de esta entrega, sus movimientos asociados se quitan de los reportes y el acceso vuelve a estar disponible.")},confirmButton={Button(delete,colors=ButtonDefaults.buttonColors(containerColor=StreamRed)){Text("Sí, eliminar")}},dismissButton={TextButton({confirmDelete=false}){Text("Cancelar")}})
}

@Composable fun QuickCollectionDialog(queue:List<Sub>,close:()->Unit,send:(Sub)->Unit,contact:(Sub)->Unit,renew:(Sub,Long,String,Int)->Unit){
 var index by remember{mutableIntStateOf(0)};var renewTarget by remember{mutableStateOf<Sub?>(null)};if(queue.isEmpty()){close();return};val current=queue[index.coerceAtMost(queue.lastIndex)]
 fun next(){if(index<queue.lastIndex)index++ else close()}
 AlertDialog(onDismissRequest=close,title={Text("Cobranza rápida ${index+1}/${queue.size}")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text(current.client,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text("${current.service} • vence ${current.end}");Text(money(current.price),style=MaterialTheme.typography.titleLarge,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold);if(current.lastContact.isNotBlank())Text(contactLabel(current.lastContact).replace("CONTACTADO ","Último contacto: ").lowercase().replaceFirstChar{it.uppercase()},style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Button({send(current);contact(current);next()},Modifier.fillMaxWidth()){Text("WhatsApp y siguiente")};OutlinedButton({renewTarget=current},Modifier.fillMaxWidth()){Text("Registrar renovación")}}},confirmButton={if(index<queue.lastIndex)TextButton({index++}){Text("Omitir")}},dismissButton={TextButton(close){Text("Salir")}})
 renewTarget?.let{target->RenewClientDialog(target,{renewTarget=null}){price,method,duration->renew(target,price,method,duration);renewTarget=null;next()}}
}

@Composable fun GlobalSearchDialog(s:List<Sub>,stock:List<StockItem>,templates:Templates,close:()->Unit,credentials:(Sub)->Unit,edit:(Sub)->Unit){
 var q by remember{mutableStateOf("")};val terms=q.trim();val clients=if(terms.length<2)emptyList() else s.filter{listOf(it.client,it.phone,it.service,it.account,it.profile,it.provider).any{x->x.contains(terms,true)}}.take(12);val items=if(terms.length<2)emptyList() else stock.filter{listOf(it.service,it.account,it.profile,it.provider).any{x->x.contains(terms,true)}}.take(12)
 AlertDialog(onDismissRequest=close,title={Text("Búsqueda global")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){item{OutlinedTextField(q,{q=it},label={Text("Cliente, correo, servicio, teléfono…")},singleLine=true,modifier=Modifier.fillMaxWidth())};if(terms.length<2)item{Text("Escribe al menos 2 caracteres.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};if(clients.isNotEmpty())item{Text("CLIENTES / ENTREGAS",fontWeight=FontWeight.Bold)};items(clients){x->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text(x.client,fontWeight=FontWeight.Bold);Text("${x.service} • ${x.account}",style=MaterialTheme.typography.bodySmall);Row{TextButton({credentials(x)}){Text("Credenciales")};TextButton({edit(x)}){Text("Editar")}}}}};if(items.isNotEmpty())item{Text("STOCK",fontWeight=FontWeight.Bold)};items(items){x->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text(x.service,fontWeight=FontWeight.Bold);Text(x.account,style=MaterialTheme.typography.bodySmall);Text("${if(isComplete(x))"Cuenta completa" else x.profile} • ${effectiveStockStatus(x)}",style=MaterialTheme.typography.labelSmall)}}}}},confirmButton={TextButton(close){Text("Cerrar")}})
}

@Composable fun ServiceTemplatesDialog(initial:List<ServiceTemplate>,close:()->Unit,save:(List<ServiceTemplate>)->Unit){
 var list by remember{mutableStateOf(initial)};var editId by remember{mutableStateOf<Long?>(null)};var name by remember{mutableStateOf("")};var type by remember{mutableStateOf("CUENTA COMPLETA")};var duration by remember{mutableStateOf("30")};var price by remember{mutableStateOf("")};var provider by remember{mutableStateOf("")};var providerPhone by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var renewCost by remember{mutableStateOf("")}
 fun clear(){editId=null;name="";type="CUENTA COMPLETA";duration="30";price="";provider="";providerPhone="";cost="";renewCost=""}
 fun load(t:ServiceTemplate){editId=t.id;name=t.name;type=t.type;duration=t.durationDays.toString();price=t.defaultPrice.toString();provider=t.provider;providerPhone=t.providerPhone;cost=t.accountCost.toString();renewCost=t.renewCost.toString()}
 AlertDialog(onDismissRequest=close,title={Text("Plantillas de servicios")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){item{Text("Una plantilla completa automáticamente duración, precio y proveedor al crear stock o una venta.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};item{F("Servicio",name){name=it}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(type=="CUENTA COMPLETA",{type="CUENTA COMPLETA"},{Text("Cuenta completa")},modifier=Modifier.weight(1f));FilterChip(type=="PERFIL/PANTALLA",{type="PERFIL/PANTALLA"},{Text("Perfil")},modifier=Modifier.weight(1f))}};item{F("Duración (días)",duration){duration=it}};item{F("Precio habitual",price){price=it}};item{F("Proveedor habitual",provider){provider=it}};item{F("WhatsApp proveedor",providerPhone){providerPhone=it}};item{F("Costo de cuenta",cost){cost=it}};item{F("Costo de renovar",renewCost){renewCost=it}};item{Button({val item=ServiceTemplate(id=editId?:System.currentTimeMillis(),name=name,type=type,durationDays=duration.toIntOrNull()?.coerceAtLeast(1)?:30,defaultPrice=price.filter{it.isDigit()}.toLongOrNull()?:0,provider=normalizedProviderStorage(provider),providerPhone=providerPhone,accountCost=cost.filter{it.isDigit()}.toLongOrNull()?:0,renewCost=renewCost.filter{it.isDigit()}.toLongOrNull()?:0);list=if(editId==null)list+item else list.map{if(it.id==item.id)item else it};clear()},enabled=name.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text(if(editId==null)"Agregar plantilla" else "Guardar cambios")}};if(list.isNotEmpty())item{Text("GUARDADAS",fontWeight=FontWeight.Bold)};items(list){t->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(9.dp)){Text(t.name,fontWeight=FontWeight.Bold);Text("${if(t.type=="CUENTA COMPLETA")"Cuenta completa" else "Perfil"} • ${t.durationDays} días • ${money(t.defaultPrice)}",style=MaterialTheme.typography.bodySmall);Row{TextButton({load(t)}){Text("Editar")};TextButton({list=list.filterNot{it.id==t.id}}){Text("Eliminar")}}}}}}},confirmButton={Button({save(list)}){Text("Guardar todo")}},dismissButton={TextButton(close){Text("Cancelar")}})
}


@Composable fun AppPinSetupDialog(changing:Boolean,close:()->Unit,save:(String)->Unit){
 var pin by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")};var error by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=close,title={Text(if(changing)"Cambiar PIN de acceso" else "Crear PIN de acceso")},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){Text("Usa entre 4 y 8 números. No se guarda el PIN en texto; solo una verificación segura.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedTextField(pin,{if(it.length<=8&&it.all(Char::isDigit)){pin=it;error=""}},label={Text("Nuevo PIN")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true,modifier=Modifier.fillMaxWidth());OutlinedTextField(confirm,{if(it.length<=8&&it.all(Char::isDigit)){confirm=it;error=""}},label={Text("Confirmar PIN")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true,modifier=Modifier.fillMaxWidth());if(error.isNotBlank())Text(error,color=StreamRed,style=MaterialTheme.typography.bodySmall)}},confirmButton={Button({if(!pin.matches(Regex("\\d{4,8}")))error="Usa entre 4 y 8 números" else if(pin!=confirm)error="Los PIN no coinciden" else save(pin)},enabled=pin.length>=4&&confirm.length>=4){Text("Guardar PIN")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun AppPinDisableDialog(close:()->Unit,disable:(String)->Unit){
 var pin by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=close,title={Text("Desactivar protección")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Confirma tu PIN actual. Al desactivarlo, cualquiera con acceso al teléfono podrá abrir la aplicación.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedTextField(pin,{if(it.length<=8&&it.all(Char::isDigit))pin=it},label={Text("PIN actual")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true,modifier=Modifier.fillMaxWidth())}},confirmButton={Button({disable(pin)},enabled=pin.length>=4){Text("Desactivar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}
@Composable fun BackupPasswordDialog(close:()->Unit,save:(String)->Unit){
 var a by remember{mutableStateOf("")};var b by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=close,title={Text("Proteger respaldos")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Esta contraseña permite recuperar tus copias incluso después de reinstalar la app.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedTextField(a,{a=it},label={Text("Contraseña (mínimo 6 caracteres)")},visualTransformation=PasswordVisualTransformation(),singleLine=true,modifier=Modifier.fillMaxWidth());OutlinedTextField(b,{b=it},label={Text("Repetir contraseña")},visualTransformation=PasswordVisualTransformation(),singleLine=true,modifier=Modifier.fillMaxWidth())}},confirmButton={Button({save(a)},enabled=a.length>=6&&a==b){Text("Guardar contraseña")}},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun RestorePasswordDialog(close:()->Unit,restore:(String)->Unit){
 var pass by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=close,title={Text("Contraseña del respaldo")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Escribe la contraseña con la que protegiste esta copia.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedTextField(pass,{pass=it},label={Text("Contraseña")},visualTransformation=PasswordVisualTransformation(),singleLine=true,modifier=Modifier.fillMaxWidth())}},confirmButton={Button({restore(pass)},enabled=pass.isNotBlank()){Text("Restaurar")}},dismissButton={TextButton(close){Text("Cancelar")}})
}
@Composable fun SaleStartDialog(stock:List<StockItem>,close:()->Unit,goStock:()->Unit,manual:()->Unit){
 val available=stock.count{effectiveStockStatus(it)=="DISPONIBLE"}
 AlertDialog(onDismissRequest=close,title={Text("Nueva venta")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Text("¿De dónde sale el acceso?",fontWeight=FontWeight.Bold);Button(goStock,Modifier.fillMaxWidth()){Text("Vender desde Stock${if(available>0)" • $available disponible${if(available==1)"" else "s"}" else ""}")};Text("Recomendado: evita duplicar cuentas y descuenta el inventario automáticamente.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton(manual,Modifier.fillMaxWidth()){Text("Venta manual avanzada")}}},confirmButton={},dismissButton={TextButton(close){Text("Cancelar")}})
}

@Composable fun ClientFields(existing:List<ClientRecord>,client:String,phone:String,onClient:(String)->Unit,onPhone:(String)->Unit){
 Column(verticalArrangement=Arrangement.spacedBy(6.dp)){
  F("Cliente",client,onClient)
  val q=client.trim();val matches=if(q.length>=2)existing.filter{it.name.contains(q,true)||it.phone.contains(q)}.take(5) else emptyList()
  if(matches.isNotEmpty()){Text("Clientes encontrados",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant);matches.forEach{x->Surface(Modifier.fillMaxWidth().clickable{onClient(x.name);onPhone(x.phone)},shape=RoundedCornerShape(10.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.45f)){Row(Modifier.padding(horizontal=10.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Person,contentDescription=null,tint=StreamCyan);Spacer(Modifier.width(8.dp));Column{Text(x.name,fontWeight=FontWeight.SemiBold);if(x.phone.isNotBlank())Text(x.phone,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}}}
  F("WhatsApp (57...)",phone,onPhone)
 }
}

@Composable fun F(l:String,v:String,c:(String)->Unit){OutlinedTextField(v,c,label={Text(l)},singleLine=false,modifier=Modifier.fillMaxWidth())}

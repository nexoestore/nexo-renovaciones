package com.nexo.suscripciones

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

object ReminderScheduler {
    private const val CHANNEL_CLIENT = "renovaciones"
    private const val CHANNEL_BUSINESS = "operacion_negocio"
    private val offsets = listOf(3, 1, 0)

    fun sync(context: Context, subs: List<Sub>, stock: List<StockItem>, templates: Templates) {
        createChannels(context)
        val prefs=context.getSharedPreferences("nexo_reminders",Context.MODE_PRIVATE)
        prefs.getStringSet("codes",emptySet())?.mapNotNull{it.toIntOrNull()}?.forEach{cancel(context,it)}
        val activeCodes=mutableSetOf<Int>()
        subs.forEach { sub ->
            when (BusinessStateEngine.client(sub).state) {
                ClientOperationState.FINALIZED -> Unit
                ClientOperationState.OVERDUE -> scheduleOverdue(context,sub,templates,activeCodes)
                ClientOperationState.PROMISE_DUE,
                ClientOperationState.WAITING -> if(sub.promiseDate.isNotBlank()) schedulePromise(context,sub,activeCodes,templates)
                else -> offsets.forEach { d -> scheduleClient(context,sub,d,templates,activeCodes) }
            }
        }
        uniqueProviderAccounts(subs,stock).forEach { account ->
            val baseId = stableLong("provider|${account.masterId.ifBlank { account.account }}")
            val providerState=BusinessStateEngine.provider(account.accountEnd)
            if(providerState.state==ProviderOperationState.OVERDUE) scheduleProviderOverdue(context,account,baseId,activeCodes,templates)
            else offsets.forEach { d -> scheduleProvider(context, account, baseId, d, activeCodes, templates) }
        }
        prefs.edit().putStringSet("codes",activeCodes.map{it.toString()}.toSet()).apply()
    }

    private fun uniqueProviderAccounts(subs:List<Sub>,stock: List<StockItem>):List<StockItem> {
        val legacy=subs.filter{it.accountEnd.isNotBlank()&&it.account.isNotBlank()}.map{it.toProviderReminderItem()}
        return (stock.filter{it.accountEnd.isNotBlank()}+legacy)
            .groupBy { it.masterId.ifBlank { "${providerKey(it.provider)}|${it.service.lowercase()}|${accountKey(it.account)}" } }
            .values.map { items -> items.maxByOrNull{if(it.accountEnd.isNotBlank())1 else 0}?:items.first() }
    }

    private fun Sub.toProviderReminderItem()=StockItem(
        id=stockId.takeIf{it>0}?:id,
        service=service,
        account=account,
        password="",
        profile=profile,
        pin="",
        type=type,
        provider=provider,
        providerPhone=providerPhone,
        accountEnd=accountEnd,
        accountCost=accountCost,
        accountRenewCost=accountRenewCost,
        status="OCUPADO",
        purchaseDate=purchaseDate,
        masterId="legacy|${providerKey(provider)}|${service.lowercase()}|${accountKey(account)}"
    )

    private fun scheduleClient(context: Context, sub: Sub, daysBefore: Int, templates: Templates, activeCodes:MutableSet<Int>) {
        val end = runCatching { LocalDate.parse(sub.end) }.getOrNull() ?: return
        val day = end.minusDays(daysBefore.toLong())
        val trigger = triggerAtNine(day) ?: return
        val template = when(daysBefore){3->templates.due3;1->templates.due1;else->templates.due0}
        val msg = fillTemplate(template, sub)
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("kind", "CLIENT");putExtra("id", sub.id);putExtra("client", sub.client);putExtra("phone", sub.phone)
            putExtra("service", sub.service);putExtra("end", sub.end);putExtra("days", daysBefore);putExtra("message",msg)
        }
        schedule(context, requestCode(sub.id, daysBefore), trigger, intent, activeCodes)
    }


    private fun scheduleOverdue(context:Context,sub:Sub,templates:Templates,activeCodes:MutableSet<Int>){
        // Un cliente vencido y aún no cortado necesita seguimiento, incluso si la app no vuelve a abrirse.
        // Programamos hasta 3 mañanas consecutivas; al renovar o cortar, sync() cancela estas alarmas.
        val today=LocalDate.now();val firstDay=if(LocalTime.now().isBefore(LocalTime.of(9,0)))today else today.plusDays(1)
        repeat(3){index->
            val day=firstDay.plusDays(index.toLong());val trigger=triggerAtNine(day)?:return@repeat
            val msg=fillTemplate(templates.expired,sub)
            val intent=Intent(context,ReminderReceiver::class.java).apply{putExtra("kind","OVERDUE");putExtra("id",sub.id);putExtra("client",sub.client);putExtra("phone",sub.phone);putExtra("service",sub.service);putExtra("end",sub.end);putExtra("days",index);putExtra("message",msg)}
            schedule(context,requestCode(sub.id,60+index),trigger,intent,activeCodes)
        }
    }

    private fun schedulePromise(context:Context, sub:Sub, activeCodes:MutableSet<Int>, templates:Templates=Templates()){
        val promisedDay=runCatching{LocalDate.parse(sub.promiseDate)}.getOrNull()?:return
        val today=LocalDate.now()
        val day=when{promisedDay.isAfter(today)->promisedDay;LocalTime.now().isBefore(LocalTime.of(9,0))->today;else->today.plusDays(1)}
        val trigger=triggerAtNine(day)?:return
        val msg=fillTemplate(templates.promise,sub.copy(end=sub.promiseDate))
        val intent=Intent(context,ReminderReceiver::class.java).apply{putExtra("kind","PROMISE");putExtra("id",sub.id);putExtra("client",sub.client);putExtra("phone",sub.phone);putExtra("service",sub.service);putExtra("end",sub.promiseDate);putExtra("message",msg)}
        schedule(context,requestCode(sub.id,50),trigger,intent,activeCodes)
    }

    private fun fillProviderTemplate(template:String,account:StockItem,provider:String):String{
        return template
            .replace("{proveedor}",provider)
            .replace("{servicio}",account.service)
            .replace("{cuenta}",account.account)
            .replace("{fecha}",account.accountEnd)
            .replace("{costo}",money(account.accountRenewCost))
            .trim()
    }

    private fun scheduleProviderOverdue(context:Context, account:StockItem, baseId:Long, activeCodes:MutableSet<Int>,templates:Templates=Templates()){
        val today=LocalDate.now();val firstDay=if(LocalTime.now().isBefore(LocalTime.of(9,0)))today else today.plusDays(1)
        repeat(3){index->
            val day=firstDay.plusDays(index.toLong());val trigger=triggerAtNine(day)?:return@repeat
            val provider=providerDisplayName(account.provider.ifBlank{"Proveedor"})
            val msg="Hola $provider 👋 La cuenta ${account.account} de ${account.service} venció el ${account.accountEnd}. Necesito renovarla. Costo estimado: ${money(account.accountRenewCost)}."
            val intent=Intent(context,ReminderReceiver::class.java).apply{putExtra("kind","PROVIDER_OVERDUE");putExtra("id",baseId);putExtra("client",provider);putExtra("phone",account.providerPhone);putExtra("service",account.service);putExtra("end",account.accountEnd);putExtra("days",index);putExtra("account",account.account);putExtra("message",msg)}
            schedule(context,requestCode(baseId,80+index),trigger,intent,activeCodes)
        }
    }

    private fun scheduleProvider(context:Context, account:StockItem, baseId:Long, daysBefore:Int, activeCodes:MutableSet<Int>,templates:Templates=Templates()){
        val end=runCatching{LocalDate.parse(account.accountEnd)}.getOrNull()?:return
        val day=end.minusDays(daysBefore.toLong());val trigger=triggerAtNine(day)?:return
        val provider=providerDisplayName(account.provider.ifBlank{"Proveedor"})
        val template=when(daysBefore){3->templates.provider3;1->templates.provider1;else->templates.provider0}
        val msg=fillProviderTemplate(template,account,provider)
        val intent=Intent(context,ReminderReceiver::class.java).apply{putExtra("kind","PROVIDER");putExtra("id",baseId);putExtra("client",provider);putExtra("phone",account.providerPhone);putExtra("service",account.service);putExtra("end",account.accountEnd);putExtra("days",daysBefore);putExtra("account",account.account);putExtra("message",msg)}
        schedule(context,requestCode(baseId,70+daysBefore),trigger,intent,activeCodes)
    }

    private fun triggerAtNine(day:LocalDate):Long?{
        val trigger=day.atTime(9,0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        return trigger.takeIf{it>System.currentTimeMillis()}
    }

    private fun schedule(context:Context, request:Int, trigger:Long, intent:Intent, activeCodes:MutableSet<Int>){
        val pi=PendingIntent.getBroadcast(context,request,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,trigger,pi)
        activeCodes+=request
    }

    private fun cancel(context: Context, request:Int) {
        val pi = PendingIntent.getBroadcast(context, request, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pi != null) context.getSystemService(AlarmManager::class.java).cancel(pi)
    }

    private fun requestCode(id: Long, code: Int) = (((id xor (id ushr 32)).toInt() and 0x00ffffff) + code * 1000000)
    private fun stableLong(value:String):Long=value.hashCode().toLong().let{if(it<0)-it else it}+10_000_000L

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_CLIENT, "Renovaciones de clientes", NotificationManager.IMPORTANCE_HIGH).apply { description = "Avisos de vencimiento de clientes" })
            nm.createNotificationChannel(NotificationChannel(CHANNEL_BUSINESS, "Operación del negocio", NotificationManager.IMPORTANCE_HIGH).apply { description = "Proveedores y promesas de pago" })
        }
    }

    fun show(context: Context, intent: Intent) {
        createChannels(context)
        val kind=intent.getStringExtra("kind")?:"CLIENT";val id=intent.getLongExtra("id",0);val client=intent.getStringExtra("client")?:"Cliente";val phone=intent.getStringExtra("phone")?:"";val service=intent.getStringExtra("service")?:"Servicio";val end=intent.getStringExtra("end")?:"";val days=intent.getIntExtra("days",0);val msg=intent.getStringExtra("message")?:""
        val title=when(kind){
            "PROMISE"->"🟣 Promesa de pago hoy"
            "OVERDUE"->"🔴 Vencido • pendiente de corte"
            "PROVIDER_OVERDUE"->"🔴 Cuenta del proveedor vencida"
            "PROVIDER"->when(days){3->"🟠 Cuenta proveedor vence en 3 días";1->"🟠 Cuenta proveedor vence mañana";else->"🟠 Cuenta proveedor vence hoy"}
            else->when(days){3->"🟠 Vence en 3 días";1->"⚪ Vence mañana";else->"🟡 Vence hoy"}
        }
        val text=when(kind){"PROVIDER"->"$service • ${intent.getStringExtra("account")?:"Cuenta"} • $end";else->"$client • $service • $end"}
        val target=if(phone.filter{it.isDigit()}.isNotBlank())Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/${phone.filter{it.isDigit()}}?text=${Uri.encode(msg)}")) else Intent(context,MainActivity::class.java)
        val code=when(kind){"PROMISE"->50;"OVERDUE"->60+days;"PROVIDER"->70+days;"PROVIDER_OVERDUE"->80+days;else->days};val open=PendingIntent.getActivity(context,requestCode(id,code),target,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val channel=if(kind=="CLIENT")CHANNEL_CLIENT else CHANNEL_BUSINESS
        val n=NotificationCompat.Builder(context,channel).setSmallIcon(R.drawable.ic_stat_nexo).setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(open).build()
        // Android 13+ requiere permiso de notificaciones en tiempo de ejecución.
        // Además de evitar un fallo de Lint (MissingPermission), si el usuario
        // todavía no lo concedió simplemente no intentamos publicar el aviso.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        context.getSystemService(NotificationManager::class.java).notify(requestCode(id,code),n)
    }
}

class ReminderReceiver : BroadcastReceiver() { override fun onReceive(context: Context, intent: Intent) { ReminderScheduler.show(context,intent) } }

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val st=Store(context);ReminderScheduler.sync(context,st.subs(),st.stock(),st.templates())
        }
    }
}

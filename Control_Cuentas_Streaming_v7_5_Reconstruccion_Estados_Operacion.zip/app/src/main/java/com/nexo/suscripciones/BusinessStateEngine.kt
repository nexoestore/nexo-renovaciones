package com.nexo.suscripciones

import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class ClientOperationState {
    FINALIZED,
    OVERDUE,
    DUE_TODAY,
    DUE_TOMORROW,
    UPCOMING_2_3,
    PROMISE_DUE,
    WAITING,
    CURRENT,
    INVALID_DATE
}

data class ClientOperationSnapshot(
    val state: ClientOperationState,
    val daysToEnd: Long? = null,
    val daysToPromise: Long? = null
)

enum class ProviderOperationState {
    OVERDUE,
    DUE_TODAY,
    DUE_TOMORROW,
    UPCOMING_2_3,
    UPCOMING_4_7,
    CURRENT,
    NO_DATE,
    INVALID_DATE
}

data class ProviderOperationSnapshot(
    val state: ProviderOperationState,
    val daysToEnd: Long? = null
)

/**
 * Fuente única de verdad para los estados operativos del negocio.
 * Inicio, Renovaciones, Reportes y recordatorios deben consultar este motor
 * en lugar de volver a interpretar las fechas de forma independiente.
 */
object BusinessStateEngine {
    fun client(sub: Sub, today: LocalDate = LocalDate.now()): ClientOperationSnapshot {
        if (sub.status.equals("CORTADO", ignoreCase = true)) {
            return ClientOperationSnapshot(ClientOperationState.FINALIZED)
        }

        if (sub.status.equals("ESPERA", ignoreCase = true)) {
            val promise = parse(sub.promiseDate)
            if (promise == null) return ClientOperationSnapshot(ClientOperationState.WAITING)
            val promiseDays = ChronoUnit.DAYS.between(today, promise)
            return ClientOperationSnapshot(
                state = if (promiseDays <= 0) ClientOperationState.PROMISE_DUE else ClientOperationState.WAITING,
                daysToEnd = parse(sub.end)?.let { ChronoUnit.DAYS.between(today, it) },
                daysToPromise = promiseDays
            )
        }

        val end = parse(sub.end) ?: return ClientOperationSnapshot(ClientOperationState.INVALID_DATE)
        val d = ChronoUnit.DAYS.between(today, end)
        val state = when {
            d < 0 -> ClientOperationState.OVERDUE
            d == 0L -> ClientOperationState.DUE_TODAY
            d == 1L -> ClientOperationState.DUE_TOMORROW
            d in 2L..3L -> ClientOperationState.UPCOMING_2_3
            else -> ClientOperationState.CURRENT
        }
        return ClientOperationSnapshot(state = state, daysToEnd = d)
    }

    fun requiresAction(snapshot: ClientOperationSnapshot): Boolean = when (snapshot.state) {
        ClientOperationState.OVERDUE,
        ClientOperationState.DUE_TODAY,
        ClientOperationState.DUE_TOMORROW,
        ClientOperationState.UPCOMING_2_3,
        ClientOperationState.PROMISE_DUE -> true
        else -> false
    }

    fun isWaiting(snapshot: ClientOperationSnapshot): Boolean = snapshot.state == ClientOperationState.WAITING

    fun priority(snapshot: ClientOperationSnapshot): Int = when (snapshot.state) {
        ClientOperationState.OVERDUE -> 0
        ClientOperationState.PROMISE_DUE -> 1
        ClientOperationState.DUE_TODAY -> 2
        ClientOperationState.DUE_TOMORROW -> 3
        ClientOperationState.UPCOMING_2_3 -> 4
        ClientOperationState.WAITING -> 5
        ClientOperationState.CURRENT -> 6
        ClientOperationState.INVALID_DATE -> 7
        ClientOperationState.FINALIZED -> 8
    }

    fun clientLabel(snapshot: ClientOperationSnapshot): String = when (snapshot.state) {
        ClientOperationState.FINALIZED -> "FINALIZADO"
        ClientOperationState.OVERDUE -> "VENCIDO"
        ClientOperationState.DUE_TODAY -> "VENCE HOY"
        ClientOperationState.DUE_TOMORROW -> "MAÑANA"
        ClientOperationState.UPCOMING_2_3 -> when (snapshot.daysToEnd) {
            2L -> "EN 2 DÍAS"
            3L -> "EN 3 DÍAS"
            else -> "PRÓXIMO"
        }
        ClientOperationState.PROMISE_DUE -> if ((snapshot.daysToPromise ?: 0L) < 0L) "PROMESA ATRASADA" else "PROMESA HOY"
        ClientOperationState.WAITING -> "EN ESPERA"
        ClientOperationState.CURRENT -> "AL DÍA"
        ClientOperationState.INVALID_DATE -> "REVISAR FECHA"
    }

    fun provider(end: String, today: LocalDate = LocalDate.now()): ProviderOperationSnapshot {
        if (end.isBlank()) return ProviderOperationSnapshot(ProviderOperationState.NO_DATE)
        val date = parse(end) ?: return ProviderOperationSnapshot(ProviderOperationState.INVALID_DATE)
        val d = ChronoUnit.DAYS.between(today, date)
        val state = when {
            d < 0 -> ProviderOperationState.OVERDUE
            d == 0L -> ProviderOperationState.DUE_TODAY
            d == 1L -> ProviderOperationState.DUE_TOMORROW
            d in 2L..3L -> ProviderOperationState.UPCOMING_2_3
            d in 4L..7L -> ProviderOperationState.UPCOMING_4_7
            else -> ProviderOperationState.CURRENT
        }
        return ProviderOperationSnapshot(state = state, daysToEnd = d)
    }

    fun providerNeedsImmediateAction(snapshot: ProviderOperationSnapshot): Boolean = when (snapshot.state) {
        ProviderOperationState.OVERDUE,
        ProviderOperationState.DUE_TODAY,
        ProviderOperationState.DUE_TOMORROW,
        ProviderOperationState.UPCOMING_2_3 -> true
        else -> false
    }

    fun providerNeedsAttentionWithinWeek(snapshot: ProviderOperationSnapshot): Boolean = when (snapshot.state) {
        ProviderOperationState.OVERDUE,
        ProviderOperationState.DUE_TODAY,
        ProviderOperationState.DUE_TOMORROW,
        ProviderOperationState.UPCOMING_2_3,
        ProviderOperationState.UPCOMING_4_7 -> true
        else -> false
    }

    fun providerLabel(snapshot: ProviderOperationSnapshot): String = when (snapshot.state) {
        ProviderOperationState.OVERDUE -> "VENCIDA"
        ProviderOperationState.DUE_TODAY -> "VENCE HOY"
        ProviderOperationState.DUE_TOMORROW -> "MAÑANA"
        ProviderOperationState.UPCOMING_2_3 -> when (snapshot.daysToEnd) {
            2L -> "EN 2 DÍAS"
            3L -> "EN 3 DÍAS"
            else -> "PRÓXIMA"
        }
        ProviderOperationState.UPCOMING_4_7 -> "ESTA SEMANA"
        ProviderOperationState.CURRENT -> "AL DÍA"
        ProviderOperationState.NO_DATE -> "SIN FECHA"
        ProviderOperationState.INVALID_DATE -> "REVISAR FECHA"
    }

    private fun parse(value: String): LocalDate? = runCatching { LocalDate.parse(value.trim()) }.getOrNull()
}

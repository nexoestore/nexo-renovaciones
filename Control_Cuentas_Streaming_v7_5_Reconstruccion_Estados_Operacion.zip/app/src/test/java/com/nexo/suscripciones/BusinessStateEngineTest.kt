package com.nexo.suscripciones

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class BusinessStateEngineTest {
    private val today = LocalDate.of(2026,10,8)
    private fun sub(end:String,status:String="ACTIVO",promise:String="") = Sub(
        client="Aldana", phone="3001234567", service="Disney", account="a@b.com", profile="3",
        type="PERFIL/PANTALLA", price=10000, start="2026-09-10", end=end, status=status, promiseDate=promise
    )

    @Test fun aldana_two_days_away_is_upcoming_and_actionable(){
        val state=BusinessStateEngine.client(sub("2026-10-10"),today)
        assertEquals(ClientOperationState.UPCOMING_2_3,state.state)
        assertEquals(2L,state.daysToEnd)
        assertTrue(BusinessStateEngine.requiresAction(state))
        assertEquals("EN 2 DÍAS",BusinessStateEngine.clientLabel(state))
    }

    @Test fun future_promise_is_waiting_and_not_in_daily_queue(){
        val state=BusinessStateEngine.client(sub("2026-10-07","ESPERA","2026-10-12"),today)
        assertEquals(ClientOperationState.WAITING,state.state)
        assertFalse(BusinessStateEngine.requiresAction(state))
    }

    @Test fun promise_due_today_returns_to_daily_queue(){
        val state=BusinessStateEngine.client(sub("2026-10-07","ESPERA","2026-10-08"),today)
        assertEquals(ClientOperationState.PROMISE_DUE,state.state)
        assertTrue(BusinessStateEngine.requiresAction(state))
        assertEquals("PROMESA HOY",BusinessStateEngine.clientLabel(state))
    }

    @Test fun waiting_client_is_not_counted_as_expired(){
        val state=BusinessStateEngine.client(sub("2026-10-01","ESPERA","2026-10-12"),today)
        assertNotEquals(ClientOperationState.OVERDUE,state.state)
        assertEquals(ClientOperationState.WAITING,state.state)
    }

    @Test fun overdue_provider_requires_action(){
        val state=BusinessStateEngine.provider("2026-10-07",today)
        assertEquals(ProviderOperationState.OVERDUE,state.state)
        assertTrue(BusinessStateEngine.providerNeedsImmediateAction(state))
    }

    @Test fun provider_in_five_days_is_week_attention_not_immediate(){
        val state=BusinessStateEngine.provider("2026-10-13",today)
        assertEquals(ProviderOperationState.UPCOMING_4_7,state.state)
        assertFalse(BusinessStateEngine.providerNeedsImmediateAction(state))
        assertTrue(BusinessStateEngine.providerNeedsAttentionWithinWeek(state))
    }
}

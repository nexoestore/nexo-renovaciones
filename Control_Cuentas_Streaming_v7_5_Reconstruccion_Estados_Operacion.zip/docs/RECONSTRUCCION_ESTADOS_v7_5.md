# Reconstrucción de estados — v7.5

La aplicación dejó de calcular el estado de cada cliente de manera independiente en cada pantalla.
`BusinessStateEngine` es ahora la fuente única de verdad para Inicio, Renovaciones, Reportes y recordatorios.

## Cliente

- `OVERDUE`: vencido y requiere gestión.
- `DUE_TODAY`: vence hoy.
- `DUE_TOMORROW`: vence mañana.
- `UPCOMING_2_3`: vence en 2 o 3 días.
- `PROMISE_DUE`: la promesa de pago es hoy o quedó atrasada.
- `WAITING`: existe una promesa futura. No aparece en Trabajo de hoy hasta esa fecha.
- `CURRENT`: al día.
- `FINALIZED`: servicio finalizado/cortado.

## Proveedor

Las cuentas vencidas ya no desaparecen del indicador. Una cuenta vencida, que vence hoy, mañana o en 2–3 días se considera atención inmediata.

## Dinero

Se evita llamar "ganancia" a un simple flujo de caja mensual. La interfaz utiliza "Balance de caja" para cobrado menos inversión del mes.

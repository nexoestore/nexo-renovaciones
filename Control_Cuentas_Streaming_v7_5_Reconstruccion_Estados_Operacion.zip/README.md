# Control de Cuentas Streaming v7.5

Actualización reconstructiva enfocada en consistencia operativa.

Base: v7.4.3 con Room, cifrado local, PIN/biometría, respaldos cifrados, validaciones, perfiles visibles y controles de calidad.

## Novedades principales

- Nuevo `BusinessStateEngine`: una sola fuente de verdad para estados de clientes y proveedores.
- Inicio, Renovaciones, Reportes y recordatorios usan las mismas reglas.
- Caso corregido: un cliente que vence en 2 días ahora aparece tanto en “Clientes por gestionar” como en “Operación de hoy”.
- Inicio muestra Vencidos, Hoy, Mañana y Próximos 2–3 días por separado.
- “Dar plazo” ahora retira al cliente de Trabajo de hoy hasta la fecha prometida.
- Cuando la promesa llega o se atrasa, el cliente vuelve automáticamente a la cola operativa.
- Las cuentas del proveedor ya vencidas dejan de desaparecer de los indicadores: pasan a atención inmediata.
- Los recordatorios también contemplan cuentas del proveedor vencidas.
- “CONTACTADO” se reemplaza por “WHATSAPP ABIERTO”, porque abrir WhatsApp no confirma el envío del mensaje.
- “Costos del mes” pasa a “Invertido este mes”.
- “Ganancia del mes” pasa a “Balance de caja” para no confundir inversión pendiente de recuperar con una pérdida definitiva.
- Reportes muestra “Por gestionar ahora” usando el mismo motor operativo.
- Se mantienen Stock, perfiles visibles, Room, cifrado, respaldo local, seguridad y compatibilidad de datos.

Version: 7.5 (versionCode 36)
Application ID: com.nexo.suscripciones
Target SDK: 36

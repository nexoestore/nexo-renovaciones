# Control de Cuentas Streaming v6.8

## Modo simple para distribuidores

Esta versión mantiene las funciones anteriores y reorganiza la interfaz para que un distribuidor con poca experiencia técnica sepa qué hacer sin interpretar métricas complejas.

- Identidad Nexo Digital: fondo azul/negro, cian/turquesa y blanco.
- Clientes vencidos: rojo.
- Vence hoy: amarillo/naranja.
- Accesos disponibles: azul.
- Cuentas del proveedor por vencer: amarillo/naranja.
- Inicio orientado a tareas del día.
- Renovaciones con estados visuales y cobranza rápida.
- Stock dividido en `Para vender` y `Ya entregadas`.
- Acciones directas: Vender cuenta / Asignar perfil.
- Proveedores con conteo único y cuentas por vencer.
- Reportes simplificados con ventas, costos, ganancia y cobros.
- Conserva datos, respaldo, notificaciones, búsqueda, WhatsApp y firma.


Actualización de proveedores únicos: corrige conteos duplicados y unifica variantes de nombres/URL sin borrar datos.

Actualización construida sobre la v6.4 que ya generó APK y AAB correctamente en GitHub Actions. Esta versión reorganiza la aplicación alrededor del flujo real de un revendedor:

**Proveedor → Compra/Stock → Venta → Entrega → Renovación → Corte → Ganancia**

## Qué cambia en v6.5.2

### Inicio — Operación de hoy
- Clientes vencidos y clientes que vencen hoy.
- Stock realmente disponible para vender.
- Cuentas del proveedor próximas a vencer.
- Por cobrar, ventas del mes, costos del mes y utilidad estimada.
- Alertas de proveedor y promesas de pago que requieren atención.

### Stock y cuentas activas
La aplicación deja de mezclar inventario con cuentas ya vendidas:

- **Stock para vender**: accesos que todavía puedes comercializar.
- **Cuentas activas**: cuentas completas entregadas o cuentas compartidas que ya tienen perfiles ocupados.

Estados definidos:
- Cuenta completa: `DISPONIBLE` → `ENTREGADA` → `DISPONIBLE` al finalizar el servicio, o `NO DISPONIBLE` si hay un problema/vencimiento.
- Perfil/Pantalla: `DISPONIBLE` → `OCUPADO` → `DISPONIBLE` al finalizar el servicio, o `NO DISPONIBLE`.

No se utiliza estado **Reservado**.

### Venta rápida desde Stock
Si el acceso ya está registrado, al vender solo necesitas ingresar cliente, WhatsApp, precio, método de pago, fecha de inicio y duración. Correo, contraseña, perfil, PIN, proveedor, costo y vencimiento del proveedor se reutilizan automáticamente.

### Proveedores
Nueva vista dedicada para analizar:
- inversión por proveedor;
- ingresos acumulados;
- renovaciones pagadas al proveedor;
- utilidad acumulada;
- fecha de compra;
- fecha de vencimiento de cada cuenta;
- costo de renovación;
- contacto directo por WhatsApp;
- registro de renovación de la cuenta con el proveedor.

### Reportes
Incluye ventas, costos, utilidad, cartera, clientes activos, renovaciones, bajas, tasa de renovación, ocupación de perfiles, proveedores próximos a vencer, proveedor más rentable, cuenta más rentable y actividad reciente.

### Operación y seguridad
Se mantienen las funciones existentes: mensajes configurables, envío/reenvío de credenciales, edición de cuentas entregadas, ajuste de vencimiento, +30 días, dar plazo, no renovó/finalizar, incidencias, búsqueda global, plantillas de servicio, notificaciones, respaldo manual y respaldo automático local con conservación de las últimas 7 copias.

## Compatibilidad de datos
- Conserva `applicationId = com.nexo.suscripciones`.
- Conserva `SharedPreferences` con nombre `nexo_db`.
- Los campos nuevos usan valores por defecto para mantener compatibilidad con datos anteriores.
- El respaldo usa `backupVersion = 5` y puede restaurar información generada por versiones previas que contengan los datos base.

## Compilación / Google Play
- `versionName = 6.5.1`
- `versionCode = 20`
- `minSdk = 26`
- `compileSdk = 36`
- `targetSdk = 36`
- Java/Kotlin JVM 17
- Android Gradle Plugin 8.9.1
- Gradle 8.11.1 en GitHub Actions
- Genera APK release y AAB release usando la clave permanente configurada en GitHub Secrets.

Usa `WORKFLOW_GOOGLE_PLAY_DESDE_ZIP.yml` si mantienes el flujo de subir un único ZIP al repositorio.

Consulta también:
- `docs/ARQUITECTURA_NEGOCIO.md`
- `docs/PLAY_CONSOLE_CHECKLIST.md`
- `docs/PLAY_STORE_LISTING.md`
- `docs/privacy-policy.html`

## Validación
Antes de empaquetar esta entrega se verifican estructura del proyecto, balance sintáctico básico del Kotlin, XML, referencias de versión y la integridad completa del ZIP. La compilación Android definitiva debe confirmarse con GitHub Actions, ya que es el mismo entorno que usarás para obtener el APK y el AAB firmados.


## Pulido v6.5.2
- Eliminados los banners estáticos “Flujo del negocio”, “¿Qué ves aquí?” y “Rentabilidad por proveedor”.
- Inicio entra directamente a indicadores reales y trabajo pendiente.
- Stock entra directamente a disponibilidad y cuentas activas.
- Compras/Proveedores muestra resumen real: proveedores, cuentas por renovar, inversión y utilidad acumulada.
- Ajustes también elimina texto explicativo redundante.
- La lógica comercial, datos, respaldo, firma y applicationId permanecen compatibles.

## Ajuste v6.6.1
- Amarillo: clientes que vencen hoy.
- Naranja: cuentas próximas a vencer con el proveedor.
- Rojo: clientes vencidos.
- Azul: accesos disponibles.
- Verde: estados positivos y ganancia.
- Morado: espera/promesa de pago.


## v6.7 — Vista rápida de cuentas

- Stock rediseñado en modo compacto para ver muchas cuentas por pantalla.
- Buscador visible por servicio, correo, cliente, perfil o proveedor.
- Filtros simples en Para vender y Ya entregadas.
- Las tarjetas se expanden solo cuando necesitas detalles financieros o del proveedor.
- En cuentas entregadas: botones Enviar datos y Editar. Se eliminó el botón Fecha de esa fila.
- Reportes aclaran la diferencia entre clientes activos, ventas nuevas y renovaciones del mes.
- Ventas del mes pasa a llamarse Cobrado este mes para evitar confusión.
- versionCode 25 / versionName 6.7.


## v6.8 — Cuentas por perfiles

- Una cuenta compartida se registra una sola vez con correo, contraseña, proveedor y vencimiento.
- En el mismo formulario se agregan Perfil 1, Perfil 2, Perfil 3... y el PIN de cada uno.
- `+ Agregar perfil` permite crear tantos perfiles como tenga la cuenta.
- La compra/costo se registra una sola vez aunque existan varios perfiles.
- Stock agrupa visualmente todos los perfiles bajo su cuenta principal.
- Cada perfil muestra LIBRE, OCUPADO o NO DISP.
- Tocar un perfil LIBRE abre `Asignar perfil`.
- La fecha del proveedor se mantiene separada de la fecha del cliente.
- Al asignar, el perfil pasa a OCUPADO y muestra el cliente.
- `Editar cuenta` actualiza los datos comunes de todos los perfiles.
- versionCode 26 / versionName 6.8.

# Control de Cuentas Streaming v6.7

## Objetivo
Acelerar la revisión de muchas cuentas sin perder funciones y hacer los reportes más fáciles de entender para distribuidores.

## Cambios
- Vista compacta de Stock y Ya entregadas.
- Búsqueda permanente.
- Filtros simples por estado.
- Toque sobre una cuenta para expandir costo, ingreso, ganancia, proveedor y fechas.
- Enviar datos reemplaza Datos.
- Se elimina Fecha junto a Editar.
- Reportes: Cobrado este mes, Clientes activos ahora, Ventas nuevas este mes y Renovaciones este mes.
- Se conserva el formato de datos y respaldos anteriores.

# Control de Cuentas Streaming v6.8

## Registro más rápido de cuentas por perfiles
Al elegir `Por perfiles`, correo, contraseña, proveedor, costo y vencimiento se escriben una sola vez. En la misma ventana se agregan todos los perfiles y PIN.

## Vista agrupada
Las cuentas compartidas se muestran como una sola tarjeta:
- servicio
- credenciales
- perfiles
- vencimiento proveedor
- estados LIBRE / OCUPADO / NO DISP.

Tocar un perfil libre abre el flujo de asignación.

## Fechas separadas
- Vencimiento proveedor: fecha de la cuenta comprada.
- Vencimiento cliente: fecha individual del perfil asignado.

## Compatibilidad
Se conserva `com.nexo.suscripciones` y el formato de datos anterior. Los perfiles continúan almacenados como accesos individuales para conservar compatibilidad con respaldos y renovaciones existentes.
